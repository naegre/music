#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 3 || $# -gt 4 ]]; then
  echo "Usage: $0 OVERALL_FEATURES.csv DEVICE_DOMAINS.csv SUBMODEL_PREDICTIONS.csv [FROZEN_SPLIT.json]" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OVERALL_DATA="$1"
DOMAINS="$2"
SUBMODEL_PREDICTIONS="$3"
SPLIT="${4:-$ROOT/data/real/frozen_pc_split.json}"

cd "$ROOT"
python main.py train \
  --overall-data "$OVERALL_DATA" \
  --domains "$DOMAINS" \
  --submodel-predictions "$SUBMODEL_PREDICTIONS" \
  --schema configs/feature_schema.json \
  --replacements configs/replacement_map.json \
  --experiment configs/experiment.json \
  --split "$SPLIT" \
  --output-dir results/real/train \
  --model-dir models/real

echo "Training complete: results/real/train"
