#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

python main.py generate-synthetic
python main.py train
python main.py predict

echo "Demo complete: results/synthetic"
