# GitHub 上传清单

## 建议上传

- `src/`：模型与数据处理源码。
- `cli/`、`main.py`、`scripts/`：命令行入口。
- `configs/`：列契约、替换映射和有限超参数网格。
- `tests/`：防泄漏和端到端测试。
- `data/synthetic/`：不含真实隐私数据的演示输入。
- `models/synthetic/`：仅用于验证加载流程的演示模型。
- `results/synthetic/`：可对照的演示输出。
- `README.md`、`FUNCTION_REFERENCE.md`、`requirements.txt`、`pyproject.toml`。

## 默认不上传

`.gitignore` 已排除：

- `data/real/`：真实设备测量与人工评分。
- `models/real/`：真实训练模型。
- `results/real/`：真实预测结果。
- Python、pytest、虚拟环境和编辑器缓存。

若仓库必须包含真实模型，请先确认数据授权和仓库可见性，再从 `.gitignore` 中删除对应规则。

## 上传前验证

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
python -m pytest -q
python main.py --help
python main.py predict
```

演示预测成功后，关键结果应位于：

```text
results/synthetic/predict/new_device_rankings.csv
results/synthetic/predict/new_vs_reference_probabilities.csv
```
