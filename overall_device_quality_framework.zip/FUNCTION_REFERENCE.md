# Overall 模块函数参考

以下路径均相对于 `src/subjective_audio_quality/overall/`。

## `config.py`

### `OverallSchema.load(path)`

- 输入：`feature_schema.json`。
- 输出：名称列、目标列、主观后缀和 22 个特征列的不可变配置。

### `load_replacement_rules(path)`

- 输入：replacement JSON。
- 输出：`tuple[ReplacementRule, ...]`。
- 校验：同一个原列不能被两个映射重复删除。

### `OverallExperiment.load(path)`

- 输入：模型网格和验证参数 JSON。
- 输出：`OverallExperiment`。

## `data.py`

### `load_and_validate_overall(path, schema, require_target=True)`

- 输入：一行一台设备的 CSV。
- 输出：数值已转换的 DataFrame。
- 拒绝：缺列、重复设备、NaN/Inf、overall 超出 0 到 100。

### `load_domains(path)`

- 输入：`name,domain` CSV。
- 输出：域表。
- 拒绝：重复设备或 tablet/pc 之外的值。

### `load_submodel_predictions(path)`

- 输入：长表 `name,subdir,predicted_percentile,prediction_se,prediction_source`。
- 输出：已校验预测表。

### `validate_prediction_sources(...)`

- 输入：预测表、映射、平板名单、PC 名单。
- 输出：无。
- 拒绝：平板不是 OOF、PC 不是 inductive、无法完整审计来源。

### `apply_replacements(...)`

- 输入：原始设备表、域表、子模型预测、schema 和映射。
- 输出：`PreparedOverallData`，包含最终矩阵、特征元数据、SE 矩阵和替换审计。

### `create_stratified_split(frame, target_column, pc_development_count, seed)`

- 输入：带域和 overall 的设备表。
- 输出：15 台平板、5 台开发 PC、6 台外测 PC 的冻结字典。

### `load_and_validate_split(path, frame)`

- 输入：已有 split JSON 和当前设备表。
- 输出：切分字典。
- 拒绝：设备重复、域错误、未知设备或未覆盖设备。

### `domain_balanced_weights(domains)`

- 输入：每行域标签。
- 输出：平板和 PC 各占一半总权重的数组。

## `preprocessing.py`

### `robust_scale(values)`

- 输出：`center, scale, method`。
- 顺序：median/MAD，IQR，标准差，单位尺度。

### `OverallPreprocessor(mode, n_components)`

- `robust`：逐列 robust 标准化。
- `block`：robust 后按组列数平方根均衡。
- `pca`：robust 后在当前训练折内 PCA。
- `raw_feature_coefficients()`：把模型系数回投到原特征单位。

## `score_model.py`

### `score_candidates(...)`

- 输入：Ridge alpha、Huber alpha、PCA 维数和 Huber delta 网格。
- 输出：有限 `ScoreSpec` 列表。

### `WeightedDomainRegressor.fit(z, domains, y, sample_weight)`

- Ridge：有界加权最小二乘。
- Huber：有界 L-BFGS-B。
- 参数：非负质量系数、自由 PC 偏移、自由截距。

### `OverallScorePipeline.fit(...)` / `predict(...)`

- 输入：最终特征、域、overall、特征元数据。
- 输出：0 到 100 的 overall 预测。

## `rank_model.py`

### `overall_preference_probability(score_difference, probability_per_point=0.1)`

- 输入：A-B 的 overall 差。
- 输出：`clip(0.5 + 0.1 * 差值, 0, 1)`。

### `RankFeatureScaler.fit(x, y, feature_metadata)`

- `_S`：一分保持一单位。
- 其他列：当前训练折内映射到 overall robust 尺度。
- 可选 block 语义组均衡。

### `make_within_domain_pairs(...)`

- 输入：变换特征、overall、设备名和域。
- 输出：差分、软目标、域均衡权重和设备对。
- 保证：不生成跨域 pair。

### `SoftPairwiseRanker.fit(differences, targets, weights)`

- 目标：加权软交叉熵加 L2 正则。
- 约束：全部 utility 系数非负，无截距，保持 A/B 反对称。

### `OverallRankPipeline.fit(...)` / `utility(...)`

- 输出：设备 utility。utility 只在同一个已拟合模型尺度内比较。

## `validation.py`

### `compare_score_candidates(...)`

- 对每个 exact 候选做开发 PC Leave-One-Out。
- 输出：候选汇总和每折预测。

### `nested_score_validation(...)`

- 外层每次留 1 台开发 PC，内层在剩余 PC 上选候选。
- 输出：nested OOF 预测和每折选择记录。

### `compare_rank_candidates(...)`

- 对每个 rank 候选生成 held-out-PC 对概率。
- 输出：候选汇总、pair 预测和设备预期胜率。

### `nested_rank_validation(...)`

- 排名侧完整嵌套 PC 留一。
- 输出：nested pair、设备级预期胜率、每折选型。

## `metrics.py`

### `regression_metrics(y_true, prediction)`

- 输出：n、MAE、RMSE、bias、最大绝对误差、Pearson、Spearman、Kendall tau。

### `soft_pair_metrics(targets, probabilities)`

- 输出：pair 数、方向准确率、Brier 和 soft log loss。

### `device_rank_metrics(y_true, rank_signal)`

- 输出：设备数、Spearman、Kendall tau 和设备对方向准确率。

### `rank_summary(names, utilities)`

- 输出：1 为最佳的名次、排名百分位、预期两两胜率和 utility。

## `uncertainty.py`

### `monte_carlo_group_predictions(...)`

- 输入：score/rank 模型、设备表、SE 矩阵、抽样次数和 seed。
- 过程：按正态 SE 抽样；百分位列截到 0 到 100。
- 输出：设备 score/utility/rank CI 与两两概率 CI。
- 限制：只传播输入子模型 SE。

## `ood.py`

### `RobustOODDetector.fit(x, domains)`

- 只在开发设备拟合全部开发和 PC-only 两套 robust 范围。

### `RobustOODDetector.report(x, names)`

- 输出：设备摘要和触发告警的特征明细。

## `synthetic.py`

### `generate_synthetic_dataset(...)`

- 输出：26 台设备的完整演示数据、域表、子模型预测、6 台推理子集、split 和 manifest。
- 保证：`ipad` 22 个特征和 overall 与用户样例一致。

## `training.py`

### `train_overall_models(...)`

- 完整执行校验、替换、来源审计、嵌套选型、最终拟合、冻结外测、CI、OOD、CSV/JSON 输出和 joblib 保存。
- 返回：关键输出路径字典。

## `prediction.py`

### `predict_new_devices(...)`

- 输入：可信 model bundle、新 PC 原特征、域表和 inductive 子模型预测。
- 输出：新 PC 排名、与每台参考 PC 的胜率、CI、邻近设备和 OOD。
- 拒绝：非 PC、映射缺失、来源非 inductive、设备名与参考设备冲突。
