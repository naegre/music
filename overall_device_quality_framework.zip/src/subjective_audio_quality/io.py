"""Tabular I/O and validation for x-level audio metric data."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .config import ColumnConfig


CANONICAL_REQUIRED = (
    "subdir",
    "name",
    "x",
    "n_windows",
    "cos_mean",
    "cos_var",
    "l2_mean",
    "l2_var",
)


def read_table(path: str | Path) -> pd.DataFrame:
    """Read CSV or TSV using UTF-8 and automatic delimiter detection.

    Parameters
    ----------
    path:
        Input ``.csv``/``.txt`` table. One row must already represent one
        ``name + subdir + x`` aggregate, not one 5-second window.

    Returns
    -------
    pandas.DataFrame
        Raw columns exactly as stored in the file.
    """

    return pd.read_csv(path, sep=None, engine="python", encoding="utf-8-sig")


def canonicalize_columns(frame: pd.DataFrame, columns: ColumnConfig) -> pd.DataFrame:
    """Rename configured source columns and validate value domains."""

    renamed = frame.rename(columns=columns.rename_to_canonical()).copy()
    missing = [column for column in CANONICAL_REQUIRED if column not in renamed]
    if missing:
        raise ValueError(f"Missing required columns after mapping: {missing}")

    renamed["subdir"] = renamed["subdir"].astype(str).str.strip()
    renamed["name"] = renamed["name"].astype(str).str.strip()
    renamed["x"] = renamed["x"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    numeric = ["n_windows", "cos_mean", "cos_var", "l2_mean", "l2_var"]
    for column in numeric:
        renamed[column] = pd.to_numeric(renamed[column], errors="coerce")
    invalid = ~np.isfinite(renamed[numeric].to_numpy(dtype=float)).all(axis=1)
    if invalid.any():
        indices = renamed.index[invalid].tolist()[:10]
        raise ValueError(f"Non-finite required numeric values at rows: {indices}")
    if (renamed["n_windows"] < 1).any():
        raise ValueError("n_windows must be at least 1")
    if (renamed[["cos_var", "l2_var"]] < 0).any().any():
        raise ValueError("Metric variances cannot be negative")
    if (renamed["l2_mean"] < 0).any():
        raise ValueError("L2 distance cannot be negative")
    if renamed[["subdir", "name", "x"]].eq("").any().any():
        raise ValueError("subdir, name, and x cannot be empty")
    return renamed


def write_csv(frame: pd.DataFrame, path: str | Path) -> None:
    """Write a DataFrame as UTF-8-SIG CSV for Excel compatibility."""

    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False, encoding="utf-8-sig")


def summarize_input(frame: pd.DataFrame) -> dict[str, int]:
    """Return compact row/device/task coverage counts for an audit JSON."""

    return {
        "rows": int(len(frame)),
        "devices": int(frame["name"].nunique()),
        "subdirs": int(frame["subdir"].nunique()),
        "subdir_x_pairs": int(frame[["subdir", "x"]].drop_duplicates().shape[0]),
    }

