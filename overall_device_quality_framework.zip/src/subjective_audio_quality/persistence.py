"""Model bundle persistence with a human-readable metadata sidecar."""

from __future__ import annotations

from pathlib import Path

import joblib

from .config import save_json


def save_bundle(bundle: dict, model_path: str | Path, metadata_path: str | Path) -> None:
    """Save executable model objects with joblib and JSON-safe metadata separately."""

    model_output = Path(model_path)
    model_output.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, model_output)
    save_json(bundle["metadata"], metadata_path)


def load_bundle(path: str | Path) -> dict:
    """Load a trusted local bundle created by :func:`save_bundle`.

    Joblib/pickle files can execute code while loading. Never load a model file
    from an untrusted source.
    """

    payload = joblib.load(path)
    if not isinstance(payload, dict) or "models" not in payload:
        raise ValueError("Not a subjective_audio_quality model bundle")
    return payload

