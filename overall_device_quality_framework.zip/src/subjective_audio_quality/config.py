"""Configuration loading and canonical schema definitions."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


PRIMARY_METRICS = ("l2", "cos")


@dataclass(frozen=True)
class ColumnConfig:
    """Map source columns to the package's canonical field names."""

    subdir: str = "subdir"
    name: str = "name"
    x: str = "x"
    n_windows: str = "n_windows"
    cos_mean: str = "cosine_similarity_mean"
    cos_var: str = "cosine_similarity_var"
    l2_mean: str = "l2_distance_mean"
    l2_var: str = "l2_distance_var"

    @classmethod
    def from_mapping(cls, mapping: dict[str, str] | None) -> "ColumnConfig":
        return cls(**(mapping or {}))

    def rename_to_canonical(self) -> dict[str, str]:
        return {value: key for key, value in self.__dict__.items()}


@dataclass(frozen=True)
class ExperimentConfig:
    """Small-data experiment controls loaded from ``experiment.json``."""

    subjective_variant: str = "no_imaging"
    default_k: float = 0.5
    k_grid: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75, 1.0)
    recommended_k_by_subdir: dict[str, float] = field(default_factory=dict)
    drop_rows: tuple[dict[str, str], ...] = ()
    columns: ColumnConfig = field(default_factory=ColumnConfig)
    ridge_alphas: tuple[float, ...] = (0.1, 1.0, 10.0, 100.0, 1000.0)
    huber_alphas: tuple[float, ...] = (0.1, 1.0, 10.0, 100.0)
    huber_deltas: tuple[float, ...] = (1.0, 1.35, 2.0)
    random_seed: int = 20260716
    material_score_gap: float = 2.0
    near_tie_score_gap: float = 1.0
    model_simplicity_tolerance: float = 0.01

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ExperimentConfig":
        values = dict(payload)
        values["columns"] = ColumnConfig.from_mapping(values.get("columns"))
        for key in ("k_grid", "drop_rows", "ridge_alphas", "huber_alphas", "huber_deltas"):
            if key in values:
                values[key] = tuple(values[key])
        return cls(**values)


def load_json(path: str | Path) -> Any:
    """Read UTF-8 JSON from ``path``."""

    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(payload: Any, path: str | Path) -> None:
    """Write readable UTF-8 JSON, preserving Chinese device names."""

    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8",
    )


def load_experiment(path: str | Path) -> ExperimentConfig:
    """Load an :class:`ExperimentConfig` from JSON."""

    return ExperimentConfig.from_dict(load_json(path))
