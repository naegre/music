"""Metrics and tabular summaries for overall score and ranking models."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import kendalltau, pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error

from .rank_model import overall_preference_probability


def _safe_correlation(function, left: np.ndarray, right: np.ndarray) -> float:
    if len(left) < 2 or np.ptp(left) == 0 or np.ptp(right) == 0:
        return float("nan")
    return float(function(left, right).statistic)


def regression_metrics(y_true, prediction) -> dict[str, float | int]:
    """Numeric score metrics with correlations supplied only for context."""

    y = np.asarray(y_true, dtype=float)
    pred = np.asarray(prediction, dtype=float)
    return {
        "n": int(len(y)),
        "mae": float(mean_absolute_error(y, pred)),
        "rmse": float(np.sqrt(mean_squared_error(y, pred))),
        "bias": float(np.mean(pred - y)),
        "max_abs_error": float(np.max(np.abs(pred - y))),
        "pearson": _safe_correlation(pearsonr, y, pred),
        "spearman": _safe_correlation(spearmanr, y, pred),
        "kendall_tau": _safe_correlation(kendalltau, y, pred),
    }


def soft_pair_metrics(
    targets: np.ndarray,
    probabilities: np.ndarray,
    probability_clip: float = 1e-6,
) -> dict[str, float | int]:
    """Evaluate probabilistic pair predictions against soft preference targets."""

    target = np.asarray(targets, dtype=float)
    probability = np.clip(
        np.asarray(probabilities, dtype=float),
        probability_clip,
        1.0 - probability_clip,
    )
    non_ties = target != 0.5
    accuracy = (
        float(np.mean((probability[non_ties] > 0.5) == (target[non_ties] > 0.5)))
        if non_ties.any()
        else float("nan")
    )
    return {
        "n_pairs": int(len(target)),
        "pairwise_accuracy": accuracy,
        "pairwise_brier": float(np.mean((probability - target) ** 2)),
        "pairwise_log_loss": float(
            np.mean(
                -target * np.log(probability)
                - (1.0 - target) * np.log(1.0 - probability)
            )
        ),
    }


def device_rank_metrics(y_true: np.ndarray, rank_signal: np.ndarray) -> dict[str, float | int]:
    """Rank correlations and hard ordering accuracy at device level."""

    y = np.asarray(y_true, dtype=float)
    signal = np.asarray(rank_signal, dtype=float)
    correct: list[bool] = []
    for left in range(len(y) - 1):
        for right in range(left + 1, len(y)):
            if y[left] == y[right]:
                continue
            correct.append((signal[left] > signal[right]) == (y[left] > y[right]))
    return {
        "n_devices": int(len(y)),
        "spearman": _safe_correlation(spearmanr, y, signal),
        "kendall_tau": _safe_correlation(kendalltau, y, signal),
        "device_pair_accuracy": float(np.mean(correct)) if correct else float("nan"),
    }


def pair_table_from_utilities(
    names: pd.Series | np.ndarray,
    utilities: np.ndarray,
    scores: np.ndarray | None = None,
    probability_per_point: float = 0.1,
) -> pd.DataFrame:
    """Create one row per unordered device pair from common-model utilities."""

    names_array = np.asarray(names).astype(str)
    utility = np.asarray(utilities, dtype=float)
    score_array = None if scores is None else np.asarray(scores, dtype=float)
    rows: list[dict[str, object]] = []
    for left in range(len(names_array) - 1):
        for right in range(left + 1, len(names_array)):
            row: dict[str, object] = {
                "left_name": names_array[left],
                "right_name": names_array[right],
                "left_utility": float(utility[left]),
                "right_utility": float(utility[right]),
                "predicted_probability_left_better": float(
                    expit(utility[left] - utility[right])
                ),
            }
            if score_array is not None:
                difference = float(score_array[left] - score_array[right])
                row.update(
                    {
                        "left_overall": float(score_array[left]),
                        "right_overall": float(score_array[right]),
                        "overall_difference": difference,
                        "target_probability_left_better": float(
                            overall_preference_probability(
                                difference, probability_per_point
                            )
                        ),
                    }
                )
            rows.append(row)
    return pd.DataFrame(rows)


def rank_summary(names: pd.Series | np.ndarray, utilities: np.ndarray) -> pd.DataFrame:
    """Convert utilities to rank, percentile, and expected pairwise win rate."""

    names_array = np.asarray(names).astype(str)
    utility = np.asarray(utilities, dtype=float)
    n_devices = len(utility)
    order = pd.Series(-utility).rank(method="min").to_numpy(dtype=int)
    if n_devices == 1:
        percentile = np.asarray([50.0])
        expected_win_rate = np.asarray([50.0])
    else:
        percentile = 100.0 * (n_devices - order) / (n_devices - 1)
        probabilities = expit(utility[:, None] - utility[None, :])
        expected_win_rate = 100.0 * (
            (probabilities.sum(axis=1) - 0.5) / (n_devices - 1)
        )
    return pd.DataFrame(
        {
            "name": names_array,
            "rank_1_is_best": order,
            "rank_percentile": percentile,
            "expected_pairwise_win_percent": expected_win_rate,
            "rank_utility": utility,
        }
    ).sort_values(["rank_1_is_best", "name"])
