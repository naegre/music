"""Inductive prediction for new PCs using a trusted trained bundle."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from subjective_audio_quality.config import save_json
from subjective_audio_quality.io import write_csv
from subjective_audio_quality.persistence import load_bundle

from .data import (
    apply_replacements,
    load_and_validate_overall,
    load_domains,
    load_submodel_predictions,
    validate_prediction_sources,
)
from .metrics import device_rank_metrics, regression_metrics, soft_pair_metrics
from .uncertainty import monte_carlo_group_predictions


def _new_vs_reference_pairs(
    pairs: pd.DataFrame,
    new_names: set[str],
    reference_names: set[str],
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for row in pairs.itertuples(index=False):
        if row.left_name in new_names and row.right_name in reference_names:
            probability = row.predicted_probability_left_better
            mean = row.probability_mc_mean
            low = row.probability_ci95_low
            high = row.probability_ci95_high
            new_name, reference_name = row.left_name, row.right_name
        elif row.right_name in new_names and row.left_name in reference_names:
            probability = 1.0 - row.predicted_probability_left_better
            mean = 1.0 - row.probability_mc_mean
            low = 1.0 - row.probability_ci95_high
            high = 1.0 - row.probability_ci95_low
            new_name, reference_name = row.right_name, row.left_name
        else:
            continue
        rows.append(
            {
                "new_name": new_name,
                "reference_name": reference_name,
                "P_new_better": float(probability),
                "P_new_better_mc_mean": float(mean),
                "P_new_better_ci95_low": float(low),
                "P_new_better_ci95_high": float(high),
                "ci_source": row.ci_source,
            }
        )
    return pd.DataFrame(rows).sort_values(["new_name", "P_new_better"])


def _attach_neighbors(
    new_rows: pd.DataFrame,
    comparisons: pd.DataFrame,
) -> pd.DataFrame:
    output = new_rows.copy()
    clearly_better: list[str | None] = []
    clearly_worse: list[str | None] = []
    approximate: list[str | None] = []
    for name in output["name"].astype(str):
        group = comparisons[comparisons["new_name"].eq(name)].copy()
        better = group[group["P_new_better"] < 0.4].sort_values(
            "P_new_better", ascending=False
        )
        worse = group[group["P_new_better"] > 0.6].sort_values("P_new_better")
        similar = group[group["P_new_better"].between(0.4, 0.6)].copy()
        if not similar.empty:
            similar["distance_to_half"] = np.abs(similar["P_new_better"] - 0.5)
            similar = similar.sort_values("distance_to_half")
        clearly_better.append(
            None if better.empty else str(better.iloc[0]["reference_name"])
        )
        clearly_worse.append(
            None if worse.empty else str(worse.iloc[0]["reference_name"])
        )
        approximate.append(
            None if similar.empty else str(similar.iloc[0]["reference_name"])
        )
    output["nearest_clearly_better_reference"] = clearly_better
    output["nearest_clearly_worse_reference"] = clearly_worse
    output["approximately_equal_reference"] = approximate
    return output


def predict_new_devices(
    model_path: str | Path,
    overall_data_path: str | Path,
    domains_path: str | Path,
    submodel_predictions_path: str | Path,
    output_dir: str | Path,
    monte_carlo_samples: int | None = None,
    seed: int | None = None,
) -> dict[str, Path]:
    """Predict new PCs and rank them among the bundle's development PC references."""

    bundle = load_bundle(model_path)
    schema = bundle["schema"]
    rules = bundle["replacement_rules"]
    experiment = bundle["experiment"]
    raw = load_and_validate_overall(overall_data_path, schema, require_target=False)
    domains = load_domains(domains_path)
    predictions = load_submodel_predictions(submodel_predictions_path)
    prepared = apply_replacements(raw, domains, predictions, schema, rules)
    if not prepared.frame["domain"].eq("pc").all():
        invalid = prepared.frame.loc[
            prepared.frame["domain"].ne("pc"), "name"
        ].tolist()
        raise ValueError(f"Overall deployment ranking is PC-only; non-PC inputs: {invalid}")
    validate_prediction_sources(
        predictions,
        rules,
        tablet_names=[],
        pc_names=prepared.frame["name"].astype(str).tolist(),
    )
    feature_columns = tuple(bundle["feature_columns"])
    if tuple(prepared.feature_columns) != feature_columns:
        raise ValueError("Prepared feature columns do not match the trained bundle")
    reference = bundle["reference_pc_frame"].copy()
    new_names = set(prepared.frame["name"].astype(str))
    reference_names = set(reference["name"].astype(str))
    overlap = sorted(new_names & reference_names)
    if overlap:
        raise ValueError(f"New device names collide with model references: {overlap}")
    combined = pd.concat(
        [reference, prepared.frame], ignore_index=True, sort=False
    )
    reference_uncertainty = bundle["reference_pc_uncertainty"].copy()
    combined_uncertainty = pd.concat(
        [reference_uncertainty, prepared.uncertainty], axis=0
    ).loc[combined["name"].astype(str), list(feature_columns)]
    samples = int(monte_carlo_samples or experiment.monte_carlo_samples)
    random_seed = int(seed if seed is not None else experiment.random_seed + 31)
    devices, all_pairs = monte_carlo_group_predictions(
        bundle["models"]["score"],
        bundle["models"]["rank"],
        combined,
        combined_uncertainty,
        feature_columns,
        samples,
        random_seed,
    )
    devices["role"] = np.where(
        devices["name"].isin(new_names), "new", "development_pc_reference"
    )
    comparisons = _new_vs_reference_pairs(all_pairs, new_names, reference_names)
    new_devices = devices[devices["role"].eq("new")].copy()
    new_devices = _attach_neighbors(new_devices, comparisons)
    ood_summary, ood_details = bundle["ood_detector"].report(
        prepared.frame[list(feature_columns)], prepared.frame["name"]
    )
    new_devices = new_devices.merge(
        ood_summary, on="name", validate="one_to_one"
    ).sort_values("estimated_rank_1_is_best")
    if schema.target_column in prepared.frame:
        actual = prepared.frame[["name", schema.target_column]]
        new_devices = new_devices.merge(actual, on="name", validate="one_to_one")

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(prepared.frame, output / "prepared_new_features.csv")
    write_csv(new_devices, output / "new_device_rankings.csv")
    write_csv(devices, output / "combined_reference_rankings.csv")
    write_csv(comparisons, output / "new_vs_reference_probabilities.csv")
    write_csv(all_pairs, output / "all_pair_probabilities.csv")
    write_csv(ood_summary, output / "new_device_ood_summary.csv")
    write_csv(ood_details, output / "new_device_ood_details.csv")

    outputs = {
        "new_rankings": output / "new_device_rankings.csv",
        "comparisons": output / "new_vs_reference_probabilities.csv",
        "ood": output / "new_device_ood_summary.csv",
    }
    if schema.target_column in prepared.frame:
        evaluation: dict[str, dict[str, float | int]] = {
            "score": regression_metrics(
                new_devices[schema.target_column], new_devices["predicted_overall"]
            )
        }
        if len(new_devices) >= 2:
            evaluation["rank_devices"] = device_rank_metrics(
                new_devices[schema.target_column], new_devices["rank_utility"]
            )
            score_lookup = prepared.frame.set_index("name")[schema.target_column]
            new_pair_rows = all_pairs[
                all_pairs["left_name"].isin(new_names)
                & all_pairs["right_name"].isin(new_names)
            ].copy()
            if not new_pair_rows.empty:
                target = np.clip(
                    0.5
                    + experiment.overall_probability_per_point
                    * (
                        new_pair_rows["left_name"].map(score_lookup)
                        - new_pair_rows["right_name"].map(score_lookup)
                    ),
                    0.0,
                    1.0,
                )
                evaluation["rank_pairs"] = soft_pair_metrics(
                    target,
                    new_pair_rows["predicted_probability_left_better"],
                    experiment.probability_clip,
                )
        save_json(evaluation, output / "optional_labeled_evaluation.json")
        outputs["evaluation"] = output / "optional_labeled_evaluation.json"
    return outputs
