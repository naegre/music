"""Fold-local robust, semantic-block, and PCA transformations."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA


def robust_scale(values: np.ndarray, epsilon: float = 1e-9) -> tuple[float, float, str]:
    """Return median and MAD/IQR/std scale with a unit fallback."""

    array = np.asarray(values, dtype=float)
    center = float(np.median(array))
    mad = float(1.4826 * np.median(np.abs(array - center)))
    if mad > epsilon:
        return center, mad, "mad"
    q25, q75 = np.quantile(array, [0.25, 0.75])
    iqr = float((q75 - q25) / 1.349)
    if iqr > epsilon:
        return center, iqr, "iqr"
    std = float(np.std(array, ddof=1)) if len(array) > 1 else 0.0
    if std > epsilon:
        return center, std, "std"
    return center, 1.0, "unit"


class OverallPreprocessor:
    """Transform device features with statistics fitted inside one device fold."""

    def __init__(self, mode: str = "robust", n_components: int | None = None):
        self.mode = mode
        self.n_components = n_components

    def fit(
        self,
        x: pd.DataFrame,
        feature_metadata: pd.DataFrame,
    ) -> "OverallPreprocessor":
        self.feature_names_in_ = list(x.columns)
        metadata = feature_metadata.set_index("feature").loc[self.feature_names_in_]
        centers = []
        scales = []
        methods = []
        for column in self.feature_names_in_:
            center, scale, method = robust_scale(x[column].to_numpy(dtype=float))
            centers.append(center)
            scales.append(scale)
            methods.append(method)
        self.center_ = np.asarray(centers, dtype=float)
        self.scale_ = np.asarray(scales, dtype=float)
        self.scale_methods_ = methods
        self.block_factor_ = np.ones(len(self.feature_names_in_), dtype=float)
        if self.mode == "block":
            group_counts = metadata["group"].value_counts().to_dict()
            self.block_factor_ = np.asarray(
                [1.0 / np.sqrt(group_counts[group]) for group in metadata["group"]],
                dtype=float,
            )
        standardized = (
            (x[self.feature_names_in_].to_numpy(dtype=float) - self.center_) / self.scale_
        ) * self.block_factor_
        if self.mode == "pca":
            components = int(self.n_components or 2)
            components = min(components, standardized.shape[0] - 1, standardized.shape[1])
            if components < 1:
                raise ValueError("PCA needs at least two training devices")
            self.pca_ = PCA(n_components=components, random_state=0).fit(standardized)
            self.output_names_ = [f"PC{index + 1}" for index in range(components)]
        elif self.mode in {"robust", "block"}:
            self.pca_ = None
            self.output_names_ = list(self.feature_names_in_)
        else:
            raise ValueError(f"Unknown preprocessing mode: {self.mode}")
        return self

    def transform(self, x: pd.DataFrame) -> np.ndarray:
        """Apply the fitted transform without recomputing any statistics."""

        standardized = (
            (x[self.feature_names_in_].to_numpy(dtype=float) - self.center_) / self.scale_
        ) * self.block_factor_
        if self.pca_ is not None:
            return self.pca_.transform(standardized)
        return standardized

    def fit_transform(self, x: pd.DataFrame, feature_metadata: pd.DataFrame) -> np.ndarray:
        return self.fit(x, feature_metadata).transform(x)

    def raw_feature_coefficients(self, transformed_coefficients: np.ndarray) -> np.ndarray:
        """Back-project model coefficients to original feature units."""

        coefficients = np.asarray(transformed_coefficients, dtype=float)
        if self.pca_ is not None:
            standardized = self.pca_.components_.T @ coefficients
        else:
            standardized = coefficients
        return standardized * self.block_factor_ / self.scale_

    def statistics_frame(self) -> pd.DataFrame:
        """Return fitted robust centers/scales for model auditing."""

        return pd.DataFrame(
            {
                "feature": self.feature_names_in_,
                "center": self.center_,
                "scale": self.scale_,
                "scale_method": self.scale_methods_,
                "block_factor": self.block_factor_,
            }
        )

