"""Nested leave-one-PC-out selection for distinct score and rank models."""

from __future__ import annotations

from dataclasses import asdict

import numpy as np
import pandas as pd

from .metrics import device_rank_metrics, regression_metrics, soft_pair_metrics
from .rank_model import OverallRankPipeline, RankSpec, overall_preference_probability
from .score_model import OverallScorePipeline, ScoreSpec


def _subset(frame: pd.DataFrame, names: list[str]) -> pd.DataFrame:
    indexed = frame.set_index("name", drop=False)
    missing = sorted(set(names) - set(indexed.index.astype(str)))
    if missing:
        raise ValueError(f"Unknown devices requested by validation: {missing}")
    return indexed.loc[names].reset_index(drop=True)


def evaluate_score_spec_loo(
    frame: pd.DataFrame,
    feature_columns: tuple[str, ...],
    feature_metadata: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    target_column: str,
    spec: ScoreSpec,
) -> pd.DataFrame:
    """Generate PC-held-out predictions for one exact score candidate."""

    rows: list[dict[str, object]] = []
    for heldout in pc_names:
        training_names = tablet_names + [name for name in pc_names if name != heldout]
        training = _subset(frame, training_names)
        test = _subset(frame, [heldout])
        model = OverallScorePipeline(spec).fit(
            training[list(feature_columns)],
            training["domain"],
            training[target_column].to_numpy(dtype=float),
            feature_metadata,
        )
        prediction = float(
            model.predict(test[list(feature_columns)], test["domain"])[0]
        )
        actual = float(test[target_column].iloc[0])
        rows.append(
            {
                "name": heldout,
                "actual_overall": actual,
                "predicted_overall": prediction,
                "residual": prediction - actual,
                "selected_spec": spec.label,
            }
        )
    return pd.DataFrame(rows)


def compare_score_candidates(
    frame: pd.DataFrame,
    feature_columns: tuple[str, ...],
    feature_metadata: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    target_column: str,
    candidates: list[ScoreSpec],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Evaluate every exact score candidate using PC leave-one-out."""

    summaries: list[dict[str, object]] = []
    predictions: list[pd.DataFrame] = []
    for spec in candidates:
        fold = evaluate_score_spec_loo(
            frame,
            feature_columns,
            feature_metadata,
            tablet_names,
            pc_names,
            target_column,
            spec,
        )
        metrics = regression_metrics(fold["actual_overall"], fold["predicted_overall"])
        summaries.append({"spec": spec.label, **spec.to_dict(), **metrics})
        predictions.append(fold.assign(candidate_spec=spec.label))
    return pd.DataFrame(summaries).sort_values(["mae", "rmse"]), pd.concat(
        predictions, ignore_index=True
    )


def choose_score_spec(
    comparison: pd.DataFrame,
    candidates: list[ScoreSpec],
    tolerance: float,
    allow_pca: bool = False,
) -> ScoreSpec:
    """Choose a deployable monotone candidate within a small MAE tolerance."""

    lookup = {candidate.label: candidate for candidate in candidates}
    deployable = comparison.copy()
    if not allow_pca:
        deployable = deployable[deployable["preprocessing"].ne("pca")]
    if deployable.empty:
        raise ValueError("No deployable score candidates remain")
    best = float(deployable["mae"].min())
    eligible = deployable[deployable["mae"] <= best + float(tolerance)].copy()
    family_order = {"ridge": 0, "huber": 1}
    preprocessing_order = {"robust": 0, "block": 1, "pca": 9}
    eligible["family_order"] = eligible["family"].map(family_order).fillna(9)
    eligible["preprocessing_order"] = (
        eligible["preprocessing"].map(preprocessing_order).fillna(9)
    )
    eligible = eligible.sort_values(
        ["family_order", "preprocessing_order", "alpha", "mae", "rmse"],
        ascending=[True, True, False, True, True],
    )
    return lookup[str(eligible.iloc[0]["spec"])]


def nested_score_validation(
    frame: pd.DataFrame,
    feature_columns: tuple[str, ...],
    feature_metadata: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    target_column: str,
    candidates: list[ScoreSpec],
    tolerance: float,
    allow_pca: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Select candidates inside each outer held-out-PC fold."""

    outer_rows: list[dict[str, object]] = []
    selection_rows: list[dict[str, object]] = []
    for outer_heldout in pc_names:
        inner_pcs = [name for name in pc_names if name != outer_heldout]
        comparison, _ = compare_score_candidates(
            frame,
            feature_columns,
            feature_metadata,
            tablet_names,
            inner_pcs,
            target_column,
            candidates,
        )
        selected = choose_score_spec(comparison, candidates, tolerance, allow_pca)
        training = _subset(frame, tablet_names + inner_pcs)
        test = _subset(frame, [outer_heldout])
        model = OverallScorePipeline(selected).fit(
            training[list(feature_columns)],
            training["domain"],
            training[target_column].to_numpy(dtype=float),
            feature_metadata,
        )
        prediction = float(
            model.predict(test[list(feature_columns)], test["domain"])[0]
        )
        actual = float(test[target_column].iloc[0])
        outer_rows.append(
            {
                "name": outer_heldout,
                "actual_overall": actual,
                "predicted_overall": prediction,
                "residual": prediction - actual,
                "selected_spec": selected.label,
            }
        )
        selected_summary = comparison.loc[comparison["spec"].eq(selected.label)].iloc[0]
        selection_rows.append(
            {
                "outer_heldout": outer_heldout,
                "selected_spec": selected.label,
                "inner_mae": float(selected_summary["mae"]),
                "inner_rmse": float(selected_summary["rmse"]),
            }
        )
    return pd.DataFrame(outer_rows), pd.DataFrame(selection_rows)


def evaluate_rank_spec_loo(
    frame: pd.DataFrame,
    feature_columns: tuple[str, ...],
    feature_metadata: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    target_column: str,
    spec: RankSpec,
    probability_per_point: float,
    probability_clip: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Predict each held-out PC against the remaining PCs with one candidate."""

    pair_rows: list[dict[str, object]] = []
    device_rows: list[dict[str, object]] = []
    for heldout in pc_names:
        peer_names = [name for name in pc_names if name != heldout]
        training = _subset(frame, tablet_names + peer_names)
        heldout_frame = _subset(frame, [heldout])
        peers = _subset(frame, peer_names)
        model = OverallRankPipeline(
            spec, probability_per_point, probability_clip
        ).fit(
            training[list(feature_columns)],
            training["domain"],
            training[target_column].to_numpy(dtype=float),
            training["name"],
            feature_metadata,
        )
        heldout_utility = float(model.utility(heldout_frame[list(feature_columns)])[0])
        peer_utilities = model.utility(peers[list(feature_columns)])
        probabilities = 1.0 / (1.0 + np.exp(-(heldout_utility - peer_utilities)))
        heldout_score = float(heldout_frame[target_column].iloc[0])
        targets = overall_preference_probability(
            heldout_score - peers[target_column].to_numpy(dtype=float),
            probability_per_point,
        )
        for peer_index, peer_name in enumerate(peer_names):
            pair_rows.append(
                {
                    "heldout_name": heldout,
                    "peer_name": peer_name,
                    "heldout_overall": heldout_score,
                    "peer_overall": float(peers[target_column].iloc[peer_index]),
                    "target_probability_heldout_better": float(targets[peer_index]),
                    "predicted_probability_heldout_better": float(
                        probabilities[peer_index]
                    ),
                    "selected_spec": spec.label,
                }
            )
        device_rows.append(
            {
                "name": heldout,
                "actual_overall": heldout_score,
                "oof_expected_win_percent": float(100.0 * np.mean(probabilities)),
                "selected_spec": spec.label,
            }
        )
    return pd.DataFrame(pair_rows), pd.DataFrame(device_rows)


def compare_rank_candidates(
    frame: pd.DataFrame,
    feature_columns: tuple[str, ...],
    feature_metadata: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    target_column: str,
    candidates: list[RankSpec],
    probability_per_point: float,
    probability_clip: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Evaluate every exact rank candidate using held-out-PC pair predictions."""

    summaries: list[dict[str, object]] = []
    all_pairs: list[pd.DataFrame] = []
    all_devices: list[pd.DataFrame] = []
    for spec in candidates:
        pairs, devices = evaluate_rank_spec_loo(
            frame,
            feature_columns,
            feature_metadata,
            tablet_names,
            pc_names,
            target_column,
            spec,
            probability_per_point,
            probability_clip,
        )
        pair_metrics = soft_pair_metrics(
            pairs["target_probability_heldout_better"],
            pairs["predicted_probability_heldout_better"],
            probability_clip,
        )
        rank_metrics = device_rank_metrics(
            devices["actual_overall"], devices["oof_expected_win_percent"]
        )
        summaries.append(
            {"spec": spec.label, **spec.to_dict(), **pair_metrics, **rank_metrics}
        )
        all_pairs.append(pairs.assign(candidate_spec=spec.label))
        all_devices.append(devices.assign(candidate_spec=spec.label))
    return (
        pd.DataFrame(summaries).sort_values(
            ["pairwise_log_loss", "pairwise_brier"], ignore_index=True
        ),
        pd.concat(all_pairs, ignore_index=True),
        pd.concat(all_devices, ignore_index=True),
    )


def choose_rank_spec(
    comparison: pd.DataFrame,
    candidates: list[RankSpec],
    tolerance: float,
) -> RankSpec:
    """Prefer stronger regularization among candidates near best log loss."""

    lookup = {candidate.label: candidate for candidate in candidates}
    best = float(comparison["pairwise_log_loss"].min())
    eligible = comparison[
        comparison["pairwise_log_loss"] <= best + float(tolerance)
    ].copy()
    preprocessing_order = {"scaled": 0, "block": 1}
    eligible["preprocessing_order"] = (
        eligible["preprocessing"].map(preprocessing_order).fillna(9)
    )
    eligible = eligible.sort_values(
        ["preprocessing_order", "alpha", "pairwise_log_loss", "pairwise_brier"],
        ascending=[True, False, True, True],
    )
    return lookup[str(eligible.iloc[0]["spec"])]


def nested_rank_validation(
    frame: pd.DataFrame,
    feature_columns: tuple[str, ...],
    feature_metadata: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    target_column: str,
    candidates: list[RankSpec],
    probability_per_point: float,
    probability_clip: float,
    tolerance: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Perform rank candidate selection inside each held-out-PC outer fold."""

    outer_pairs: list[pd.DataFrame] = []
    outer_devices: list[dict[str, object]] = []
    selections: list[dict[str, object]] = []
    for outer_heldout in pc_names:
        inner_pcs = [name for name in pc_names if name != outer_heldout]
        comparison, _, _ = compare_rank_candidates(
            frame,
            feature_columns,
            feature_metadata,
            tablet_names,
            inner_pcs,
            target_column,
            candidates,
            probability_per_point,
            probability_clip,
        )
        selected = choose_rank_spec(comparison, candidates, tolerance)
        training = _subset(frame, tablet_names + inner_pcs)
        heldout = _subset(frame, [outer_heldout])
        peers = _subset(frame, inner_pcs)
        model = OverallRankPipeline(
            selected, probability_per_point, probability_clip
        ).fit(
            training[list(feature_columns)],
            training["domain"],
            training[target_column].to_numpy(dtype=float),
            training["name"],
            feature_metadata,
        )
        heldout_utility = float(model.utility(heldout[list(feature_columns)])[0])
        peer_utilities = model.utility(peers[list(feature_columns)])
        probabilities = 1.0 / (1.0 + np.exp(-(heldout_utility - peer_utilities)))
        heldout_score = float(heldout[target_column].iloc[0])
        targets = overall_preference_probability(
            heldout_score - peers[target_column].to_numpy(dtype=float),
            probability_per_point,
        )
        fold_rows = []
        for index, peer_name in enumerate(inner_pcs):
            fold_rows.append(
                {
                    "heldout_name": outer_heldout,
                    "peer_name": peer_name,
                    "heldout_overall": heldout_score,
                    "peer_overall": float(peers[target_column].iloc[index]),
                    "target_probability_heldout_better": float(targets[index]),
                    "predicted_probability_heldout_better": float(
                        probabilities[index]
                    ),
                    "selected_spec": selected.label,
                }
            )
        outer_pairs.append(pd.DataFrame(fold_rows))
        outer_devices.append(
            {
                "name": outer_heldout,
                "actual_overall": heldout_score,
                "oof_expected_win_percent": float(100.0 * np.mean(probabilities)),
                "selected_spec": selected.label,
            }
        )
        selected_summary = comparison.loc[comparison["spec"].eq(selected.label)].iloc[0]
        selections.append(
            {
                "outer_heldout": outer_heldout,
                "selected_spec": selected.label,
                "inner_pairwise_log_loss": float(
                    selected_summary["pairwise_log_loss"]
                ),
                "inner_pairwise_brier": float(selected_summary["pairwise_brier"]),
            }
        )
    return (
        pd.concat(outer_pairs, ignore_index=True),
        pd.DataFrame(outer_devices),
        pd.DataFrame(selections),
    )
