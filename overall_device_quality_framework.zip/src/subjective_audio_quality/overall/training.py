"""End-to-end training orchestration for numeric score and PC rank models."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from subjective_audio_quality.config import save_json
from subjective_audio_quality.io import write_csv
from subjective_audio_quality.persistence import save_bundle

from .config import OverallExperiment, OverallSchema, load_replacement_rules
from .data import (
    apply_replacements,
    create_stratified_split,
    development_names,
    load_and_validate_overall,
    load_and_validate_split,
    load_domains,
    load_submodel_predictions,
    save_split,
    validate_prediction_sources,
)
from .metrics import device_rank_metrics, regression_metrics, soft_pair_metrics
from .ood import RobustOODDetector
from .rank_model import OverallRankPipeline, rank_candidates
from .score_model import OverallScorePipeline, score_candidates
from .uncertainty import monte_carlo_group_predictions
from .validation import (
    choose_rank_spec,
    choose_score_spec,
    compare_rank_candidates,
    compare_score_candidates,
    nested_rank_validation,
    nested_score_validation,
)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _metric_frame(section: str, metrics: dict[str, object]) -> pd.DataFrame:
    return pd.DataFrame(
        [{"section": section, "metric": key, "value": value} for key, value in metrics.items()]
    )


def _prepare_split(
    split_path: Path,
    frame: pd.DataFrame,
    experiment: OverallExperiment,
    target_column: str,
) -> dict[str, object]:
    if split_path.exists():
        return load_and_validate_split(split_path, frame)
    split = create_stratified_split(
        frame,
        target_column,
        experiment.pc_development_count,
        experiment.random_seed,
    )
    save_split(split, split_path)
    return split


def train_overall_models(
    overall_data_path: str | Path,
    domains_path: str | Path,
    submodel_predictions_path: str | Path,
    schema_path: str | Path,
    replacements_path: str | Path,
    experiment_path: str | Path,
    split_path: str | Path,
    output_dir: str | Path,
    model_dir: str | Path,
) -> dict[str, Path]:
    """Train, validate, externally audit, and persist both overall models."""

    output = Path(output_dir)
    models = Path(model_dir)
    output.mkdir(parents=True, exist_ok=True)
    models.mkdir(parents=True, exist_ok=True)
    schema = OverallSchema.load(schema_path)
    rules = load_replacement_rules(replacements_path)
    experiment = OverallExperiment.load(experiment_path)
    raw = load_and_validate_overall(overall_data_path, schema, require_target=True)
    domains = load_domains(domains_path)
    predictions = load_submodel_predictions(submodel_predictions_path)
    prepared = apply_replacements(raw, domains, predictions, schema, rules)
    split = _prepare_split(
        Path(split_path), prepared.frame, experiment, schema.target_column
    )
    tablet_names = list(map(str, split["tablet_development"]))
    pc_development = list(map(str, split["pc_development"]))
    pc_external = list(map(str, split["pc_external"]))
    validate_prediction_sources(
        predictions,
        rules,
        tablet_names,
        pc_development + pc_external,
    )
    development = development_names(split)
    frame = prepared.frame.copy()
    feature_columns = prepared.feature_columns
    metadata = prepared.feature_metadata

    write_csv(frame, output / "prepared_features.csv")
    write_csv(metadata, output / "feature_metadata.csv")
    write_csv(prepared.replacement_audit, output / "replacement_audit.csv")
    write_csv(prepared.uncertainty.reset_index(), output / "feature_uncertainty.csv")
    save_json(split, output / "frozen_split_copy.json")

    score_specs = score_candidates(
        experiment.score_ridge_alphas,
        experiment.score_huber_alphas,
        experiment.pca_components,
        experiment.score_huber_delta,
    )
    score_nested, score_nested_selection = nested_score_validation(
        frame,
        feature_columns,
        metadata,
        tablet_names,
        pc_development,
        schema.target_column,
        score_specs,
        experiment.score_simplicity_tolerance,
        experiment.allow_pca_deployment,
    )
    score_nested_metrics = regression_metrics(
        score_nested["actual_overall"], score_nested["predicted_overall"]
    )
    score_comparison, score_candidate_predictions = compare_score_candidates(
        frame,
        feature_columns,
        metadata,
        tablet_names,
        pc_development,
        schema.target_column,
        score_specs,
    )
    selected_score_spec = choose_score_spec(
        score_comparison,
        score_specs,
        experiment.score_simplicity_tolerance,
        experiment.allow_pca_deployment,
    )
    score_comparison["selected_final"] = score_comparison["spec"].eq(
        selected_score_spec.label
    )
    score_comparison["deployable"] = experiment.allow_pca_deployment | score_comparison[
        "preprocessing"
    ].ne("pca")
    development_frame = frame.set_index("name").loc[development].reset_index()
    score_model = OverallScorePipeline(selected_score_spec).fit(
        development_frame[list(feature_columns)],
        development_frame["domain"],
        development_frame[schema.target_column].to_numpy(dtype=float),
        metadata,
    )

    rank_specs = rank_candidates(experiment.rank_alphas)
    rank_nested_pairs, rank_nested_devices, rank_nested_selection = (
        nested_rank_validation(
            frame,
            feature_columns,
            metadata,
            tablet_names,
            pc_development,
            schema.target_column,
            rank_specs,
            experiment.overall_probability_per_point,
            experiment.probability_clip,
            experiment.rank_simplicity_tolerance,
        )
    )
    rank_nested_pair_metrics = soft_pair_metrics(
        rank_nested_pairs["target_probability_heldout_better"],
        rank_nested_pairs["predicted_probability_heldout_better"],
        experiment.probability_clip,
    )
    rank_nested_device_metrics = device_rank_metrics(
        rank_nested_devices["actual_overall"],
        rank_nested_devices["oof_expected_win_percent"],
    )
    rank_comparison, rank_candidate_pairs, rank_candidate_devices = (
        compare_rank_candidates(
            frame,
            feature_columns,
            metadata,
            tablet_names,
            pc_development,
            schema.target_column,
            rank_specs,
            experiment.overall_probability_per_point,
            experiment.probability_clip,
        )
    )
    selected_rank_spec = choose_rank_spec(
        rank_comparison, rank_specs, experiment.rank_simplicity_tolerance
    )
    rank_comparison["selected_final"] = rank_comparison["spec"].eq(
        selected_rank_spec.label
    )
    rank_model = OverallRankPipeline(
        selected_rank_spec,
        experiment.overall_probability_per_point,
        experiment.probability_clip,
    ).fit(
        development_frame[list(feature_columns)],
        development_frame["domain"],
        development_frame[schema.target_column].to_numpy(dtype=float),
        development_frame["name"],
        metadata,
    )

    ood_detector = RobustOODDetector(experiment.ood_z_threshold).fit(
        development_frame[list(feature_columns)], development_frame["domain"]
    )
    external_frame = frame.set_index("name").loc[pc_external].reset_index()
    external_devices, external_pairs = monte_carlo_group_predictions(
        score_model,
        rank_model,
        external_frame,
        prepared.uncertainty,
        feature_columns,
        experiment.monte_carlo_samples,
        experiment.random_seed + 17,
    )
    external_devices = external_devices.merge(
        external_frame[["name", schema.target_column]], on="name", validate="one_to_one"
    )
    external_score_metrics = regression_metrics(
        external_devices[schema.target_column], external_devices["predicted_overall"]
    )
    external_rank_device_metrics = device_rank_metrics(
        external_devices[schema.target_column], external_devices["rank_utility"]
    )
    score_lookup = external_frame.set_index("name")[schema.target_column].to_dict()
    external_pairs["left_overall"] = external_pairs["left_name"].map(score_lookup)
    external_pairs["right_overall"] = external_pairs["right_name"].map(score_lookup)
    external_pairs["target_probability_left_better"] = np.clip(
        0.5
        + experiment.overall_probability_per_point
        * (external_pairs["left_overall"] - external_pairs["right_overall"]),
        0.0,
        1.0,
    )
    external_rank_pair_metrics = soft_pair_metrics(
        external_pairs["target_probability_left_better"],
        external_pairs["predicted_probability_left_better"],
        experiment.probability_clip,
    )
    ood_summary, ood_details = ood_detector.report(
        external_frame[list(feature_columns)], external_frame["name"]
    )
    external_devices = external_devices.merge(
        ood_summary, on="name", validate="one_to_one"
    ).sort_values("estimated_rank_1_is_best")

    write_csv(score_nested, output / "score_nested_oof.csv")
    write_csv(score_nested_selection, output / "score_nested_selections.csv")
    write_csv(score_comparison, output / "score_candidate_comparison.csv")
    write_csv(
        score_candidate_predictions, output / "score_candidate_oof_predictions.csv"
    )
    write_csv(score_model.coefficient_frame(), output / "score_coefficients.csv")
    write_csv(rank_nested_pairs, output / "rank_nested_oof_pairs.csv")
    write_csv(rank_nested_devices, output / "rank_nested_oof_devices.csv")
    write_csv(rank_nested_selection, output / "rank_nested_selections.csv")
    write_csv(rank_comparison, output / "rank_candidate_comparison.csv")
    write_csv(rank_candidate_pairs, output / "rank_candidate_oof_pairs.csv")
    write_csv(rank_candidate_devices, output / "rank_candidate_oof_devices.csv")
    write_csv(rank_model.coefficient_frame(), output / "rank_coefficients.csv")
    write_csv(external_devices, output / "external_pc_predictions.csv")
    write_csv(external_pairs, output / "external_pc_pair_probabilities.csv")
    write_csv(ood_summary, output / "external_ood_summary.csv")
    write_csv(ood_details, output / "external_ood_details.csv")

    metrics = {
        "score_nested_pc_loo": score_nested_metrics,
        "rank_nested_pc_loo_pairs": rank_nested_pair_metrics,
        "rank_nested_pc_loo_devices": rank_nested_device_metrics,
        "external_pc_score": external_score_metrics,
        "external_pc_rank_pairs": external_rank_pair_metrics,
        "external_pc_rank_devices": external_rank_device_metrics,
    }
    metric_frames = [
        _metric_frame(section, values) for section, values in metrics.items()
    ]
    write_csv(pd.concat(metric_frames, ignore_index=True), output / "metrics.csv")
    save_json(_json_safe(metrics), output / "metrics.json")
    leakage_audit = {
        "robust_scaling": "fitted inside every score fold",
        "rank_feature_scaling": "fitted inside every rank fold",
        "candidate_selection": "inner leave-one-PC-out inside each outer PC fold",
        "external_pc_use": "never used for fitting or candidate selection",
        "replacement_predictions": (
            "tablets must use submodel OOF predictions; PCs use inductive predictions"
        ),
        "ranking_pairs": "within-domain only; no tablet-PC pairs",
        "pca": (
            "diagnostic fold-local candidate; deployment disabled"
            if not experiment.allow_pca_deployment
            else "fold-local and eligible for deployment"
        ),
        "uncertainty": "used only for Monte Carlo intervals, never as quality input",
    }
    save_json(leakage_audit, output / "leakage_audit.json")

    reference_pc = development_frame[development_frame["domain"].eq("pc")].copy()
    reference_uncertainty = prepared.uncertainty.loc[
        reference_pc["name"].astype(str), list(feature_columns)
    ].copy()
    metadata_payload = {
        "bundle_type": "overall_score_and_pc_rank",
        "schema_version": 1,
        "selected_score_spec": selected_score_spec.to_dict(),
        "selected_rank_spec": selected_rank_spec.to_dict(),
        "feature_columns": list(feature_columns),
        "development_devices": development,
        "pc_reference_devices": reference_pc["name"].astype(str).tolist(),
        "external_devices": pc_external,
        "probability_rule": {
            "formula": "clip(0.5 + 0.1 * (overall_A - overall_B), 0, 1)",
            "probability_per_point": experiment.overall_probability_per_point,
        },
        "ci_source": "submodel prediction_se only",
        "synthetic_warning": (
            "Metrics are framework checks only when trained on generated synthetic data."
        ),
    }
    bundle = {
        "models": {"score": score_model, "rank": rank_model},
        "ood_detector": ood_detector,
        "schema": schema,
        "replacement_rules": rules,
        "feature_columns": feature_columns,
        "feature_metadata": metadata,
        "reference_pc_frame": reference_pc[
            ["name", "domain", *feature_columns, schema.target_column]
        ].copy(),
        "reference_pc_uncertainty": reference_uncertainty,
        "experiment": experiment,
        "metadata": metadata_payload,
    }
    model_path = models / "overall_model_bundle.joblib"
    metadata_path = models / "overall_model_metadata.json"
    save_bundle(bundle, model_path, metadata_path)
    return {
        "model": model_path,
        "metadata": metadata_path,
        "metrics": output / "metrics.json",
        "external_predictions": output / "external_pc_predictions.csv",
        "external_pairs": output / "external_pc_pair_probabilities.csv",
    }
