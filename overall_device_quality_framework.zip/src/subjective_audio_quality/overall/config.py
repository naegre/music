"""Typed configuration for the overall modelling subsystem."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from subjective_audio_quality.config import load_json


@dataclass(frozen=True)
class OverallSchema:
    """Column contract for one-row-per-device overall data."""

    name_column: str
    target_column: str
    subjective_suffix: str
    feature_columns: tuple[str, ...]

    @classmethod
    def load(cls, path: str | Path) -> "OverallSchema":
        payload = load_json(path)
        payload["feature_columns"] = tuple(payload["feature_columns"])
        return cls(**payload)


@dataclass(frozen=True)
class ReplacementRule:
    """Replace one or more raw columns with one submodel percentile."""

    key: str
    replace: tuple[str, ...]
    prediction_column: str = "predicted_percentile"
    uncertainty_column: str = "prediction_se"
    required: bool = True


def load_replacement_rules(path: str | Path) -> tuple[ReplacementRule, ...]:
    """Read and validate replacement rules from JSON."""

    payload = load_json(path)
    rules = []
    used_columns: set[str] = set()
    for key, values in payload.items():
        replace = tuple(map(str, values["replace"]))
        overlap = used_columns & set(replace)
        if overlap:
            raise ValueError(f"Raw columns occur in multiple replacement rules: {sorted(overlap)}")
        used_columns.update(replace)
        rules.append(
            ReplacementRule(
                key=str(key),
                replace=replace,
                prediction_column=str(values.get("prediction_column", "predicted_percentile")),
                uncertainty_column=str(values.get("uncertainty_column", "prediction_se")),
                required=bool(values.get("required", True)),
            )
        )
    return tuple(rules)


@dataclass(frozen=True)
class OverallExperiment:
    """Finite model grids and validation settings."""

    random_seed: int = 20260721
    pc_development_count: int = 5
    score_ridge_alphas: tuple[float, ...] = (0.1, 1.0, 10.0, 100.0)
    score_huber_alphas: tuple[float, ...] = (1.0, 10.0)
    score_huber_delta: float = 1.35
    pca_components: tuple[int, ...] = (2, 3, 4)
    allow_pca_deployment: bool = False
    rank_alphas: tuple[float, ...] = (0.01, 0.1, 1.0, 10.0, 100.0)
    score_simplicity_tolerance: float = 0.5
    rank_simplicity_tolerance: float = 0.01
    overall_probability_per_point: float = 0.1
    probability_clip: float = 1e-6
    monte_carlo_samples: int = 500
    ood_z_threshold: float = 3.5

    @classmethod
    def load(cls, path: str | Path) -> "OverallExperiment":
        payload = load_json(path)
        for field in (
            "score_ridge_alphas",
            "score_huber_alphas",
            "pca_components",
            "rank_alphas",
        ):
            payload[field] = tuple(payload[field])
        return cls(**payload)
