"""Deterministic synthetic data matching the user's eventual overall tables."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from subjective_audio_quality.config import save_json
from subjective_audio_quality.io import write_csv

from .config import OverallSchema, ReplacementRule
from .data import create_stratified_split, save_split


TABLET_NAMES = (
    "ipad",
    "AGS6",
    "DBY2",
    "DBYR",
    "PCE",
    "QXS",
    "tagore",
    "VivoPad3",
    "iPadPro13",
    "ipadPro2021",
    "ipadPro2022",
    "oppoPad2",
    "vivoPad2",
    "xiaomiPad7Ultra",
    "Magicpad13",
)

PC_NAMES = (
    "PC_Atlas",
    "PC_Boreal",
    "PC_Cinder",
    "PC_Delta",
    "PC_Echo",
    "PC_Flux",
    "PC_Grove",
    "PC_Halo",
    "PC_Ion",
    "PC_Juniper",
    "PC_Kilo",
)

IPAD_VALUES = (
    79.6,
    85.0,
    80.125,
    92.975,
    96.521,
    98.085,
    85.344,
    83.980,
    96.592,
    92.458,
    85.0,
    90.035,
    85.0,
    85.0,
    103.920,
    85.0,
    85.0,
    85.0,
    85.0,
    85.0,
    90.0,
    85.0,
)


def _feature_group(column: str) -> str:
    return column.split("_", 1)[0]


def generate_synthetic_dataset(
    output_dir: str | Path,
    schema: OverallSchema,
    rules: tuple[ReplacementRule, ...],
    seed: int = 20260721,
    pc_development_count: int = 5,
) -> dict[str, Path]:
    """Create 15 tablets, 11 PCs, replacement predictions, and a frozen split.

    The ``ipad`` row exactly preserves the 22 values and ``overall=94.55``
    supplied by the user. Every other row is artificial and must never be
    interpreted as measured model performance.
    """

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    names = list(TABLET_NAMES + PC_NAMES)
    domains = np.asarray(["tablet"] * len(TABLET_NAMES) + ["pc"] * len(PC_NAMES))
    n_devices = len(names)
    latent = rng.normal(0.0, 1.0, n_devices)
    latent += np.where(domains == "pc", -0.25, 0.15)
    latent[0] = 1.55
    groups = sorted({_feature_group(column) for column in schema.feature_columns})
    group_noise = {
        group: 1.8 * rng.normal(size=n_devices) for group in groups
    }
    base_by_group = {
        "loudness": 80.0,
        "dynamics": 84.0,
        "timber": 88.0,
        "treble": 86.0,
        "edginess": 83.0,
        "balance": 89.0,
        "fullness": 87.0,
        "clarity": 87.0,
        "spatial": 86.0,
        "artefacts": 88.0,
    }
    data: dict[str, np.ndarray | list[str]] = {"name": names}
    for feature_index, column in enumerate(schema.feature_columns):
        group = _feature_group(column)
        feature_offset = rng.normal(0.0, 2.0)
        loading = rng.uniform(4.5, 8.0)
        values = (
            base_by_group.get(group, 85.0)
            + feature_offset
            + loading * latent
            + group_noise[group]
            + rng.normal(0.0, 2.2, n_devices)
        )
        if column.endswith(schema.subjective_suffix):
            values = 85.0 + 0.72 * (values - 85.0)
        data[column] = values
    frame = pd.DataFrame(data)
    quality_summary = frame[list(schema.feature_columns)].apply(
        lambda column: (column - column.median()) / max(column.std(ddof=1), 1e-6)
    ).mean(axis=1)
    overall = (
        83.0
        + 5.8 * latent
        + 2.2 * quality_summary.to_numpy(dtype=float)
        + rng.normal(0.0, 1.1, n_devices)
    )
    frame[schema.target_column] = np.clip(overall, 55.0, 99.0)
    frame.loc[frame["name"].eq("ipad"), list(schema.feature_columns)] = np.asarray(
        IPAD_VALUES, dtype=float
    )
    frame.loc[frame["name"].eq("ipad"), schema.target_column] = 94.55
    frame[list(schema.feature_columns) + [schema.target_column]] = frame[
        list(schema.feature_columns) + [schema.target_column]
    ].round(4)

    domain_frame = pd.DataFrame({"name": names, "domain": domains})
    prediction_rows: list[dict[str, object]] = []
    for rule in rules:
        raw_signal = frame[list(rule.replace)].mean(axis=1)
        percentile = raw_signal.rank(method="average", pct=True).to_numpy() * 100.0
        percentile = np.clip(percentile + rng.normal(0.0, 2.5, n_devices), 0.0, 100.0)
        standard_error = rng.uniform(1.2, 4.5, n_devices)
        for index, name in enumerate(names):
            prediction_rows.append(
                {
                    "name": name,
                    "subdir": rule.key,
                    "predicted_percentile": round(float(percentile[index]), 4),
                    "prediction_se": round(float(standard_error[index]), 4),
                    "prediction_ci95_low": round(
                        float(max(0.0, percentile[index] - 1.96 * standard_error[index])),
                        4,
                    ),
                    "prediction_ci95_high": round(
                        float(min(100.0, percentile[index] + 1.96 * standard_error[index])),
                        4,
                    ),
                    "prediction_source": "oof" if domains[index] == "tablet" else "inductive",
                }
            )
    predictions = pd.DataFrame(prediction_rows)
    split_frame = frame[["name", schema.target_column]].merge(
        domain_frame, on="name", validate="one_to_one"
    )
    split = create_stratified_split(
        split_frame,
        schema.target_column,
        pc_development_count,
        seed,
    )

    paths = {
        "overall_data": output / "overall_features.csv",
        "domains": output / "device_domains.csv",
        "submodel_predictions": output / "submodel_predictions.csv",
        "prediction_overall_data": output / "prediction_pc_features.csv",
        "prediction_domains": output / "prediction_pc_domains.csv",
        "prediction_submodel_predictions": output / "prediction_pc_submodels.csv",
        "split": output / "split.json",
        "manifest": output / "SYNTHETIC_DATA_MANIFEST.json",
    }
    write_csv(frame, paths["overall_data"])
    write_csv(domain_frame, paths["domains"])
    write_csv(predictions, paths["submodel_predictions"])
    external_names = set(map(str, split["pc_external"]))
    write_csv(
        frame[frame["name"].isin(external_names)].reset_index(drop=True),
        paths["prediction_overall_data"],
    )
    write_csv(
        domain_frame[domain_frame["name"].isin(external_names)].reset_index(drop=True),
        paths["prediction_domains"],
    )
    write_csv(
        predictions[predictions["name"].isin(external_names)].reset_index(drop=True),
        paths["prediction_submodel_predictions"],
    )
    save_split(split, paths["split"])
    save_json(
        {
            "synthetic": True,
            "seed": seed,
            "n_tablets": len(TABLET_NAMES),
            "n_pcs": len(PC_NAMES),
            "pc_development_count": pc_development_count,
            "warning": "Only the ipad row was user-supplied; all other values are artificial.",
            "files": {key: path.name for key, path in paths.items() if key != "manifest"},
        },
        paths["manifest"],
    )
    return paths
