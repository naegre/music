"""Bounded overall score regression with nested PC-oriented validation."""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd
from scipy.optimize import lsq_linear, minimize
from sklearn.metrics import mean_absolute_error, mean_squared_error

from .data import domain_balanced_weights
from .preprocessing import OverallPreprocessor, robust_scale


@dataclass(frozen=True)
class ScoreSpec:
    """One finite score model candidate."""

    family: str
    preprocessing: str
    alpha: float
    n_components: int | None = None
    delta: float = 1.35

    @property
    def label(self) -> str:
        components = f"_pc{self.n_components}" if self.n_components else ""
        return f"{self.family}_{self.preprocessing}{components}_alpha{self.alpha:g}"

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class WeightedDomainRegressor:
    """Quality coefficients plus an unconstrained PC offset and intercept."""

    def __init__(
        self,
        family: str,
        alpha: float,
        positive_quality: bool,
        delta: float = 1.35,
    ):
        self.family = family
        self.alpha = float(alpha)
        self.positive_quality = bool(positive_quality)
        self.delta = float(delta)

    def fit(
        self,
        z: np.ndarray,
        domains: pd.Series | np.ndarray,
        y: np.ndarray,
        sample_weight: np.ndarray,
    ) -> "WeightedDomainRegressor":
        z = np.asarray(z, dtype=float)
        y = np.asarray(y, dtype=float)
        weights = np.asarray(sample_weight, dtype=float)
        is_pc = (np.asarray(domains).astype(str) == "pc").astype(float)
        design = np.column_stack([z, is_pc, np.ones(len(z))])
        n_quality = z.shape[1]
        lower = np.full(design.shape[1], -np.inf)
        if self.positive_quality:
            lower[:n_quality] = 0.0
        upper = np.full(design.shape[1], np.inf)

        if self.family == "ridge":
            weighted_design = design * np.sqrt(weights)[:, None]
            weighted_target = y * np.sqrt(weights)
            penalty = np.sqrt(self.alpha) * np.eye(design.shape[1])
            penalty[-1, -1] = 0.0
            augmented_x = np.vstack([weighted_design, penalty])
            augmented_y = np.concatenate([weighted_target, np.zeros(design.shape[1])])
            result = lsq_linear(augmented_x, augmented_y, bounds=(lower, upper))
            parameters = result.x
            self.optimization_success_ = bool(result.success)
        elif self.family == "huber":
            _, target_scale, _ = robust_scale(y)
            threshold = max(self.delta * target_scale, 1e-6)

            def objective(parameters):
                residual = design @ parameters - y
                absolute = np.abs(residual)
                quadratic = absolute <= threshold
                loss = np.where(
                    quadratic,
                    0.5 * residual**2,
                    threshold * (absolute - 0.5 * threshold),
                )
                psi = np.where(quadratic, residual, threshold * np.sign(residual))
                penalty_value = 0.5 * self.alpha * np.dot(parameters[:-1], parameters[:-1])
                value = float(np.dot(weights, loss) + penalty_value)
                gradient = design.T @ (weights * psi)
                gradient[:-1] += self.alpha * parameters[:-1]
                return value, gradient

            initial = np.zeros(design.shape[1], dtype=float)
            initial[-1] = float(np.average(y, weights=weights))
            bounds = list(zip(lower, upper, strict=True))
            result = minimize(
                objective,
                initial,
                method="L-BFGS-B",
                jac=True,
                bounds=bounds,
                options={"maxiter": 5000},
            )
            parameters = result.x
            self.optimization_success_ = bool(result.success)
        else:
            raise ValueError(f"Unknown score family: {self.family}")
        self.quality_coef_ = parameters[:n_quality]
        self.pc_offset_ = float(parameters[n_quality])
        self.intercept_ = float(parameters[n_quality + 1])
        return self

    def predict(self, z: np.ndarray, domains: pd.Series | np.ndarray) -> np.ndarray:
        is_pc = (np.asarray(domains).astype(str) == "pc").astype(float)
        return np.asarray(z, dtype=float) @ self.quality_coef_ + self.pc_offset_ * is_pc + self.intercept_


class OverallScorePipeline:
    """Serializable fold-local preprocessing and bounded score predictor."""

    def __init__(self, spec: ScoreSpec):
        self.spec = spec

    def fit(
        self,
        x: pd.DataFrame,
        domains: pd.Series,
        y: np.ndarray,
        feature_metadata: pd.DataFrame,
    ) -> "OverallScorePipeline":
        self.preprocessor_ = OverallPreprocessor(
            self.spec.preprocessing, self.spec.n_components
        )
        z = self.preprocessor_.fit_transform(x, feature_metadata)
        positive = self.spec.preprocessing != "pca"
        self.regressor_ = WeightedDomainRegressor(
            self.spec.family,
            self.spec.alpha,
            positive_quality=positive,
            delta=self.spec.delta,
        ).fit(z, domains, np.asarray(y, dtype=float), domain_balanced_weights(domains))
        self.feature_metadata_ = feature_metadata.copy()
        return self

    def predict(self, x: pd.DataFrame, domains: pd.Series) -> np.ndarray:
        raw = self.regressor_.predict(self.preprocessor_.transform(x), domains)
        return np.clip(raw, 0.0, 100.0)

    def coefficient_frame(self) -> pd.DataFrame:
        raw = self.preprocessor_.raw_feature_coefficients(self.regressor_.quality_coef_)
        return pd.DataFrame(
            {
                "feature": self.preprocessor_.feature_names_in_,
                "coefficient_original_units": raw,
                "preprocessing": self.spec.preprocessing,
            }
        )


def score_candidates(
    ridge_alphas: tuple[float, ...],
    huber_alphas: tuple[float, ...],
    pca_components: tuple[int, ...],
    huber_delta: float,
) -> list[ScoreSpec]:
    """Build robust, block-equalized, Huber, and fold-local PCA candidates."""

    candidates = []
    for alpha in ridge_alphas:
        candidates.append(ScoreSpec("ridge", "robust", alpha))
        candidates.append(ScoreSpec("ridge", "block", alpha))
    for alpha in huber_alphas:
        candidates.append(ScoreSpec("huber", "robust", alpha, delta=huber_delta))
    for components in pca_components:
        for alpha in ridge_alphas:
            candidates.append(ScoreSpec("ridge", "pca", alpha, n_components=components))
    return candidates


def score_metrics(y_true, prediction) -> dict[str, float | int]:
    """Score-only metrics; ranking metrics do not select this model."""

    y = np.asarray(y_true, dtype=float)
    pred = np.asarray(prediction, dtype=float)
    return {
        "n": int(len(y)),
        "mae": float(mean_absolute_error(y, pred)),
        "rmse": float(np.sqrt(mean_squared_error(y, pred))),
        "bias": float(np.mean(pred - y)),
        "max_abs_error": float(np.max(np.abs(pred - y))),
    }
