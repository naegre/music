from __future__ import annotations

import json

import joblib
import numpy as np
import pandas as pd
import pytest

from subjective_audio_quality.config import save_json
from subjective_audio_quality.overall.config import (
    OverallExperiment,
    OverallSchema,
    load_replacement_rules,
)
from subjective_audio_quality.overall.data import (
    apply_replacements,
    load_and_validate_overall,
    load_domains,
    load_submodel_predictions,
    validate_prediction_sources,
)
from subjective_audio_quality.overall.prediction import predict_new_devices
from subjective_audio_quality.overall.rank_model import (
    OverallRankPipeline,
    RankSpec,
    make_within_domain_pairs,
)
from subjective_audio_quality.overall.synthetic import IPAD_VALUES, generate_synthetic_dataset
from subjective_audio_quality.overall.training import train_overall_models


ROOT = __import__("pathlib").Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "configs/feature_schema.json"
RULES_PATH = ROOT / "configs/replacement_map.json"
EXPERIMENT_PATH = ROOT / "configs/experiment.json"


def _generate(tmp_path):
    schema = OverallSchema.load(SCHEMA_PATH)
    rules = load_replacement_rules(RULES_PATH)
    experiment = OverallExperiment.load(EXPERIMENT_PATH)
    paths = generate_synthetic_dataset(
        tmp_path / "data",
        schema,
        rules,
        experiment.random_seed,
        experiment.pc_development_count,
    )
    return schema, rules, paths


def test_synthetic_schema_and_exact_ipad_row(tmp_path):
    schema, _, paths = _generate(tmp_path)
    frame = pd.read_csv(paths["overall_data"])
    assert frame.shape == (26, 24)
    assert list(frame.columns) == ["name", *schema.feature_columns, "overall"]
    ipad = frame.set_index("name").loc["ipad"]
    np.testing.assert_allclose(
        ipad[list(schema.feature_columns)].to_numpy(dtype=float),
        np.asarray(IPAD_VALUES),
    )
    assert ipad["overall"] == pytest.approx(94.55)
    split = json.loads(paths["split"].read_text(encoding="utf-8"))
    assert len(split["tablet_development"]) == 15
    assert len(split["pc_development"]) == 5
    assert len(split["pc_external"]) == 6


def test_replacement_collapses_groups_and_rejects_missing_prediction(tmp_path):
    schema, rules, paths = _generate(tmp_path)
    overall = load_and_validate_overall(paths["overall_data"], schema)
    domains = load_domains(paths["domains"])
    predictions = load_submodel_predictions(paths["submodel_predictions"])
    prepared = apply_replacements(overall, domains, predictions, schema, rules)
    assert len(prepared.feature_columns) == 19
    assert "clarity_1_S" not in prepared.feature_columns
    assert "clarity__predicted_percentile" in prepared.feature_columns
    missing = predictions[
        ~(
            predictions["name"].eq("ipad")
            & predictions["subdir"].eq("clarity")
        )
    ]
    with pytest.raises(ValueError, match="missing devices"):
        apply_replacements(overall, domains, missing, schema, rules)
    unsafe = predictions.copy()
    unsafe.loc[
        unsafe["name"].eq("ipad") & unsafe["subdir"].eq("clarity"),
        "prediction_source",
    ] = "inductive"
    with pytest.raises(ValueError, match="Unsafe submodel prediction sources"):
        validate_prediction_sources(
            unsafe,
            rules,
            tablet_names=["ipad"],
            pc_names=[],
        )


def test_pair_builder_never_crosses_domains_and_rank_is_monotone():
    z = np.asarray([[0.0, 1.0], [1.0, 1.0], [2.0, 2.0], [3.0, 2.0]])
    y = np.asarray([70.0, 72.0, 75.0, 78.0])
    names = np.asarray(["t1", "t2", "p1", "p2"])
    domains = np.asarray(["tablet", "tablet", "pc", "pc"])
    pairs = make_within_domain_pairs(z, y, names, domains, 0.1)
    assert len(pairs["targets"]) == 2
    assert set(pairs["domains"]) == {"tablet", "pc"}

    x = pd.DataFrame(z, columns=["f1", "f2"])
    metadata = pd.DataFrame(
        {
            "feature": ["f1", "f2"],
            "subjective": [False, True],
            "group": ["g1", "g2"],
        }
    )
    model = OverallRankPipeline(RankSpec(alpha=1.0)).fit(
        x, pd.Series(domains), y, pd.Series(names), metadata
    )
    assert np.all(model.ranker_.coef_ >= 0.0)


def test_reduced_grid_end_to_end_train_and_predict(tmp_path):
    schema, _, paths = _generate(tmp_path)
    experiment = {
        "random_seed": 20260721,
        "pc_development_count": 5,
        "score_ridge_alphas": [1.0],
        "score_huber_alphas": [1.0],
        "score_huber_delta": 1.35,
        "pca_components": [2],
        "allow_pca_deployment": False,
        "rank_alphas": [1.0],
        "score_simplicity_tolerance": 0.5,
        "rank_simplicity_tolerance": 0.01,
        "overall_probability_per_point": 0.1,
        "probability_clip": 1e-6,
        "monte_carlo_samples": 20,
        "ood_z_threshold": 3.5,
    }
    experiment_path = tmp_path / "experiment.json"
    save_json(experiment, experiment_path)
    outputs = train_overall_models(
        paths["overall_data"],
        paths["domains"],
        paths["submodel_predictions"],
        SCHEMA_PATH,
        RULES_PATH,
        experiment_path,
        paths["split"],
        tmp_path / "train_results",
        tmp_path / "models",
    )
    assert outputs["model"].exists()
    bundle = joblib.load(outputs["model"])
    assert np.all(bundle["models"]["score"].regressor_.quality_coef_ >= 0.0)
    assert np.all(bundle["models"]["rank"].ranker_.coef_ >= 0.0)
    assert bundle["models"]["rank"].training_pair_counts_ == {
        "pc": 10,
        "tablet": 105,
    }
    nested = pd.read_csv(tmp_path / "train_results/score_nested_oof.csv")
    external = pd.read_csv(tmp_path / "train_results/external_pc_predictions.csv")
    assert len(nested) == 5
    assert len(external) == 6

    prediction_outputs = predict_new_devices(
        outputs["model"],
        paths["prediction_overall_data"],
        paths["prediction_domains"],
        paths["prediction_submodel_predictions"],
        tmp_path / "predict_results",
        monte_carlo_samples=20,
        seed=123,
    )
    predicted = pd.read_csv(prediction_outputs["new_rankings"])
    comparisons = pd.read_csv(prediction_outputs["comparisons"])
    assert len(predicted) == 6
    assert len(comparisons) == 30
    assert predicted["estimated_rank_1_is_best"].between(1, 11).all()
    assert comparisons["P_new_better"].between(0.0, 1.0).all()
