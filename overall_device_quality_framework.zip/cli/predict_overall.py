#!/usr/bin/env python3
"""Load a trained bundle and rank new PCs among development references."""

from __future__ import annotations

import argparse
import json

from _bootstrap import PROJECT_ROOT

from subjective_audio_quality.overall.prediction import predict_new_devices


def main(argv: list[str] | None = None) -> None:
    synthetic = PROJECT_ROOT / "data/synthetic"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--model",
        default=PROJECT_ROOT / "models/synthetic/overall_model_bundle.joblib",
    )
    parser.add_argument(
        "--overall-data", default=synthetic / "prediction_pc_features.csv"
    )
    parser.add_argument("--domains", default=synthetic / "prediction_pc_domains.csv")
    parser.add_argument(
        "--submodel-predictions", default=synthetic / "prediction_pc_submodels.csv"
    )
    parser.add_argument(
        "--output-dir", default=PROJECT_ROOT / "results/synthetic/predict"
    )
    parser.add_argument("--monte-carlo-samples", type=int)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args(argv)
    outputs = predict_new_devices(
        args.model,
        args.overall_data,
        args.domains,
        args.submodel_predictions,
        args.output_dir,
        args.monte_carlo_samples,
        args.seed,
    )
    print(json.dumps({key: str(value) for key, value in outputs.items()}, indent=2))


if __name__ == "__main__":
    main()
