#!/usr/bin/env python3
"""Generate deterministic demo inputs with the real overall schema."""

from __future__ import annotations

import argparse
import json

from _bootstrap import PROJECT_ROOT

from subjective_audio_quality.overall.config import (
    OverallExperiment,
    OverallSchema,
    load_replacement_rules,
)
from subjective_audio_quality.overall.synthetic import generate_synthetic_dataset


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default=PROJECT_ROOT / "data/synthetic",
        type=str,
    )
    parser.add_argument(
        "--schema",
        default=PROJECT_ROOT / "configs/feature_schema.json",
        type=str,
    )
    parser.add_argument(
        "--replacements",
        default=PROJECT_ROOT / "configs/replacement_map.json",
        type=str,
    )
    parser.add_argument(
        "--experiment",
        default=PROJECT_ROOT / "configs/experiment.json",
        type=str,
    )
    args = parser.parse_args(argv)
    schema = OverallSchema.load(args.schema)
    rules = load_replacement_rules(args.replacements)
    experiment = OverallExperiment.load(args.experiment)
    paths = generate_synthetic_dataset(
        args.output_dir,
        schema,
        rules,
        experiment.random_seed,
        experiment.pc_development_count,
    )
    print(json.dumps({key: str(value) for key, value in paths.items()}, indent=2))


if __name__ == "__main__":
    main()
