#!/usr/bin/env python3
"""Train numeric overall score and PC-only ranking models."""

from __future__ import annotations

import argparse
import json

from _bootstrap import PROJECT_ROOT

from subjective_audio_quality.overall.training import train_overall_models


def main(argv: list[str] | None = None) -> None:
    synthetic = PROJECT_ROOT / "data/synthetic"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--overall-data", default=synthetic / "overall_features.csv")
    parser.add_argument("--domains", default=synthetic / "device_domains.csv")
    parser.add_argument(
        "--submodel-predictions", default=synthetic / "submodel_predictions.csv"
    )
    parser.add_argument(
        "--schema", default=PROJECT_ROOT / "configs/feature_schema.json"
    )
    parser.add_argument(
        "--replacements",
        default=PROJECT_ROOT / "configs/replacement_map.json",
    )
    parser.add_argument(
        "--experiment", default=PROJECT_ROOT / "configs/experiment.json"
    )
    parser.add_argument("--split", default=synthetic / "split.json")
    parser.add_argument(
        "--output-dir", default=PROJECT_ROOT / "results/synthetic/train"
    )
    parser.add_argument(
        "--model-dir", default=PROJECT_ROOT / "models/synthetic"
    )
    args = parser.parse_args(argv)
    outputs = train_overall_models(
        args.overall_data,
        args.domains,
        args.submodel_predictions,
        args.schema,
        args.replacements,
        args.experiment,
        args.split,
        args.output_dir,
        args.model_dir,
    )
    print(json.dumps({key: str(value) for key, value in outputs.items()}, indent=2))


if __name__ == "__main__":
    main()
