# 设备分类质量模型与预测结果

这个目录包含产品别名合并后的训练数据、最终分类排名模型和最新预测结果。最终模型只使用 L2/cosim 及折内选中的稳定性特征，KL/JS 不参与预测。

## 文件说明

### 模型与预测程序

- `merged_subdir_rank_models.joblib`：六个 subdir 的已拟合模型、特征配置和参考产品数据。
- `predict_saved_rank_models.py`：加载 joblib 并预测新设备。
- `selected_model_details.csv`：每个 subdir 的模型类型、特征和超参数。
- `model_coefficients.csv`：标准化特征空间中的模型截距和系数。
- `requirements-audio-eval.txt`：Python 依赖。

### 合并后的训练输入

- `data_merged.csv`：产品级 `name+subdir+x` 指标。
- `scores_merged.json`：使用相同产品名的人工评分。
- `data_merge_audit.csv`：每行数据由哪些录音名称合并而来。
- `merge_device_aliases.py`：重新执行别名合并的脚本。

### 已生成结果

- `unlabeled_device_summary.csv`：无标签产品的分类百分位汇总。
- `unlabeled_device_subdir_rankings.csv`：无标签产品详细排名。
- `all_device_subdir_rankings.csv`：全部参考产品和无标签产品排名。
- `subdir_model_comparison.csv`：产品级 LOODO 模型比较。

## 安装环境

建议使用 Python 3.10 或 3.11：

```bash
conda create -n device-rank python=3.10 -y
conda activate device-rank
python -m pip install -r requirements-audio-eval.txt
```

预测不需要 CUDA、PyTorch 或 InspireMusic；输入指标应提前计算完成。

## 新设备输入格式

输入可以是 CSV、制表符 TXT 或转换后的 JSON。一行表示一个新设备的一个 `subdir+x`，至少需要：

```text
subdir
name
x
n_windows
cosine_similarity_mean
cosine_similarity_var
l2_distance_mean
l2_distance_var
```

同一新产品在所有行中必须使用完全相同的 `name`，而且不能与模型中的参考产品重名。KL/JS 列可以存在，但预测程序会忽略。

## 加载模型并预测

```bash
python predict_saved_rank_models.py \
  --model merged_subdir_rank_models.joblib \
  --data /path/to/new_device.csv \
  --output-dir prediction_output
```

输出：

```text
prediction_output/new_device_subdir_predictions.csv
prediction_output/new_device_percentiles_wide.csv
```

`predicted_percentile` 越高表示该分类预测质量越好。`estimated_rank` 是把新设备加入参考产品后的估计名次，`reference_product_count` 是该分类中具有数据的参考产品数。

## 重新合并别名

默认脚本包含当前数据的 Magicpad/荣耀、Tagore 和 iPad Pro 2022 别名：

```bash
python merge_device_aliases.py \
  --data-json data.json \
  --scores-json overall.json \
  --output-dir merged_products
```

当前导出的 `data_merged.csv` 对重复录音的指标使用 pooled mean/variance，`n_windows` 是来源录音窗口数之和。每个 `x` 在质量聚合时仍然等权；`n_windows` 只影响不确定性估计。

## 注意事项

- 只加载自己生成或可信来源的 joblib 文件。
- `0` 或 `100` 可能是模型外推后截断的结果，不表示绝对零分或满分。
- 缺少某个 subdir 时，该分类不会生成预测。
- joblib 对 scikit-learn 版本较敏感，服务器应使用 requirements 中的兼容版本。
