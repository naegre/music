#!/usr/bin/env python3
"""Load the saved product rank models and predict new device recordings."""

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd


METRICS = {
    "cos": ("cosine_similarity_mean", "cosine_similarity_var", "fisher", 1.0),
    "l2": ("l2_distance_mean", "l2_distance_var", "log1p", -1.0),
}


def load_frame(path):
    path = Path(path)
    if path.suffix.lower() == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        records = payload.get("records", payload) if isinstance(payload, dict) else payload
        return pd.DataFrame(records)
    return pd.read_csv(path, sep=None, engine="python", encoding="utf-8-sig")


def robust_center_scale(values):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    center = float(np.median(values))
    mad = 1.4826 * float(np.median(np.abs(values - center)))
    if mad > 1e-8:
        return center, mad
    q25, q75 = np.percentile(values, [25, 75])
    iqr = float((q75 - q25) / 1.349)
    if iqr > 1e-8:
        return center, iqr
    std = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
    return center, std if std > 1e-8 else 1.0


def transform(values, kind):
    values = np.asarray(values, dtype=float)
    if kind == "log1p":
        return np.log1p(np.maximum(values, 0.0))
    return np.arctanh(np.clip(values, -0.999999, 0.999999))


def build_features(combined, reference_devices, subdir):
    task = combined[combined["subdir"].astype(str) == str(subdir)].copy()
    reference_devices = set(reference_devices)
    for key, (mean_column, variance_column, kind, direction) in METRICS.items():
        task[f"__{key}"] = transform(task[mean_column], kind)
        reference = task[task["name"].astype(str).isin(reference_devices)]
        global_stat = robust_center_scale(reference[f"__{key}"])
        exact = {
            str(audio_id): robust_center_scale(group[f"__{key}"])
            for audio_id, group in reference.groupby("x")
        }
        qualities = []
        uncertainties = []
        for _, row in task.iterrows():
            center, scale = exact.get(str(row["x"]), global_stat)
            qualities.append(direction * (float(row[f"__{key}"]) - center) / scale)
            raw_mean = max(float(row[mean_column]), 0.0)
            raw_variance = max(float(row[variance_column]), 0.0)
            if kind == "log1p":
                transformed_variance = raw_variance / ((1.0 + raw_mean) ** 2)
            else:
                clipped = np.clip(float(row[mean_column]), -0.999999, 0.999999)
                transformed_variance = raw_variance / max((1.0 - clipped ** 2) ** 2, 1e-12)
            n_effective = max(1.0, (float(row["n_windows"]) + 4.0) / 5.0)
            uncertainties.append(-np.sqrt(transformed_variance / n_effective) / scale)
        task[f"{key}_quality"] = qualities
        task[f"{key}_uncertainty_x"] = uncertainties

    rows = []
    for name, group in task.groupby("name", sort=False):
        row = {"name": str(name), "n_x": len(group)}
        for key in METRICS:
            values = group[f"{key}_quality"].to_numpy(float)
            row[f"{key}_mean"] = float(np.mean(values))
            row[f"{key}_median"] = float(np.median(values))
            row[f"{key}_stability"] = -float(np.std(values, ddof=1)) if len(values) > 1 else np.nan
            row[f"{key}_uncertainty"] = float(group[f"{key}_uncertainty_x"].mean())
        rows.append(row)
    return pd.DataFrame(rows).set_index("name")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--data", required=True, help="New device CSV, TSV, or JSON")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    bundle = joblib.load(args.model)
    if bundle.get("format_version") != 1:
        raise ValueError("Unsupported model bundle format")
    reference = bundle["reference_data"].copy()
    new_data = load_frame(args.data)
    required = {"subdir", "name", "x", "n_windows"}
    required.update(value for spec in METRICS.values() for value in spec[:2])
    missing = sorted(required - set(new_data.columns))
    if missing:
        raise ValueError(f"New data is missing required columns: {missing}")
    collisions = sorted(set(new_data["name"].astype(str)) & set(bundle["reference_devices"]))
    if collisions:
        raise ValueError(f"New product names collide with reference products: {collisions}")

    combined = pd.concat([reference, new_data], ignore_index=True, sort=False)
    new_names = set(new_data["name"].astype(str))
    rows = []
    for subdir, entry in bundle["models"].items():
        features = build_features(combined, bundle["reference_devices"], subdir)
        available_new = [name for name in features.index if name in new_names]
        if not available_new:
            continue
        prediction = np.clip(
            entry["pipeline"].predict(features.loc[available_new, entry["feature_columns"]]),
            0.0,
            100.0,
        )
        reference_names = [name for name in features.index if name in set(bundle["reference_devices"])]
        reference_prediction = np.clip(
            entry["pipeline"].predict(features.loc[reference_names, entry["feature_columns"]]),
            0.0,
            100.0,
        )
        rank_values = np.concatenate([reference_prediction, prediction])
        ranks = pd.Series(rank_values).rank(method="min", ascending=False).astype(int).to_numpy()
        for index, name in enumerate(available_new):
            rows.append({
                "name": name,
                "subdir": subdir,
                "predicted_percentile": float(prediction[index]),
                "estimated_rank": int(ranks[len(reference_names) + index]),
                "reference_product_count": len(reference_names),
            })

    result = pd.DataFrame(rows)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    result.to_csv(output / "new_device_subdir_predictions.csv", index=False)
    wide = result.pivot(index="name", columns="subdir", values="predicted_percentile")
    wide.to_csv(output / "new_device_percentiles_wide.csv")
    print(result.sort_values(["name", "subdir"]).round(2).to_string(index=False))


if __name__ == "__main__":
    main()
