#!/usr/bin/env python3
"""Merge repeated-recording device aliases at the product/subdir/x level."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


DEFAULT_ALIASES = {
    "Magicpad13-": "Magicpad13-",
    "\u8363\u8000magic13_": "Magicpad13-",
    "Tagore-": "tagore_",
    "tagore_": "tagore_",
    "ipadPro-": "ipadPro2022-",
    "ipadPro12.9-2022": "ipadPro2022-",
    "ipadPro2022-": "ipadPro2022-",
}


def load_records(path):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    records = payload.get("records", payload) if isinstance(payload, dict) else payload
    return pd.DataFrame(records), payload


def pooled_metric(group, mean_column, variance_column):
    counts = group["n_windows"].to_numpy(dtype=float)
    means = group[mean_column].to_numpy(dtype=float)
    variances = np.maximum(group[variance_column].to_numpy(dtype=float), 0.0)
    total = float(counts.sum())
    mean = float(np.sum(counts * means) / total)
    if total <= 1:
        return mean, float(np.average(variances, weights=counts))
    numerator = np.sum(np.maximum(counts - 1.0, 0.0) * variances + counts * (means - mean) ** 2)
    return mean, float(numerator / (total - 1.0))


def merge_metrics(frame, aliases):
    frame = frame.copy()
    frame["source_name"] = frame["name"].astype(str)
    frame["name"] = frame["source_name"].map(aliases).fillna(frame["source_name"])
    metric_pairs = []
    for mean_column in frame.columns:
        if not mean_column.endswith("_mean"):
            continue
        variance_column = mean_column[:-5] + "_var"
        if variance_column in frame.columns:
            metric_pairs.append((mean_column, variance_column))

    rows = []
    audit_rows = []
    for (name, subdir, audio_id), group in frame.groupby(["name", "subdir", "x"], sort=False):
        row = {"name": name, "subdir": subdir, "x": audio_id}
        row["n_windows"] = int(group["n_windows"].sum())
        for mean_column, variance_column in metric_pairs:
            mean, variance = pooled_metric(group, mean_column, variance_column)
            row[mean_column] = mean
            row[variance_column] = variance
        rows.append(row)
        audit_rows.append({
            "name": name,
            "subdir": subdir,
            "x": audio_id,
            "source_names": "|".join(sorted(group["source_name"].unique())),
            "recordings_merged": int(group["source_name"].nunique()),
            "source_rows": int(len(group)),
            "n_windows_pooled": int(group["n_windows"].sum()),
        })
    merged = pd.DataFrame(rows)
    preferred = ["subdir", "x", "name", "n_windows"]
    merged = merged[preferred + [column for column in merged if column not in preferred]]
    return merged, pd.DataFrame(audit_rows)


def merge_scores(scores, aliases):
    merged = {}
    audit = []
    for subdir, values in scores.items():
        grouped = {}
        for source_name, score in values.items():
            canonical = aliases.get(source_name, source_name)
            grouped.setdefault(canonical, []).append((source_name, float(score)))
        merged[subdir] = {}
        for canonical, entries in grouped.items():
            merged[subdir][canonical] = float(np.mean([score for _, score in entries]))
            audit.append({
                "subdir": subdir,
                "name": canonical,
                "source_names": "|".join(sorted(name for name, _ in entries)),
                "scores_merged": len(entries),
                "merged_score": merged[subdir][canonical],
            })
    return merged, pd.DataFrame(audit)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-json", required=True)
    parser.add_argument("--scores-json", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--aliases-json", default="")
    args = parser.parse_args()

    aliases = DEFAULT_ALIASES
    if args.aliases_json:
        aliases = json.loads(Path(args.aliases_json).read_text(encoding="utf-8"))
    frame, source_payload = load_records(args.data_json)
    scores = json.loads(Path(args.scores_json).read_text(encoding="utf-8"))
    merged, data_audit = merge_metrics(frame, aliases)
    merged_scores, score_audit = merge_scores(scores, aliases)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": source_payload.get("schema_version", 1) if isinstance(source_payload, dict) else 1,
        "source_format": "product-level alias-merged x aggregate",
        "aliases": aliases,
        "columns": merged.columns.tolist(),
        "records": merged.to_dict("records"),
    }
    (output / "data_merged.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output / "scores_merged.json").write_text(
        json.dumps(merged_scores, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    merged.to_csv(output / "data_merged.csv", index=False)
    data_audit.to_csv(output / "data_merge_audit.csv", index=False)
    score_audit.to_csv(output / "score_merge_audit.csv", index=False)
    print(f"Rows: {len(frame)} -> {len(merged)}")
    print(f"Devices: {frame['name'].nunique()} -> {merged['name'].nunique()}")
    print(f"Outputs written to: {output}")


if __name__ == "__main__":
    main()
