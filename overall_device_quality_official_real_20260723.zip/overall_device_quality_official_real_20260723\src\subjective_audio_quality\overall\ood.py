"""Fold-independent deployment diagnostics fitted on development devices only."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .preprocessing import robust_scale


class RobustOODDetector:
    """Flag extrapolation against all-development and PC-only references."""

    def __init__(self, z_threshold: float = 3.5):
        self.z_threshold = float(z_threshold)

    @staticmethod
    def _fit_reference(x: pd.DataFrame) -> dict[str, np.ndarray | list[str]]:
        centers: list[float] = []
        scales: list[float] = []
        methods: list[str] = []
        for column in x.columns:
            center, scale, method = robust_scale(x[column].to_numpy(dtype=float))
            centers.append(center)
            scales.append(scale)
            methods.append(method)
        return {
            "center": np.asarray(centers, dtype=float),
            "scale": np.asarray(scales, dtype=float),
            "minimum": x.to_numpy(dtype=float).min(axis=0),
            "maximum": x.to_numpy(dtype=float).max(axis=0),
            "methods": methods,
        }

    def fit(
        self,
        x: pd.DataFrame,
        domains: pd.Series,
    ) -> "RobustOODDetector":
        self.feature_names_in_ = list(x.columns)
        numeric = x[self.feature_names_in_].astype(float)
        self.impute_values_ = numeric.median(axis=0, skipna=True)
        if self.impute_values_.isna().any():
            missing = self.impute_values_.index[self.impute_values_.isna()].tolist()
            raise ValueError(f"OOD reference features are entirely missing: {missing}")
        imputed = numeric.fillna(self.impute_values_)
        self.all_reference_ = self._fit_reference(imputed)
        pc_mask = domains.astype(str).eq("pc").to_numpy()
        if int(pc_mask.sum()) >= 2:
            self.pc_reference_ = self._fit_reference(
                imputed.loc[pc_mask, self.feature_names_in_]
            )
        else:
            self.pc_reference_ = None
        return self

    def _reference_report(
        self,
        x: pd.DataFrame,
        reference: dict[str, np.ndarray | list[str]],
        prefix: str,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        raw = x[self.feature_names_in_].astype(float)
        missing_input = raw.isna().to_numpy()
        values = raw.fillna(self.impute_values_).to_numpy(dtype=float)
        center = np.asarray(reference["center"], dtype=float)
        scale = np.asarray(reference["scale"], dtype=float)
        minimum = np.asarray(reference["minimum"], dtype=float)
        maximum = np.asarray(reference["maximum"], dtype=float)
        absolute_z = np.abs((values - center) / scale)
        outside = (values < minimum) | (values > maximum)
        summary = pd.DataFrame(
            {
                f"{prefix}_max_abs_robust_z": absolute_z.max(axis=1),
                f"{prefix}_n_features_z_above_threshold": (
                    absolute_z > self.z_threshold
                ).sum(axis=1),
                f"{prefix}_n_features_outside_training_range": outside.sum(axis=1),
                f"{prefix}_n_features_imputed": missing_input.sum(axis=1),
            },
            index=x.index,
        )
        details: list[dict[str, object]] = []
        for row_index, device_index in enumerate(x.index):
            for feature_index, feature in enumerate(self.feature_names_in_):
                if (
                    absolute_z[row_index, feature_index] > self.z_threshold
                    or outside[row_index, feature_index]
                    or missing_input[row_index, feature_index]
                ):
                    details.append(
                        {
                            "row_index": device_index,
                            "reference": prefix,
                            "feature": feature,
                            "value": float(values[row_index, feature_index]),
                            "abs_robust_z": float(absolute_z[row_index, feature_index]),
                            "outside_training_range": bool(
                                outside[row_index, feature_index]
                            ),
                            "input_was_missing": bool(
                                missing_input[row_index, feature_index]
                            ),
                        }
                    )
        return summary, pd.DataFrame(details)

    def report(
        self,
        x: pd.DataFrame,
        names: pd.Series,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Return one-row-per-device flags and feature-level exceptions."""

        all_summary, all_details = self._reference_report(
            x, self.all_reference_, "all_development"
        )
        summary = all_summary
        details = [all_details]
        if self.pc_reference_ is not None:
            pc_summary, pc_details = self._reference_report(
                x, self.pc_reference_, "pc_development"
            )
            summary = pd.concat([summary, pc_summary], axis=1)
            details.append(pc_details)
            flag = (
                summary["pc_development_max_abs_robust_z"] > self.z_threshold
            ) | (
                summary["pc_development_n_features_outside_training_range"] > 0
            ) | (
                summary["pc_development_n_features_imputed"] > 0
            )
        else:
            flag = (
                summary["all_development_max_abs_robust_z"] > self.z_threshold
            ) | (
                summary["all_development_n_features_outside_training_range"] > 0
            ) | (
                summary["all_development_n_features_imputed"] > 0
            )
        summary.insert(0, "name", names.astype(str).to_numpy())
        summary["ood_warning"] = flag.to_numpy(dtype=bool)
        summary["ood_threshold"] = self.z_threshold
        detail_frame = pd.concat(details, ignore_index=True) if details else pd.DataFrame()
        if not detail_frame.empty:
            name_lookup = dict(zip(x.index, names.astype(str), strict=True))
            detail_frame.insert(
                0, "name", detail_frame["row_index"].map(name_lookup).astype(str)
            )
            detail_frame = detail_frame.drop(columns="row_index")
        return summary.reset_index(drop=True), detail_frame
