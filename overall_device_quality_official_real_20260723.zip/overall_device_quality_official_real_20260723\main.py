#!/usr/bin/env python3
"""Unified entry point for the overall score/ranking framework."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path


CLI_DIR = Path(__file__).resolve().parent / "cli"
sys.path.insert(0, str(CLI_DIR))

COMMANDS = {
    "generate-synthetic": "generate_synthetic",
    "prepare-real": "prepare_real_data",
    "prepare-real-predict": "prepare_real_prediction_data",
    "train": "train_overall",
    "predict": "predict_overall",
}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] in {"-h", "--help"}:
        commands = ", ".join(COMMANDS)
        print(f"{__doc__}\n\nCommands: {commands}")
        return
    command = sys.argv[1]
    if command not in COMMANDS:
        raise SystemExit(f"Unknown command {command!r}; choose from: {', '.join(COMMANDS)}")
    importlib.import_module(COMMANDS[command]).main(sys.argv[2:])


if __name__ == "__main__":
    main()
