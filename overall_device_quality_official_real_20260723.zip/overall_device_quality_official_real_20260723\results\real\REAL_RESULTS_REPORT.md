# 真实数据首次训练、冻结外测与预测报告

运行日期：2026-07-23（Asia/Shanghai）

## 冻结协议

- 权威白名单：29 台，17 tablet + 12 PC。
- 最终训练：17 tablet + 5 开发 PC；冻结外测：7 PC。
- 开发 PC：`CG-`、`MG-`、`pro14-`、`pro16-`、`xx14-`。
- 冻结 PC：`air13-`、`air15-`、`enzoh-`、`harden-`、`hookeg-`、`magic-`、`vg-`。
- 数据、配置、split 和训练源码已用 SHA-256 联合锁定，指纹为 `1af987fabea2366eb9a0c14033a4681fea318f18010a024c16b2aeaf7643564e`。
- 本报告基于唯一一次正式冻结评估。不得利用以下结果重新选择特征、超参数、OOD 阈值或 PC 切分。

## 数据处理核对

- 真实映射替换 `clarity`、`lowfreq`、`fullness`、`edginess`，原始 22 维折叠为 19 维；原始 `treble_1/treble_2` 保留。
- 子模型输入共 116 行，即 29 台 × 4 subdir。16 台 tablet 的 64 行为 OOF；`ipadPro2022-` 与 12 台 PC 的 52 行为 inductive。
- 原表有 12 个主观缺失；clarity 被整体替换后，最终矩阵剩 9 个缺失，均位于 3 台 tablet 的 `spatial_5_S`、`spatial_6_S`、`artefacts_3_S`。每个 score/rank 训练折独立拟合列中位数；外测不参与填补。
- `prediction_se` 按已确认定义恢复为 `prediction_sd = prediction_se × sqrt(1000)`。四个预测特征的 SD 共 116 个，范围约 0.792–21.473，中位数约 5.350。

## 模型选择

- Score：非负 Ridge，robust 预处理，`alpha=10`。
- Rank：非负 soft pairwise logistic，scaled 预处理，`alpha=100`。
- Score 外层 5 折中 4 折选择 `alpha=10`、1 折选择 `alpha=1`。
- Rank 外层 5 折中 3 折选择 scaled/100、2 折选择 block/100，说明小样本下预处理选择仍有不稳定性。

## 开发 PC 嵌套 LOO

| 任务 | 指标 | 结果 |
|---|---|---:|
| Score | MAE | 2.812 |
| Score | RMSE | 3.553 |
| Score | 最大绝对误差 | 6.261 |
| Rank | pairwise accuracy | 1.000 |
| Rank | pairwise Brier | 0.0108 |
| Rank | pairwise log loss | 0.2091 |

开发排名的 20 行是 5 个外折分别与 4 个 peer 的有向记录；底层只有 10 个无序 PC 对，且共享设备与模型，不能视为 20 个独立样本。

## 7 台冻结 PC 外测

| 任务 | 指标 | 结果 |
|---|---|---:|
| Score | MAE | 2.235 |
| Score | RMSE | 2.656 |
| Score | bias（预测−真实） | -2.235 |
| Score | 最大绝对误差 | 5.372 |
| Score | Spearman | 0.893 |
| Rank | pairwise accuracy | 0.905（19/21） |
| Rank | pairwise Brier | 0.0138 |
| Rank | pairwise log loss | 0.2624 |
| Rank | Kendall tau | 0.810 |

所有 7 台的数值分数都被低估，不能只因平均 MAE 尚可就忽略这一系统性现象。最明显的是 `enzoh-`：真实 89.102，预测 83.731，误差 -5.372。

| 冻结 PC | 真实 overall | 预测 overall | 残差 | 7 台内部预测名次 |
|---|---:|---:|---:|---:|
| harden- | 96.249 | 94.877 | -1.372 | 1 |
| vg- | 95.011 | 91.802 | -3.209 | 2 |
| air15- | 91.427 | 89.804 | -1.623 | 3 |
| air13- | 87.606 | 86.568 | -1.038 | 4 |
| hookeg- | 87.540 | 85.874 | -1.665 | 5 |
| enzoh- | 89.102 | 83.731 | -5.372 | 6 |
| magic- | 79.556 | 78.189 | -1.366 | 7 |

两项方向错误均涉及 `enzoh-`：

- 模型判断 `air13-` 优于 `enzoh-`，概率 0.692；真实软目标为 0.350。
- 模型判断 `hookeg-` 优于 `enzoh-`（等价于 `P(enzoh- > hookeg-)=0.450`）；真实软目标为 0.656。
- 两项均未达到代码定义的“高置信错误”阈值，`overconfident_wrong=0`。

## 部署式预测排名

把 7 台冻结 PC 作为 inductive 新设备，与 5 台开发 PC 参考机合并后，rank model 的 12 台顺序为：

1. `pro16-`
2. `harden-`
3. `pro14-`
4. `vg-`
5. `MG-`
6. `air15-`
7. `CG-`
8. `air13-`
9. `hookeg-`
10. `enzoh-`
11. `magic-`
12. `xx14-`

这里的名次参考集合是 12 台，不能与“7 台冻结 PC 内部名次”直接比较。Score model 与 Rank model 独立，因此数值分数顺序也不必逐项等于 rank utility 顺序。

## 不确定性与 OOD

- 7 台全部被 OOD detector 标记。相对全部 22 台开发设备时有 6/7 触发异常；相对仅 5 台开发 PC 时 7/7 都触发，表明 PC 参考范围过窄。
- 常见异常来源包括 `lowfreq__predicted_percentile`、treble、balance 和 artefacts。`enzoh-` 相对 PC 参考有 7 个特征超出训练范围，是最需要谨慎解释的设备之一。
- score 的输入不确定性区间宽度约 1.749–3.606 分，中位数约 2.535 分，但它只传播四个子模型的 `prediction_sd`。它不包含模型参数、overall 标签、实测特征和缺失填补的不确定性，不是真正的完整预测区间；实际 overall 仅 1/7 落在该有限区间内。
- 蒙特卡洛还假设设备与 subdir 误差近似独立正态；共同模型或共同 bootstrap 带来的相关性没有进入区间。

## 结论

这次结果支持模型具备一定排序信号：冻结集 19/21 对方向正确，且数值 MAE 约 2.24。但证据强度受 5 台开发 PC、7 台外测 PC、普遍 OOD、全体低估和 `enzoh-` 明显失配限制。当前模型适合做带警告的探索性预测，不应被描述为已经充分校准或已在广泛 PC 分布上验证。

下一步若要改善，应新增独立 PC 数据并预先定义新的开发/验证协议；不能拿本轮 7 台冻结结果做偏差校正或超参数回选。
