# 2026-07-23 正式发布包验证报告

验证对象：`releases/overall_device_quality_official_real_20260723/`

## 1. 输入与冻结指纹

- 四个原始 CSV 的 SHA-256 与 `data/real/data_audit.json` 记录一致。
- 规范化训练输入、正式配置和 `src/subjective_audio_quality/overall/*.py` 与冻结 manifest 记录一致。
- 模型元数据中的冻结评估指纹与 manifest 一致：

```text
1af987fabea2366eb9a0c14033a4681fea318f18010a024c16b2aeaf7643564e
```

## 2. 从打包副本运行测试

命令：

```powershell
python -m pytest -q -p no:cacheprovider
```

结果：

```text
8 passed in 2.96s
```

## 3. 从打包副本加载正式模型并预测

使用包内：

```text
models/real/overall_model_bundle.joblib
data/real/prediction_pc_features.csv
data/real/prediction_pc_domains.csv
data/real/prediction_pc_submodels.csv
```

预测成功：

- 新设备行数：7；
- 新设备对 5 台参考 PC 的概率行数：35；
- 生成输出文件：8 个。

## 4. 从打包副本完整复训

使用 `REPRODUCIBILITY.md` 的 real 配置和同一冻结 split，输出到临时目录，没有覆盖正式模型或正式结果。

复训结果：

```text
external Score MAE = 2.235014925958339
external Rank pair accuracy = 0.9047619047619048（19/21）
```

与正式 `results/real/train/metrics.json` 一致。复训生成的 `overall_model_metadata.json` 与正式元数据逐字一致。

joblib/pickle 重新序列化后的文件二进制 SHA-256 不保证逐次相同，因此不把“重新训练后 bundle 二进制逐字节一致”作为复现标准。正式交付模型的权威哈希为：

```text
b30bb4cef9118d51719d2d6d7ad1d6eb0e6c254af340f111aeb32e7223001ac4
```

可复现性以输入/config/source 指纹、可读元数据、模型规格、指标和逐设备预测一致为准。

## 5. 发布边界

- 正式模型继续保留原始 treble，不采用 post-hoc treble 替代模型。
- 已查看的 7 台冻结 PC 只能复现旧评估，不能被重新解释为新的盲测。
- 发布包内真实数据和原始四表属于私有资料，不建议公开上传。

