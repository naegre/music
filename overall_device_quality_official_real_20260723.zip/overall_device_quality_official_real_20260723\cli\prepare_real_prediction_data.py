#!/usr/bin/env python3
"""Select the seven frozen PCs as reproducible inductive-prediction inputs."""

from __future__ import annotations

import argparse
import json

from _bootstrap import PROJECT_ROOT

from subjective_audio_quality.overall.real_data import (
    prepare_frozen_pc_prediction_inputs,
)


def main(argv: list[str] | None = None) -> None:
    real = PROJECT_ROOT / "data/real"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--overall-data", default=real / "overall_features.csv")
    parser.add_argument("--domains", default=real / "device_domains.csv")
    parser.add_argument(
        "--submodel-predictions", default=real / "submodel_predictions.csv"
    )
    parser.add_argument("--split", default=real / "frozen_pc_split.json")
    parser.add_argument("--output-dir", default=real)
    args = parser.parse_args(argv)
    paths = prepare_frozen_pc_prediction_inputs(
        args.overall_data,
        args.domains,
        args.submodel_predictions,
        args.split,
        args.output_dir,
    )
    print(
        json.dumps(
            {key: str(path.resolve()) for key, path in paths.items()},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
