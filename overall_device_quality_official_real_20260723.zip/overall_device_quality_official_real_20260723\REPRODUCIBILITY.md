# 正式真实模型复现与新设备预测

本文档对应 2026-07-23 的正式 no-treble-replacement 模型。请先阅读 [`MODEL_ANALYSIS_README.md`](MODEL_ANALYSIS_README.md) 了解模型边界和冻结外测限制。

## 1. 安装与基础验证

在项目根目录打开 Windows PowerShell：

```powershell
python -m pip install -r requirements.txt
python -m pip install -e .
python -m pytest -q -p no:cacheprovider
python main.py --help
```

本次训练的精确版本记录在 [`ENVIRONMENT_LOCK.txt`](ENVIRONMENT_LOCK.txt)。`requirements.txt` 是兼容范围，不保证未来依赖版本得到逐位相同的数值。joblib/pickle 只能从可信来源加载。

## 2. 从四个原始 CSV 重新做数据准备

私有发布包若包含 `source_inputs/`，可执行：

```powershell
python main.py prepare-real `
  --device-score source_inputs/device_score.csv `
  --device-domain source_inputs/device_domain.csv `
  --table-predictions source_inputs/table_predicted_score.csv `
  --pc-predictions source_inputs/pc_predicted_score.csv `
  --schema configs/feature_schema.json `
  --output-dir reproduction/prepared_real
```

程序只读原始 CSV，不修改它们。输出会包含规范化数据、列映射、排除行和输入哈希审计。

若没有原始四表，包内已有的以下规范文件足以完整复跑第二层训练：

```text
data/real/overall_features.csv
data/real/device_domains.csv
data/real/submodel_predictions.csv
data/real/frozen_pc_split.json
```

## 3. 复现正式训练流程

不要裸跑 `python main.py train`，因为无参数默认值指向 synthetic 演示。正式复现必须显式指定 real 输入与 `*_real.json`。

为避免覆盖已经锁定的官方模型和结果，建议输出到新的 `reproduction/`：

```powershell
python main.py train `
  --overall-data data/real/overall_features.csv `
  --domains data/real/device_domains.csv `
  --submodel-predictions data/real/submodel_predictions.csv `
  --schema configs/feature_schema.json `
  --replacements configs/replacement_map_real.json `
  --experiment configs/experiment_real.json `
  --split data/real/frozen_pc_split.json `
  --output-dir reproduction/official_20260723/results/train `
  --model-dir reproduction/official_20260723/models
```

注意：这会复现已经查看过的 7 台冻结 PC 评估，用于代码和结果核对；它不是一轮新的独立盲测。不得根据这 7 台结果修改模型后继续称其为冻结外测。

正式基线必须使用：

```text
configs/replacement_map_real.json
configs/experiment_real.json
```

普通 `configs/replacement_map.json` 和 `configs/experiment.json` 属于 synthetic/test 流程，不能替代正式配置。

## 4. 用现有模型复现 7 台部署式预测

```powershell
python main.py predict `
  --model models/real/overall_model_bundle.joblib `
  --overall-data data/real/prediction_pc_features.csv `
  --domains data/real/prediction_pc_domains.csv `
  --submodel-predictions data/real/prediction_pc_submodels.csv `
  --output-dir reproduction/official_20260723/results/predict
```

不要裸跑 `python main.py predict`，因为无参数默认值同样指向 synthetic 模型和输入。

## 5. 新 PC 输入格式

新设备需要三张表。

### 5.1 设备特征表

一行一台设备，包含：

```text
name + configs/feature_schema.json 中的 22 个规范特征
```

预测时 `overall` 可以省略；若保留，程序会额外输出有标签评估。字段顺序和含义必须与 schema 一致。

### 5.2 设备域表

```csv
name,domain
new_pc_01,pc
```

当前部署排名接口只接受 PC。新名称不能与模型包内 5 台开发参考 PC 重名。

### 5.3 第一层 subdir 长表

每台新 PC 必须正好提供 clarity、lowfreq、fullness、edginess 四行：

```csv
name,subdir,predicted_percentile,prediction_se,prediction_sd,prediction_source
new_pc_01,clarity,78.2,0.42,13.281,inductive
new_pc_01,lowfreq,73.1,0.37,11.700,inductive
new_pc_01,fullness,81.4,0.35,11.068,inductive
new_pc_01,edginess,76.8,0.39,12.333,inductive
```

规则：

- `predicted_percentile` 必须在 0–100；
- `prediction_sd >= 0`，且本项目原始定义为 `prediction_sd = prediction_se × sqrt(1000)`；
- 正式 `replacement_map_real.json` 使用 `prediction_sd` 做蒙特卡洛传播，因此该列不能缺失；
- 新 PC 的 `prediction_source` 必须为 `inductive`；
- `prediction_se`、`prediction_sd` 和来源字段不会作为音质高低特征。

## 6. 新 PC 预测命令

```powershell
python main.py predict `
  --model models/real/overall_model_bundle.joblib `
  --overall-data data/new/my_batch_features.csv `
  --domains data/new/my_batch_domains.csv `
  --submodel-predictions data/new/my_batch_submodels.csv `
  --output-dir results/new/my_batch
```

核心输出：

| 文件 | 含义 |
|---|---|
| `new_device_rankings.csv` | 新设备 Score、组合名次、有限 CI、邻近参考和 OOD |
| `combined_reference_rankings.csv` | 新设备与 5 台开发参考 PC 的共同顺序 |
| `new_vs_reference_probabilities.csv` | 新设备对每台参考 PC 的胜出概率 |
| `all_pair_probabilities.csv` | 当前批次全部设备对 |
| `new_device_ood_summary.csv` | 每台设备的 OOD 摘要 |
| `new_device_ood_details.csv` | 具体越界特征 |

名次依赖比较集合。外测 7 台内部名次与“新设备 + 5 台参考 PC”的组合名次不能直接比较。

## 7. 正式产物校验

正式模型：

```text
models/real/overall_model_bundle.joblib
SHA-256: b30bb4cef9118d51719d2d6d7ad1d6eb0e6c254af340f111aeb32e7223001ac4
```

冻结评估联合指纹：

```text
1af987fabea2366eb9a0c14033a4681fea318f18010a024c16b2aeaf7643564e
```

解压发布包后可用 PowerShell 校验全部文件：

```powershell
Get-Content SHA256SUMS.txt | ForEach-Object {
  $expected, $relative = $_ -split '  ', 2
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $relative).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw "Hash mismatch: $relative" }
}
```

