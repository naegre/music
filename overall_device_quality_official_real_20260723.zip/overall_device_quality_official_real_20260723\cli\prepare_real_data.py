#!/usr/bin/env python3
"""Validate and prepare the four confirmed real-device CSV inputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from _bootstrap import PROJECT_ROOT

from subjective_audio_quality.overall.config import OverallSchema
from subjective_audio_quality.overall.real_data import prepare_real_data


def main(argv: list[str] | None = None) -> None:
    desktop = Path.home() / "Desktop"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--device-score",
        default=desktop / "device_score.csv",
        help="Chinese-column overall score table (read-only input)",
    )
    parser.add_argument(
        "--device-domain",
        default=desktop / "device_domain.csv",
        help="Authoritative 29-device whitelist (read-only input)",
    )
    parser.add_argument(
        "--table-predictions",
        default=desktop / "table_predicted_score.csv",
        help="Tablet submodel predictions (read-only input)",
    )
    parser.add_argument(
        "--pc-predictions",
        default=desktop / "pc_predicted_score.csv",
        help="PC submodel predictions (read-only input)",
    )
    parser.add_argument(
        "--schema",
        default=PROJECT_ROOT / "configs/feature_schema.json",
        help="Canonical 22-feature schema",
    )
    parser.add_argument(
        "--output-dir",
        default=PROJECT_ROOT / "data/real",
        help="Directory for prepared copies and audit files",
    )
    args = parser.parse_args(argv)
    paths = prepare_real_data(
        args.device_score,
        args.device_domain,
        args.table_predictions,
        args.pc_predictions,
        args.output_dir,
        OverallSchema.load(args.schema),
    )
    print(
        json.dumps(
            {key: str(path.resolve()) for key, path in paths.items()},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
