# Overall 设备质量模型：设计、数据处理与结果说明

版本日期：2026-07-23（Asia/Shanghai）

本文档面向几乎没有 AI 或机器学习背景的读者，说明当前正式模型为什么这样设计、每个模块怎样处理数据、参数怎样选择，以及当前结果可以和不可以说明什么。

> **正式模型边界：**本文只把“保留原始 `treble_1/treble_2`、替换 clarity/lowfreq/fullness/edginess”的方案视为正式模型。查看冻结 7 台 PC 结果后进行的 treble 补值/替换实验仅是 post-hoc 敏感性分析，不能替代正式冻结成绩，也不能用于宣称模型经过了新的独立外测。

## 1. 一句话理解整个系统

这不是神经网络或不可解释的“大模型”，而是一套面向极小样本的两层建模系统：

1. 第一层 subdir 模型把四个音频子类别浓缩为预测百分位。
2. 第二层使用同一套 19 维设备输入，分别训练一个 Score 模型和一个 Rank 模型。
3. Score 负责预测 0–100 的 overall 分数；Rank 负责预测设备间的相对顺序和胜出概率。
4. 两个模型相互独立，Rank 不读取 Score 的预测，Score 也不读取 Rank 的结果。

```text
设备原始 22 个子特征 + 第一层 4 个 subdir 预测
                    │
                    ▼
      白名单、字段、缺失、来源和泄漏审计
                    │
                    ▼
   22 - 7 个被替换原始字段 + 4 个预测 = 19 维
                    │
          ┌─────────┴─────────┐
          ▼                   ▼
   Score：预测 overall   Rank：预测 utility/概率/名次
          │                   │
          └─────────┬─────────┘
                    ▼
       有限不确定性区间 + OOD 警告 + 审计结果
```

## 2. 当前正式数据定义

权威设备范围由 `device_domain.csv` 决定，只允许 29 台设备：

- 17 台 tablet；
- 12 台 PC。

其他 CSV 中即使存在额外设备，也不会进入训练，并会被写入排除审计。

每台设备的原始评分表包含：

- `name`；
- 22 个分项特征；
- 训练标签 `overall`；
- 另表提供的 `domain`（`tablet` 或 `pc`）。

名称以 `_S` 结尾的字段表示主观评价。所有输入特征均在契约中定义为“越高越好”。`overall` 必须为 0–100 的有限数字；分项特征只要求为有限数值，不强行裁剪到 100，因为部分客观指标不一定是百分制。

规范字段定义见 [`configs/feature_schema.json`](configs/feature_schema.json)，中文原始列到规范字段的映射审计见 [`data/real/column_mapping.csv`](data/real/column_mapping.csv)。

## 3. 第一层 subdir 预测怎样进入第二层

第二层正式接入以下四类第一层输出：

| subdir | 删除的原始字段 | 新增字段 |
|---|---|---|
| clarity | `clarity_1_S`、`clarity_2`、`clarity_3_S` | `clarity__predicted_percentile` |
| lowfreq | `timber_1`、`timber_2` | `lowfreq__predicted_percentile` |
| fullness | `fullness` | `fullness__predicted_percentile` |
| edginess | `edginess` | `edginess__predicted_percentile` |

所以最终特征数为：

```text
22 - 7 + 4 = 19
```

正式模型保留原始 `treble_1`、`treble_2`。完整 19 维字段可在 [`models/real/overall_model_metadata.json`](models/real/overall_model_metadata.json) 中核对。

使用第一层综合百分位的目的，是减少同一语义类别下重复、相关的输入，并把不同子类别的输出放到统一的百分位尺度上。代价是第一层预测误差会向第二层传播，因此第一层预测的不确定性被单独保留，但不会当作“质量高低”特征输入模型。

## 4. OOF 与 inductive：第一层如何避免把答案泄漏给第二层

第一层输出必须记录 `prediction_source`：

- **OOF（out-of-fold）**：如果某台 tablet 的人工标签参与过第一层训练，那么为它生成第二层输入时，必须使用一个没有见过该设备标签的折外模型。
- **inductive**：该设备从未以有标签样本进入第一层模型，按照真正新设备的方式推理。

可以把 OOF 理解为：老师可以从其他学生的试卷学习评分规律，但给当前学生打分时不能提前看当前学生的标准答案。

当前来源为：

- 16 台有标签 tablet：OOF；
- `ipadPro2022-`：inductive；
- 全部 12 台 PC：inductive。

四个 subdir 合计：

```text
16 × 4 = 64 行 OOF
13 × 4 = 52 行 inductive
总计 116 行
```

代码会拒绝 PC 的训练内预测、来源混乱、重复组合或缺少任意必需 `name + subdir` 组合。

## 5. 缺失值怎样处理

原始表有 12 个主观分缺失，来自 3 台 tablet。clarity 整组被第一层预测替换后，其中 3 个 clarity 缺失单元不再进入最终矩阵；最终 19 维矩阵剩余 9 个缺失：

- `spatial_5_S`：3 个；
- `spatial_6_S`：3 个；
- `artefacts_3_S`：3 个。

这些字段使用列中位数填补，但中位数必须在每一个训练折内部独立计算：

1. 当前折只读取训练设备；
2. 用训练设备计算列中位数；
3. 用该中位数填训练设备和当前留出设备；
4. 下一折重新计算；
5. 冻结 PC 永不参与统计量计算。

最终正式模型在 17 tablet + 5 开发 PC 上得到：

| 字段 | 最终训练中位数 |
|---|---:|
| `spatial_5_S` | 82.33 |
| `spatial_6_S` | 82.00 |
| `artefacts_3_S` | 84.60 |

中位数比平均数更不容易受极端值影响。代码没有根据 overall 或真实名次反推缺失特征，因为这会把目标答案注入输入，形成泄漏。如果某个训练折中整列都缺失，程序会直接报错，而不是静默填 0。

## 6. 17/5/7 开发与冻结协议

29 台设备的职责固定为：

```text
17 tablet + 5 开发 PC：建模、交叉验证、参数选择和最终拟合
7 冻结 PC：模型锁定后的一次性外部评估
```

开发 PC：

- `CG-`
- `MG-`
- `pro14-`
- `pro16-`
- `xx14-`

冻结 PC：

- `air13-`
- `air15-`
- `enzoh-`
- `harden-`
- `hookeg-`
- `magic-`
- `vg-`

首次创建划分时，代码按 12 台 PC 的 overall 从低到高分层，并使用固定种子 `20260721` 从不同层次选择 5 台开发 PC，使极少的开发 PC 尽量覆盖低、中、高分。划分创建后永久复用。

严格说，12 台 PC 的 overall 在首次分层划分时被使用过一次；冻结设备随后不再参与：

- 缺失填补；
- 中心与尺度；
- PCA；
- 模型系数；
- 超参数选择；
- OOD 参考范围；
- 特征映射或阈值调整。

冻结结果目前已经查看，今后不能根据它们调整模型后再把同一批 7 台描述为新的盲测。数据、配置、split 和训练源码的联合指纹为：

```text
1af987fabea2366eb9a0c14033a4681fea318f18010a024c16b2aeaf7643564e
```

## 7. 折内预处理

不同特征使用不同量尺，不能直接比较。Score 正式预处理对每列执行：

```text
处理后数值 =（原值 - 当前训练折中位数）/ 当前训练折稳健尺度
```

稳健尺度优先使用：

```text
1.4826 × MAD
```

若 MAD 退化为 0，则依次回退到：

1. `IQR / 1.349`；
2. 样本标准差；
3. 常数 1。

这相当于把 19 个使用不同尺子的评分员换算到可比较的尺度，而且比均值/标准差更不容易被极端设备带偏。

除正式使用的 `robust`/`scaled` 外，开发阶段还比较：

- `block`：在稳健处理后，再乘 `1 / sqrt(同语义组字段数)`，避免某个语义组只因列数多而重复占权；
- `PCA`：把 19 维压缩到 2、3 或 4 个综合轴，仅作诊断。PCA 混合原始特征后难以保证原始字段单调非负，因此 `allow_pca_deployment=false`。

所有填补、中心、尺度、block 因子和 PCA 都在当前训练折内拟合，验证设备只能套用已拟合参数。

## 8. Score 模型

Score 预测公式可简化为：

```text
预测 overall
= 基础分
+ PC 域偏移
+ 19 个“处理后特征 × 对应权重”
```

数学形式：

```text
ŷ = clip(b0 + bPC × I(PC) + Σ βj × zj, 0, 100)
```

其中：

- `b0` 是基础分；
- `bPC` 吸收 tablet 与 PC 的平均域差异；
- `zj` 是填补和缩放后的输入；
- `βj` 是模型学习的质量权重；
- 输出最终裁剪到 0–100。

非 PCA 候选的 19 个质量权重强制 `βj >= 0`。因为所有字段都定义为越高越好，所以在其他输入不变时，提高任意一项质量输入不能让预测分下降。基础分和 PC 域偏移不受非负约束。

### 8.1 tablet/PC 域平衡

最终训练有 17 tablet、5 PC。若每台权重相同，tablet 会仅因数量多而支配模型。代码让两个域的总样本权重各占一半；在最终 22 台训练中，每台 tablet 的相对权重约 0.647，每台 PC 约 2.2。它不是复制样本，只是在损失函数中平衡两个域的总影响。

### 8.2 Ridge 正则

正式模型使用 Ridge，目标可以理解为：

```text
加权平方预测误差 + alpha × 参数平方和
```

正则项像把权重向 0 拉的弹簧：

- alpha 太小：容易记住极少的训练设备；
- alpha 太大：过于保守，可能欠拟合；
- 当前正式值：`alpha=10`。

截距不受正则惩罚；质量权重和 PC 偏移受惩罚。正式 Score 规格为：

```text
nonnegative Ridge + robust + alpha=10
```

## 9. Rank 模型

Rank 不直接预测 overall，而是学习一个隐藏的相对实力值 `utility`：

```text
utility = Σ βj × 处理后特征j
```

比较 A、B 时：

```text
P(A > B) = sigmoid(utilityA - utilityB)
```

utility 本身没有 0–100 的现实含义，只有差值、顺序和转换出的概率有意义。模型不需要独立截距，因为两设备相减时截距会抵消。

### 9.1 软排序标签

训练标签不是简单的“赢/输”，而是根据 overall 差值编码为：

```text
目标概率 = clip(0.5 + 0.1 × (overallA - overallB), 0, 1)
```

| A 的 overall 领先 | 训练目标概率 |
|---:|---:|
| 0 分 | 50% |
| 1 分 | 60% |
| 2 分 | 70% |
| 3 分 | 80% |
| 4 分 | 90% |
| 5 分及以上 | 100% |

这能区分“只赢一点”和“明显更好”。但这些概率是预先规定的偏好强度编码，不是从大量重复听测统计出的真实概率。

### 9.2 只构造同域设备对

Rank 只构造 tablet-tablet 和 PC-PC 设备对，不构造 tablet-PC 对。最终拟合包含：

```text
C(17,2) = 136 个 tablet pair
C(5,2)  = 10 个 PC pair
```

两个域的 pair loss 各占一半，避免 136 个 tablet pair 淹没 10 个目标 PC pair。

Rank 的 `_S` 主观特征保留“一原始分 = 一建模单位”；客观特征与预测百分位根据各自稳健尺度和 overall 稳健尺度换算，使典型变化量大致可比较。所有 utility 权重同样要求非负。

正式 Rank 规格为：

```text
nonnegative soft pairwise logistic + scaled + alpha=100
```

输出包括 utility、两两胜出概率、名次、排名百分位和平均预期胜率。名次取决于当前比较集合；同一设备换一批参考设备后名次数字变化，不代表模型自相矛盾。

## 10. 模型参数与超参数怎样优化

需要区分：

- **模型参数**：Score/Rank 的特征权重、Score 截距和 PC 偏移，由数值优化器从训练数据学习；
- **超参数**：模型家族、预处理方式、alpha、PCA 维数，通过开发 PC 验证选择；
- **固定协议参数**：随机种子、概率编码、蒙特卡洛次数、OOD 阈值等，预先写入配置，不使用冻结 7 台优化。

### 10.1 Score 候选

| 候选 | 网格 | 数量 |
|---|---|---:|
| Ridge + robust | alpha = 0.1、1、10、100 | 4 |
| Ridge + block | alpha = 0.1、1、10、100 | 4 |
| Huber + robust | alpha = 1、10 | 2 |
| PCA + Ridge | 2/3/4 维 × 4 个 alpha | 12 |

共评估 22 个候选，其中 PCA 只能诊断、不能部署。Huber 在小误差时使用平方损失、在大误差时转为近似线性损失，阈值为 `1.35 × overall稳健尺度`，用于降低离群设备对拟合的支配。

### 10.2 Rank 候选

```text
scaled/block × alpha={0.01, 0.1, 1, 10, 100}
```

共 10 个候选。Rank 使用加权软交叉熵加 L2 正则，alpha 越大，utility 差和输出概率通常越保守。

### 10.3 嵌套 Leave-One-PC-Out

开发 PC 只有 5 台，因此使用嵌套留一：

1. 外层完全封存 1 台开发 PC；
2. 剩余 4 台 PC 内部再留一，比较候选并选择参数；
3. 使用选定候选在 17 tablet + 4 PC 上重训；
4. 预测外层封存 PC；
5. 5 台开发 PC 轮流封存一次。

这样外层预测连“选哪个 alpha”这一步也没有看过当前设备。17 台 tablet 始终作为辅助训练数据，开发 PC 决定面向 PC 的验证表现。

Score 以 MAE 为主、RMSE 为辅，不使用排名指标选 Score；Rank 以 pairwise log loss 为主、Brier 为辅，不只看方向准确率。

### 10.4 为什么没有机械选择数字最小的候选

Score 的开发 LOO 数值最优候选为 `ridge_block_alpha1`，MAE 2.502；正式选择的 `ridge_robust_alpha10` 为 2.598，仅差 0.096，处于预先规定的 0.5 分简洁容差内。规则在近似同好候选中优先 Ridge、robust 和更强正则，以减少对 5 台开发 PC 随机波动的追逐。

Rank 最低 log loss 为 block/100 的 0.202138；scaled/100 为 0.203206，只差 0.001068，处于预设 0.01 容差内，因此选择更简单的 scaled/100。开发 LOO 中 10 个 Rank 候选方向准确率均为 1.0，真正区分它们的是概率质量而非“排对几对”。

实现上，Score Ridge 使用带边界的线性最小二乘；Huber 与 Rank 使用 L-BFGS-B。Rank 系数初始值为 0.01，非负边界，最多 5000 次迭代，概率裁剪到 `[1e-6, 1-1e-6]` 防止 `log(0)`。这些是数值求解设置，不是根据冻结外测调出的质量参数。

## 11. 不确定性传播

原始定义已确认为：

```text
prediction_se = prediction_sd / sqrt(1000)
```

数据准备时恢复：

```text
prediction_sd = prediction_se × sqrt(1000)
```

随后执行 1000 次蒙特卡洛：

1. 只对四个第一层预测百分位按各自 `prediction_sd` 进行正态扰动；
2. 百分位超出 0–100 时裁剪；
3. 每次重新计算 Score、utility、名次和两两概率；
4. 取 2.5% 和 97.5% 分位作为有限区间。

该区间不包含实测特征误差、人工 overall 标签噪声、缺失填补误差、模型参数/模型选择不确定性，以及不同 subdir 或设备间的相关误差。因此输出统一标记 `ci_is_limited=true`，不能宣传为完整校准的 95% 预测区间。冻结 7 台实际只有 1 台真实 overall 落入该有限区间。

## 12. OOD 检测

OOD 表示输入超出模型熟悉的分布，不代表音质差。检测器只用 22 台开发设备拟合，并建立：

- 22 台全部开发设备参考；
- 5 台开发 PC 参考。

它检查某特征是否超出训练最小/最大值、robust z 是否超过 3.5，以及是否发生缺失填补。警告不会修改分数。

冻结 7 台相对 5 台开发 PC 全部触发 OOD；相对全部 22 台开发设备也有 6/7 触发。常见超范围来源包括 lowfreq、treble、balance 和 artefacts。这说明开发 PC 覆盖太窄，不能通过简单调宽阈值解决。

## 13. 当前正式结果

### 13.1 开发 PC 嵌套验证

| 任务 | 指标 | 结果 |
|---|---|---:|
| Score | MAE | 2.812 |
| Score | RMSE | 3.553 |
| Score | bias | +0.086 |
| Score | 最大绝对误差 | 6.261 |
| Rank | pairwise accuracy | 1.000 |
| Rank | pairwise Brier | 0.0108 |
| Rank | pairwise log loss | 0.2091 |

开发 Rank 输出有 20 条“外层设备对 peer”的有向记录，但底层只有 10 个无序 PC 对，而且共享设备和模型，不能视为 20 个完全独立样本。

### 13.2 7 台冻结 PC

| 任务 | 指标 | 结果 |
|---|---|---:|
| Score | MAE | 2.235 |
| Score | RMSE | 2.656 |
| Score | bias（预测−真实） | -2.235 |
| Score | 最大绝对误差 | 5.372 |
| Score | Spearman | 0.893 |
| Rank | pairwise accuracy | 0.905（19/21） |
| Rank | pairwise Brier | 0.0138 |
| Rank | pairwise log loss | 0.2624 |
| Rank | Kendall tau | 0.810 |

关键事实：

- 7 台 Score 全部低估，平均低估 2.235 分；
- `enzoh-` 误差最大，真实 89.102、预测 83.731，低估 5.372；
- Rank 的两项方向错误均涉及 `enzoh-`；
- Score 按预测分数排序也是 19/21 对正确；
- Rank 也是 19/21 对正确；
- 两种模型在冻结 7 台上的顺序完全相同，因此不能声称 Rank 比 Score 更准；
- Rank 的额外价值是直接提供两两胜出概率，Score 的额外价值是给出 0–100 的数值估计。

完整逐设备和逐对结果见 [`results/real/REAL_RESULTS_REPORT.md`](results/real/REAL_RESULTS_REPORT.md)、[`results/real/train/external_pc_predictions.csv`](results/real/train/external_pc_predictions.csv) 和 [`results/real/train/external_pc_pair_probabilities.csv`](results/real/train/external_pc_pair_probabilities.csv)。

## 14. “数据优化”的正确含义

当前合理的数据优化包括：

- 固定白名单、列契约和方向定义；
- 记录中文列映射、排除设备和文件哈希；
- 严格区分 OOF 与 inductive；
- 用第一层综合预测减少重复特征；
- 每折独立填补和缩放；
- 平衡 tablet/PC 的总训练影响；
- 使用稳健尺度、单调非负约束和正则；
- 嵌套验证选择参数；
- 固定 split 和一次性外测指纹；
- 对新分布提供 OOD 警告。

不允许的“优化”包括：

- 根据 overall 或真实名次补特征；
- 用全部 29 台先计算中位数或标准化；
- 看完冻结 7 台后重选 alpha、特征映射或切分；
- 因平均低估 2.235 分而直接给未来设备统一加 2.235；
- 因 post-hoc treble 实验看起来更好而改写正式冻结成绩；
- 删除表现差的设备；
- 把训练内第一层预测伪装成 OOF。

## 15. 为什么当前不用神经网络或复杂树模型

最终训练只有 22 台设备，却有 19 个输入，加上 Score 截距和 PC 偏移，样本量几乎与参数量相当。复杂模型很容易记住训练设备，而不是学到可推广规律。

当前线性、非负、强正则模型是主动的风险控制。更可靠的下一步依次是：

1. 增加覆盖更多品牌、形态和分数范围的独立 PC；
2. 优先补充当前 OOD 明显的 lowfreq、treble、balance、artefacts 区域；
3. 对主观评分进行重复测量，估计人工标签波动；
4. 建立更完整的相关误差和模型参数不确定性；
5. 若把已查看的 7 台纳入下一轮开发，必须另留一批全新 PC 作盲测；
6. 样本量明显增加后，再评估非线性、交互或集成模型。

## 16. 正式模型和代码位置

| 内容 | 路径 |
|---|---|
| 正式模型包 | [`models/real/overall_model_bundle.joblib`](models/real/overall_model_bundle.joblib) |
| 可读模型元数据 | [`models/real/overall_model_metadata.json`](models/real/overall_model_metadata.json) |
| Score 实现 | [`src/subjective_audio_quality/overall/score_model.py`](src/subjective_audio_quality/overall/score_model.py) |
| Rank 实现 | [`src/subjective_audio_quality/overall/rank_model.py`](src/subjective_audio_quality/overall/rank_model.py) |
| 数据替换与切分 | [`src/subjective_audio_quality/overall/data.py`](src/subjective_audio_quality/overall/data.py) |
| 原始真实数据准备 | [`src/subjective_audio_quality/overall/real_data.py`](src/subjective_audio_quality/overall/real_data.py) |
| 折内预处理 | [`src/subjective_audio_quality/overall/preprocessing.py`](src/subjective_audio_quality/overall/preprocessing.py) |
| 嵌套验证和候选选择 | [`src/subjective_audio_quality/overall/validation.py`](src/subjective_audio_quality/overall/validation.py) |
| 完整训练编排 | [`src/subjective_audio_quality/overall/training.py`](src/subjective_audio_quality/overall/training.py) |
| 新 PC 推理 | [`src/subjective_audio_quality/overall/prediction.py`](src/subjective_audio_quality/overall/prediction.py) |
| 蒙特卡洛传播 | [`src/subjective_audio_quality/overall/uncertainty.py`](src/subjective_audio_quality/overall/uncertainty.py) |
| OOD 检测 | [`src/subjective_audio_quality/overall/ood.py`](src/subjective_audio_quality/overall/ood.py) |
| 正式实验配置 | [`configs/experiment_real.json`](configs/experiment_real.json) |
| 正式替换规则 | [`configs/replacement_map_real.json`](configs/replacement_map_real.json) |
| 正式指标 | [`results/real/train/metrics.json`](results/real/train/metrics.json) |
| 防泄漏审计 | [`results/real/train/leakage_audit.json`](results/real/train/leakage_audit.json) |

安装、重跑训练和预测命令见项目根目录 [`README.md`](README.md)。

