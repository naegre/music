# Overall 评分与 PC 排名训练框架

本目录是在已有 subdir 子模型之上的第二层模型。它接收一行一台设备的子类分数，以及子模型产生的 `predicted_percentile`，分别训练：

1. **Score model**：预测 0 到 100 的 `overall` 数值，只按 MAE、RMSE、偏差等数值误差选型。
2. **Rank model**：预测 PC 之间的相对效用、排名和两两胜出概率，只按软排序损失和排名指标选型。

两者是不同模型，互不拿对方的指标调参。本轮真实白名单为 17 台平板和 12 台 PC；样本仍很小，不适合神经网络、树模型堆叠或高维无约束模型。本实现优先使用强正则、非负系数和严格的设备级验证。

> 2026-07-23 已完成首次真实训练与一次性冻结外测。完整结论见 `results/real/REAL_RESULTS_REPORT.md`；冻结外测指纹见 `results/real/train/external_evaluation_manifest.json`。禁止根据这 7 台外测结果修改映射、超参数或切分后重新评估。

> `data/synthetic/` 中除 `ipad` 行外均为程序生成的测试数据。合成结果只证明代码能跑通，绝不能作为真实模型精度。

## 当前正式模型速览（2026-07-23）

| 项目 | 当前正式定义 |
|---|---|
| 权威设备范围 | 29 台：17 tablet + 12 PC |
| 最终训练 | 17 tablet + 5 开发 PC |
| 一次性冻结外测 | 7 PC |
| 第二层输入 | 19 维；用 clarity、lowfreq、fullness、edginess 的第一层预测百分位替换 7 个原始字段，保留原始 treble |
| Score model | 非负 Ridge，robust 预处理，`alpha=10` |
| Rank model | 非负 soft pairwise logistic utility，scaled 预处理，`alpha=100` |
| 缺失处理 | 每个训练折独立拟合列中位数，留出设备和冻结设备不参与统计量计算 |
| 第一层来源 | 16 台有标签 tablet 使用 OOF；`ipadPro2022-` 与全部 PC 使用 inductive |
| 冻结 Score | MAE 2.235，RMSE 2.656，bias -2.235 |
| 冻结排序 | Score 与 Rank 均为 19/21 设备对方向正确，不能声称 Rank 比 Score 更准 |
| 主要限制 | 7 台冻结 PC 全部相对 5 台开发 PC 触发 OOD；7 台 Score 全部低估；有限 CI 不是完整预测区间 |

面向非 AI 背景读者的完整设计、数据处理、参数优化和结果解释见 [`MODEL_ANALYSIS_README.md`](MODEL_ANALYSIS_README.md)。真实逐设备结果见 [`results/real/REAL_RESULTS_REPORT.md`](results/real/REAL_RESULTS_REPORT.md)。

复现训练与新设备预测见 [`REPRODUCIBILITY.md`](REPRODUCIBILITY.md)；发布包边界见 [`PACKAGE_MANIFEST.md`](PACKAGE_MANIFEST.md)；从打包副本完成的测试、预测和复训核验见 [`VERIFICATION_REPORT.md`](VERIFICATION_REPORT.md)。

## 目录

```text
overall_device_quality_framework/
├── configs/
│   ├── feature_schema.json       # name、22 个子特征和 overall 的契约
│   ├── replacement_map.json      # 合成演示替换映射
│   ├── replacement_map_real.json # 真实四组替换；保留原始 treble
│   ├── experiment.json           # 合成演示配置
│   └── experiment_real.json      # 真实训练配置与 5/7 PC 切分
├── cli/                          # generate、train、predict 的命令实现
├── data/synthetic/               # 可重复生成的演示输入
├── models/synthetic/             # 演示训练得到的 joblib 和元数据
├── results/synthetic/            # 演示训练、外测和预测输出
├── scripts/
│   ├── run_demo.sh               # Linux 一键演示
│   └── run_real_training.sh      # Linux 真实数据训练入口
├── src/subjective_audio_quality/ # 可安装 Python 包
├── tests/                        # 单元和端到端测试
├── main.py                       # 统一入口
├── requirements.txt
├── pyproject.toml
├── README.md
└── FUNCTION_REFERENCE.md

src/subjective_audio_quality/overall/
├── config.py                     # 配置数据类
├── data.py                       # 校验、替换、冻结切分、来源审计
├── preprocessing.py              # 折内 robust/block/PCA 变换
├── score_model.py                # 非负 Ridge/Huber overall 分数模型
├── rank_model.py                 # 非负 soft pairwise 排名模型
├── validation.py                 # 嵌套 Leave-One-PC-Out
├── metrics.py                    # 分数、相关性和两两概率指标
├── uncertainty.py                # 配置的不确定性列蒙特卡洛传播
├── ood.py                        # 开发集范围外检测
├── synthetic.py                  # 合成数据生成器
├── training.py                   # 完整训练流程
└── prediction.py                 # 新 PC 推理和参考设备比较
```

## 输入 1：设备特征表

CSV 一行表示一台设备。列必须与 `configs/feature_schema.json` 一致：

```csv
name,loudness,dynamics_1_S,dynamics_2,timber_1,timber_2,treble_1,treble_2,edginess,balance,fullness,clarity_1_S,clarity_2,clarity_3_S,spatial_1,spatial_2,spatial_3_S,spatial_4_S,spatial_5_S,spatial_6_S,artefacts_1_S,artefacts_2,artefacts_3_S,overall
ipad,79.6,85.00,80.125,92.975,96.521,98.085,85.344,83.980,96.592,92.458,85.00,90.035,85.00,85.00,103.920,85.00,85.00,85.00,85.00,85.00,90.00,85.00,94.55
```

规则：

- 共 `name + 22 个子特征 + overall`，即 24 列。
- 所有子特征均为越大越好。
- `_S` 表示主观评分。子特征可以超过 100，不会被截断。
- `overall` 必须在 `[0, 100]`。
- 训练必须有 `overall`，新设备推理可以没有。推理输入如果保留 `overall`，程序会额外生成有标签评估。
- 设备名不能为空或重复。

## 输入 2：设备域

```csv
name,domain
ipad,tablet
PC_Atlas,pc
```

只接受 `tablet` 和 `pc`。最终排名是 PC 内部排名，不训练平板-PC 的偏好关系。

## 输入 3：子模型预测

长表格式，每个 `name + subdir` 一行：

```csv
name,subdir,predicted_percentile,prediction_se,prediction_source
ipad,clarity,88.2,2.4,oof
PC_Atlas,clarity,71.5,3.1,inductive
```

- `predicted_percentile` 必须在 `[0, 100]`。
- 原始 `prediction_se = prediction_sd / sqrt(1000)`。真实数据准备会保留该列并新增 `prediction_sd = prediction_se * sqrt(1000)`；蒙特卡洛使用 `prediction_sd`，两者都不作为质量特征。
- 被子模型标签训练使用过的平板必须为严格 OOF；从未作为子模型标签的平板可为 inductive。本轮具体为 16 台 OOF，`ipadPro2022-` 为 inductive。
- 开发、外测和新 PC 都必须是不使用该设备人工标签得到的归纳预测，`prediction_source=inductive`。
- 需要替换的任何 `name + subdir` 缺失都会拒绝运行。

## 输入 4：替换映射

replacement JSON 决定多列如何折叠成一个模型预测特征；`replacement_map.json` 用于合成演示，`replacement_map_real.json` 用于本轮真实数据：

```json
{
  "clarity": {
    "replace": ["clarity_1_S", "clarity_2", "clarity_3_S"],
    "prediction_column": "predicted_percentile",
    "uncertainty_column": "prediction_se",
    "required": true
  }
}
```

上例会删除 3 个 clarity 原列，增加 1 个 `clarity__predicted_percentile`。JSON 未列出的特征保留实测值。本轮真实映射替换 clarity、lowfreq、fullness、edginess，保留原始 treble，最终为 19 维；该映射已经随冻结外测锁定。

## 冻结的 PC 切分

首次运行时，程序按 `overall` 分层抽取 5 台开发 PC，其余 PC 作为冻结外部测试。合成演示是 5/6；本轮 12 台真实 PC 固定为 5/7。切分保存为 `split.json`，后续运行必须复用：

```json
{
  "tablet_development": ["...17 tablets in the real run..."],
  "pc_development": ["...5 PCs..."],
  "pc_external": ["...7 PCs in the real run..."]
}
```

17 台真实平板与 5 台开发 PC 用于最终训练。7 台外测 PC 不参与缺失填补、标准化、超参数选择、PCA、模型拟合或 OOD 基准，只在模型完全固定后使用一次。

## Score Model 原理

候选包括非负 Ridge、非负 Huber、语义组均衡 Ridge，以及折内 PCA Ridge 诊断项。

- robust 和 block 候选先在每个训练折内做 `median / MAD` 标准化；MAD 为 0 时依次回退 IQR、标准差和 1。
- block 候选按组内特征数的平方根缩放，降低一组因列数多而重复计权的风险。
- Ridge 和 Huber 都强正则化；非 PCA 候选的质量系数强制 `>= 0`。
- 单独拟合一个无方向约束的 PC 域偏移，吸收平板到 PC 的平均域差异。
- 平板和 PC 各占一半总样本权重，避免 17 台平板淹没 5 台开发 PC。
- PCA 只在训练折内拟合并输出诊断结果。默认 `allow_pca_deployment=false`，因为主成分回投后无法保证每个原特征单调非负。
- 最终输出截断到 `[0, 100]`。

Score model 只用 PC 嵌套留一预测的 MAE/RMSE 选型，不拿 Spearman 或排名准确率决定数值模型。

## Rank Model 原理

排名模型是带 L2 正则和非负系数的 soft pairwise logistic utility model。

### 特征尺度

- `_S` 特征保留原始一分单位，符合“一分对应偏好提升 10 个百分点”的解释。
- 客观特征和 `predicted_percentile` 只用当前训练折统计量换算：一个 robust 特征跨度对应一个 robust overall 跨度。
- scaled 和语义 block 两种候选参与选择。
- 所有 utility 系数均强制 `>= 0`，保证任一越大越好的特征改善时，预测效用不会下降。

### 软排序标签

只对 overall 使用：

```text
P(A > B) = clip(0.5 + 0.1 * (overall_A - overall_B), 0, 1)
```

因此差 1 分为 60%，差 2 分为 70%，差 5 分恰好为 100%。这个公式不套用到单独 subdir。

训练只构造：

- PC-PC 对，作为目标域主证据。
- 平板-平板对，作为辅助证据。
- 不构造平板-PC 对。

两个域的 pair loss 各占一半总权重，避免大量平板组合对支配 PC 目标。

## 嵌套验证与防泄漏

对 5 台开发 PC 做外层 Leave-One-PC-Out：

1. 外层留出 1 台 PC。
2. 在剩余 4 台 PC 中再次 Leave-One-PC-Out，选择超参数。
3. 每个内折和外折都重新拟合 robust 尺度、block 因子、PCA、PC 偏移和模型。
4. 用选出的候选预测外层 PC。
5. 聚合 5 台完全未参与本折选择的外层预测，形成 nested OOF 指标。

`results/.../leakage_audit.json` 会记录这些边界。严格说 5 台 PC 的验证方差仍会很大，所以本轮同时保留 7 台冻结 PC 作为一次性外测。

## 安装

Windows PowerShell 或 Linux 终端均可执行：

```bash
conda create -n overall_audio python=3.10 -y
conda activate overall_audio
python -m pip install -r requirements.txt
python -m pip install -e .
```

依赖仅为 NumPy、pandas、SciPy、scikit-learn、joblib 和 pytest，不需要 CUDA。

本次正式训练的精确环境版本、Windows 完整复现命令和新 PC 输入要求见 [`REPRODUCIBILITY.md`](REPRODUCIBILITY.md)。宽范围 `requirements.txt` 用于兼容安装；若要最大程度复现当前 joblib 模型，应优先采用该文件记录的精确版本。

## 先跑合成演示

在项目根目录执行：

```bash
python main.py generate-synthetic
python main.py train
python main.py predict
```

或：

```bash
bash scripts/run_demo.sh
```

当前固定 seed 的 smoke test 结果如下，只用于核对流程没有崩溃或明显泄漏：

| 范围 | 指标 | 合成值 |
|---|---|---:|
| 5 台开发 PC nested OOF | score MAE | 0.602 |
| 5 台开发 PC nested OOF | rank pair accuracy | 1.000 |
| 6 台冻结 PC | score MAE | 0.759 |
| 6 台冻结 PC | rank pair accuracy | 0.733 |
| 6 台冻结 PC | rank Spearman | 0.714 |

开发折接近满分而冻结外测下降，正好提醒我们小样本开发指标会乐观。不要引用这些合成数字评价真实设备模型。

## 使用真实数据训练

先将四个原始 CSV 校验并复制成规范输入；Desktop 原文件不会被修改：

```bash
python main.py prepare-real
```

```bash
python main.py train \
  --overall-data data/real/overall_features.csv \
  --domains data/real/device_domains.csv \
  --submodel-predictions data/real/submodel_predictions.csv \
  --schema configs/feature_schema.json \
  --replacements configs/replacement_map_real.json \
  --experiment configs/experiment_real.json \
  --split data/real/frozen_pc_split.json \
  --output-dir results/real/train \
  --model-dir models/real
```

如果 `--split` 文件不存在，首次运行会创建；之后不要删除或重新抽取。Linux 也可以运行：

```bash
bash scripts/run_real_training.sh \
  /data/overall_features.csv \
  /data/device_domains.csv \
  /data/submodel_predictions.csv \
  /data/frozen_pc_split.json
```

## 预测新 PC

本轮将 7 台冻结 PC 作为 inductive 新设备、放入 5 台开发参考机尺度时，先执行只做行选择的准备命令：

```bash
python main.py prepare-real-predict
```

```bash
python main.py predict \
  --model models/real/overall_model_bundle.joblib \
  --overall-data /data/new_pc_features.csv \
  --domains /data/new_pc_domains.csv \
  --submodel-predictions /data/new_pc_submodel_predictions.csv \
  --output-dir results/real/predict
```

新设备名称不能与 bundle 内的 5 台开发 PC 参考设备重名。模型文件使用 joblib/pickle，只能加载可信来源。

## 训练输出

`results/<run>/train/`：

| 文件 | 含义 |
|---|---|
| `prepared_features.csv` | 替换后的最终训练矩阵 |
| `feature_metadata.csv` | 特征来源、主观标记、语义组和方向 |
| `replacement_audit.csv` | 每个映射删除/新增的列及预测来源计数 |
| `feature_uncertainty.csv` | 每台设备每个最终特征的配置不确定性；真实运行中为预测 SD |
| `missingness_audit.csv` | 全体、开发、外测的逐特征缺失计数 |
| `prediction_source_audit.csv` | 按域、subdir 和 OOF/inductive 的来源计数 |
| `frozen_split_copy.json` | 本次实际使用的冻结设备名单 |
| `score_nested_oof.csv` | 外层嵌套 PC 留一分数预测 |
| `score_nested_selections.csv` | 每个外折在内层选中的候选 |
| `score_candidate_comparison.csv` | 全部 exact score 候选的开发 PC LOO 比较 |
| `score_coefficients.csv` | 最终 score 原始单位系数，应全部非负 |
| `score_preprocessing_statistics.csv` | 最终 score 的开发集填补值和尺度统计 |
| `rank_nested_oof_pairs.csv` | 外层 PC 与开发 peer 的软概率预测 |
| `rank_nested_oof_devices.csv` | 每台外层 PC 的预期胜率 |
| `rank_candidate_comparison.csv` | 全部 exact rank 候选比较 |
| `rank_coefficients.csv` | 最终 rank 系数，应全部非负 |
| `rank_preprocessing_statistics.csv` | 最终 rank 的开发集填补值和尺度统计 |
| `external_pc_predictions.csv` | 冻结 PC 内部的分数、排名、CI 和 OOD；本轮为 7 台 |
| `external_pc_pair_probabilities.csv` | 冻结 PC 的两两概率；本轮为 21 对 |
| `metrics.json` / `metrics.csv` | 嵌套开发与冻结外测指标 |
| `leakage_audit.json` | 各类统计量和模型在哪个边界内拟合 |
| `external_evaluation_manifest.json` | 冻结数据、配置、split 和训练源码的一次性指纹锁 |

`models/<run>/`：

- `overall_model_bundle.joblib`：score、rank、OOD 检测器、特征契约和 5 台开发 PC 参考。
- `overall_model_metadata.json`：可直接阅读的模型选择与概率规则。

## 预测输出

| 文件 | 含义 |
|---|---|
| `new_device_rankings.csv` | 新 PC 的分数、组合排名、CI、邻近参考和 OOD |
| `combined_reference_rankings.csv` | 新 PC 与 5 台开发 PC 放在同一模型尺度后的名次 |
| `new_vs_reference_probabilities.csv` | `P(新 PC > 每台参考 PC)` 及 95% CI |
| `all_pair_probabilities.csv` | 本批所有设备对 |
| `new_device_ood_summary.csv` | 每台新 PC 的范围外摘要 |
| `new_device_ood_details.csv` | 触发范围外警告的具体特征 |
| `optional_labeled_evaluation.json` | 只有推理 CSV 带 overall 时才生成 |

`external_pc_predictions.csv` 的排名只在冻结 PC 内部计算；`predict/new_device_rankings.csv` 的排名是在新 PC 加 5 台开发参考 PC 的组合中计算。两列名相同但参考集合不同，不能直接比较名次数值。

## 指标解释

- **MAE**：overall 绝对误差均值，越低越好。
- **RMSE**：对大误差更敏感，越低越好。
- **bias**：`预测 - 真实` 均值，接近 0 较好。
- **Pearson**：数值线性关系。
- **Spearman**：排序的单调相关，1 为完全同序。
- **Kendall tau**：两两顺序一致程度，对小样本更直观。
- **pairwise accuracy**：忽略概率大小后，两两方向判断正确率。
- **pairwise Brier**：预测概率与软目标概率的平方误差，越低越好。
- **pairwise log loss**：对自信但错误的概率惩罚更重，越低越好。

没有脱离样本量和标签噪声的通用“优秀阈值”。这里每个开发指标只有 5 台 PC，本轮真实外测只有 7 台 PC，必须报告设备级结果、有限不确定性区间和逐对错误，而不能只看一个 Spearman。合成数据当前跑出的数字只用来发现实现错误，不用于判断真实方案优劣。

## 置信区间和 OOD

- 真实运行的蒙特卡洛仅按恢复出的子模型预测标准差 `prediction_sd` 抽样，再传播到 score、utility、排名和两两概率。
- 实测特征误差、人工标签误差和有限训练设备导致的模型参数不确定性尚未进入 CI，所以输出统一标记 `ci_is_limited=true`。
- OOD 同时对比全部开发设备和 5 台开发 PC 的 robust z 与训练范围。
- OOD 是“谨慎使用”的警告，不是自动判定音质差。
- 新 PC 若大量特征超出开发 PC 范围，应补充 PC 训练设备，而不是仅调整阈值隐藏警告。

## 真实数据复跑核对

1. 核对真实 CSV 确有 22 个特征，列名和 iPad 样例逐列对齐。
2. 使用已冻结的 `replacement_map_real.json`：只替换 clarity、lowfreq、fullness、edginess，保留 treble。
3. 确保 16 台有标签平板为 OOF，`ipadPro2022-` 与全部 PC 为 inductive。
4. 首次创建并提交冻结 `split.json`，之后不因外测表现反复抽取。
5. 复用现有 split 和外测 manifest；不得根据已经看过的 frozen external 指标改变配置再评估。
6. 检查非负系数、逐设备残差、逐对概率错误和 OOD，而不是只看汇总相关系数。
