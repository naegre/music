"""Monte Carlo propagation of submodel prediction uncertainty."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.special import expit

from .metrics import rank_summary
from .rank_model import OverallRankPipeline
from .score_model import OverallScorePipeline


def _sample_features(
    frame: pd.DataFrame,
    uncertainty: pd.DataFrame,
    feature_columns: tuple[str, ...],
    rng: np.random.Generator,
) -> pd.DataFrame:
    values = frame[list(feature_columns)].to_numpy(dtype=float)
    predictive_standard_deviations = uncertainty.loc[
        frame["name"].astype(str), list(feature_columns)
    ].to_numpy(dtype=float)
    sampled = values + rng.normal(size=values.shape) * predictive_standard_deviations
    for index, column in enumerate(feature_columns):
        if column.endswith("__predicted_percentile"):
            sampled[:, index] = np.clip(sampled[:, index], 0.0, 100.0)
    return pd.DataFrame(sampled, columns=feature_columns, index=frame.index)


def monte_carlo_group_predictions(
    score_model: OverallScorePipeline,
    rank_model: OverallRankPipeline,
    frame: pd.DataFrame,
    uncertainty: pd.DataFrame,
    feature_columns: tuple[str, ...],
    n_samples: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Propagate configured predictive SDs into score, utility, rank, and pairs."""

    if n_samples < 1:
        raise ValueError("n_samples must be at least 1")
    frame = frame.reset_index(drop=True).copy()
    names = frame["name"].astype(str).to_numpy()
    domains = frame["domain"].astype(str)
    point_score = score_model.predict(frame[list(feature_columns)], domains)
    point_utility = rank_model.utility(frame[list(feature_columns)])
    point_rank = rank_summary(names, point_utility).set_index("name").loc[names]
    rng = np.random.default_rng(seed)
    score_samples = np.empty((n_samples, len(frame)), dtype=float)
    utility_samples = np.empty_like(score_samples)
    rank_samples = np.empty_like(score_samples)
    win_samples = np.empty_like(score_samples)
    for sample_index in range(n_samples):
        sampled = _sample_features(frame, uncertainty, feature_columns, rng)
        score_samples[sample_index] = score_model.predict(sampled, domains)
        utility = rank_model.utility(sampled)
        utility_samples[sample_index] = utility
        ranks = pd.Series(-utility).rank(method="min").to_numpy(dtype=float)
        rank_samples[sample_index] = ranks
        if len(frame) == 1:
            win_samples[sample_index] = 50.0
        else:
            probability_matrix = expit(utility[:, None] - utility[None, :])
            win_samples[sample_index] = 100.0 * (
                (probability_matrix.sum(axis=1) - 0.5) / (len(frame) - 1)
            )
    predictive_standard_deviations = uncertainty.loc[
        names, list(feature_columns)
    ].to_numpy(dtype=float)
    has_input_uncertainty = np.any(predictive_standard_deviations > 0, axis=1)
    device_rows = []
    for index, name in enumerate(names):
        device_rows.append(
            {
                "name": name,
                "predicted_overall": float(point_score[index]),
                "predicted_overall_ci95_low": float(
                    np.quantile(score_samples[:, index], 0.025)
                ),
                "predicted_overall_ci95_high": float(
                    np.quantile(score_samples[:, index], 0.975)
                ),
                "rank_utility": float(point_utility[index]),
                "rank_utility_ci95_low": float(
                    np.quantile(utility_samples[:, index], 0.025)
                ),
                "rank_utility_ci95_high": float(
                    np.quantile(utility_samples[:, index], 0.975)
                ),
                "estimated_rank_1_is_best": int(
                    point_rank.loc[name, "rank_1_is_best"]
                ),
                "possible_rank_ci95_low": int(
                    np.floor(np.quantile(rank_samples[:, index], 0.025))
                ),
                "possible_rank_ci95_high": int(
                    np.ceil(np.quantile(rank_samples[:, index], 0.975))
                ),
                "rank_percentile": float(point_rank.loc[name, "rank_percentile"]),
                "expected_pairwise_win_percent": float(
                    point_rank.loc[name, "expected_pairwise_win_percent"]
                ),
                "expected_win_ci95_low": float(
                    np.quantile(win_samples[:, index], 0.025)
                ),
                "expected_win_ci95_high": float(
                    np.quantile(win_samples[:, index], 0.975)
                ),
                "ci_source": (
                    "configured_submodel_prediction_sd_only"
                    if has_input_uncertainty[index]
                    else "no_nonzero_input_uncertainty"
                ),
                "ci_is_limited": True,
            }
        )

    pair_rows: list[dict[str, object]] = []
    for left in range(len(names) - 1):
        for right in range(left + 1, len(names)):
            point_probability = float(expit(point_utility[left] - point_utility[right]))
            samples = expit(
                utility_samples[:, left] - utility_samples[:, right]
            )
            pair_rows.append(
                {
                    "left_name": names[left],
                    "right_name": names[right],
                    "predicted_probability_left_better": point_probability,
                    "probability_mc_mean": float(np.mean(samples)),
                    "probability_ci95_low": float(np.quantile(samples, 0.025)),
                    "probability_ci95_high": float(np.quantile(samples, 0.975)),
                    "ci_source": "configured_submodel_prediction_sd_only",
                }
            )
    return pd.DataFrame(device_rows), pd.DataFrame(pair_rows)
