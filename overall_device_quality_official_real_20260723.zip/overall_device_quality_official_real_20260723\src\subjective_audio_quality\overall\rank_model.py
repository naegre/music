"""PC-oriented soft pairwise ranking with within-domain training pairs."""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit

from .preprocessing import FoldMedianImputer, robust_scale


@dataclass(frozen=True)
class RankSpec:
    """One regularized, monotone pairwise ranking candidate."""

    alpha: float
    preprocessing: str = "scaled"

    @property
    def label(self) -> str:
        return f"soft_rank_{self.preprocessing}_alpha{self.alpha:g}"

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class RankFeatureScaler:
    """Median-impute and convert differences to a fold-local common scale.

    Subjective columns retain their native one-point unit. Other columns are
    rescaled so one robust feature spread equals one robust overall-score
    spread. Optional block equalization prevents groups with many correlated
    columns from receiving a larger prior influence merely through duplication.
    """

    def __init__(self, mode: str = "scaled"):
        self.mode = mode

    def fit(
        self,
        x: pd.DataFrame,
        y: np.ndarray,
        feature_metadata: pd.DataFrame,
    ) -> "RankFeatureScaler":
        if self.mode not in {"scaled", "block"}:
            raise ValueError(f"Unknown rank preprocessing mode: {self.mode}")
        self.feature_names_in_ = list(x.columns)
        metadata = feature_metadata.set_index("feature").loc[self.feature_names_in_]
        self.imputer_ = FoldMedianImputer().fit(x[self.feature_names_in_])
        imputed = self.imputer_.transform(x)
        _, self.target_scale_, self.target_scale_method_ = robust_scale(
            np.asarray(y, dtype=float)
        )
        centers: list[float] = []
        multipliers: list[float] = []
        methods: list[str] = []
        for index, column in enumerate(self.feature_names_in_):
            center, feature_scale, method = robust_scale(imputed[:, index])
            centers.append(center)
            methods.append(method)
            if bool(metadata.loc[column, "subjective"]):
                multipliers.append(1.0)
            else:
                multipliers.append(self.target_scale_ / feature_scale)
        self.center_ = np.asarray(centers, dtype=float)
        self.multiplier_ = np.asarray(multipliers, dtype=float)
        self.scale_methods_ = methods
        self.block_factor_ = np.ones(len(self.feature_names_in_), dtype=float)
        if self.mode == "block":
            counts = metadata["group"].value_counts().to_dict()
            self.block_factor_ = np.asarray(
                [1.0 / np.sqrt(counts[group]) for group in metadata["group"]],
                dtype=float,
            )
        self.effective_multiplier_ = self.multiplier_ * self.block_factor_
        return self

    def transform(self, x: pd.DataFrame) -> np.ndarray:
        values = self.imputer_.transform(x)
        return (values - self.center_) * self.effective_multiplier_

    def raw_feature_coefficients(self, coefficients: np.ndarray) -> np.ndarray:
        return np.asarray(coefficients, dtype=float) * self.effective_multiplier_

    def statistics_frame(self) -> pd.DataFrame:
        return pd.DataFrame(
            {
                "feature": self.feature_names_in_,
                "missing_count": self.imputer_.missing_count_,
                "impute_value": self.imputer_.impute_value_,
                "center": self.center_,
                "feature_to_overall_multiplier": self.multiplier_,
                "block_factor": self.block_factor_,
                "effective_multiplier": self.effective_multiplier_,
                "scale_method": self.scale_methods_,
            }
        )


def overall_preference_probability(
    score_difference: np.ndarray | float,
    probability_per_point: float = 0.1,
) -> np.ndarray:
    """Map an overall score difference to the specified soft preference.

    A +1 point difference maps to 0.60 and +5 points maps to 1.00. Values
    beyond +/-5 points are clipped to deterministic endpoints.
    """

    difference = np.asarray(score_difference, dtype=float)
    return np.clip(0.5 + probability_per_point * difference, 0.0, 1.0)


def make_within_domain_pairs(
    z: np.ndarray,
    y: np.ndarray,
    names: np.ndarray,
    domains: np.ndarray,
    probability_per_point: float,
) -> dict[str, np.ndarray]:
    """Build one oriented pair per unordered pair, never crossing domains."""

    z = np.asarray(z, dtype=float)
    y = np.asarray(y, dtype=float)
    names = np.asarray(names).astype(str)
    domains = np.asarray(domains).astype(str)
    differences: list[np.ndarray] = []
    targets: list[float] = []
    left_names: list[str] = []
    right_names: list[str] = []
    pair_domains: list[str] = []
    for domain in sorted(set(domains)):
        indices = np.flatnonzero(domains == domain)
        for left_position, left in enumerate(indices[:-1]):
            for right in indices[left_position + 1 :]:
                differences.append(z[left] - z[right])
                targets.append(
                    float(
                        overall_preference_probability(
                            y[left] - y[right], probability_per_point
                        )
                    )
                )
                left_names.append(names[left])
                right_names.append(names[right])
                pair_domains.append(domain)
    if not differences:
        raise ValueError("Pairwise ranking requires at least two devices in one domain")
    domain_array = np.asarray(pair_domains, dtype=str)
    weights = np.zeros(len(domain_array), dtype=float)
    unique_domains = sorted(set(domain_array))
    for domain in unique_domains:
        mask = domain_array == domain
        weights[mask] = 1.0 / (len(unique_domains) * int(mask.sum()))
    weights *= len(weights)
    return {
        "differences": np.vstack(differences),
        "targets": np.asarray(targets, dtype=float),
        "weights": weights,
        "left_names": np.asarray(left_names, dtype=str),
        "right_names": np.asarray(right_names, dtype=str),
        "domains": domain_array,
    }


class SoftPairwiseRanker:
    """Nonnegative logistic utility model fitted to soft pair labels."""

    def __init__(self, alpha: float, probability_clip: float = 1e-6):
        self.alpha = float(alpha)
        self.probability_clip = float(probability_clip)

    def fit(
        self,
        differences: np.ndarray,
        targets: np.ndarray,
        weights: np.ndarray,
    ) -> "SoftPairwiseRanker":
        differences = np.asarray(differences, dtype=float)
        targets = np.asarray(targets, dtype=float)
        weights = np.asarray(weights, dtype=float)

        def objective(coefficients: np.ndarray) -> tuple[float, np.ndarray]:
            logits = differences @ coefficients
            probabilities = np.clip(
                expit(logits), self.probability_clip, 1.0 - self.probability_clip
            )
            cross_entropy = -targets * np.log(probabilities) - (
                1.0 - targets
            ) * np.log(1.0 - probabilities)
            value = float(
                np.dot(weights, cross_entropy)
                + 0.5 * self.alpha * np.dot(coefficients, coefficients)
            )
            gradient = differences.T @ (weights * (probabilities - targets))
            gradient += self.alpha * coefficients
            return value, gradient

        initial = np.full(differences.shape[1], 0.01, dtype=float)
        result = minimize(
            objective,
            initial,
            method="L-BFGS-B",
            jac=True,
            bounds=[(0.0, None)] * differences.shape[1],
            options={"maxiter": 5000, "ftol": 1e-12},
        )
        self.coef_ = np.maximum(result.x, 0.0)
        self.optimization_success_ = bool(result.success)
        self.optimization_message_ = str(result.message)
        return self

    def pair_probability(self, difference: np.ndarray) -> np.ndarray:
        return expit(np.asarray(difference, dtype=float) @ self.coef_)


class OverallRankPipeline:
    """Serializable rank scaler and pairwise utility estimator."""

    def __init__(
        self,
        spec: RankSpec,
        probability_per_point: float = 0.1,
        probability_clip: float = 1e-6,
    ):
        self.spec = spec
        self.probability_per_point = float(probability_per_point)
        self.probability_clip = float(probability_clip)

    def fit(
        self,
        x: pd.DataFrame,
        domains: pd.Series,
        y: np.ndarray,
        names: pd.Series,
        feature_metadata: pd.DataFrame,
    ) -> "OverallRankPipeline":
        self.scaler_ = RankFeatureScaler(self.spec.preprocessing).fit(
            x, np.asarray(y, dtype=float), feature_metadata
        )
        z = self.scaler_.transform(x)
        pairs = make_within_domain_pairs(
            z,
            np.asarray(y, dtype=float),
            names.astype(str).to_numpy(),
            domains.astype(str).to_numpy(),
            self.probability_per_point,
        )
        self.ranker_ = SoftPairwiseRanker(
            self.spec.alpha, self.probability_clip
        ).fit(pairs["differences"], pairs["targets"], pairs["weights"])
        self.feature_metadata_ = feature_metadata.copy()
        self.training_pair_counts_ = {
            domain: int(np.sum(pairs["domains"] == domain))
            for domain in sorted(set(pairs["domains"]))
        }
        return self

    def utility(self, x: pd.DataFrame) -> np.ndarray:
        return self.scaler_.transform(x) @ self.ranker_.coef_

    def pair_probability(self, left: pd.DataFrame, right: pd.DataFrame) -> np.ndarray:
        difference = self.scaler_.transform(left) - self.scaler_.transform(right)
        return self.ranker_.pair_probability(difference)

    def statistics_frame(self) -> pd.DataFrame:
        """Return fold-fitted imputation and scaling statistics for auditing."""

        return self.scaler_.statistics_frame()

    def coefficient_frame(self) -> pd.DataFrame:
        return pd.DataFrame(
            {
                "feature": self.scaler_.feature_names_in_,
                "coefficient_model_scale": self.ranker_.coef_,
                "coefficient_original_units": self.scaler_.raw_feature_coefficients(
                    self.ranker_.coef_
                ),
                "preprocessing": self.spec.preprocessing,
            }
        )


def rank_candidates(alphas: tuple[float, ...]) -> list[RankSpec]:
    """Build ordinary and semantic-block-equalized rank candidates."""

    return [
        RankSpec(alpha=alpha, preprocessing=preprocessing)
        for preprocessing in ("scaled", "block")
        for alpha in alphas
    ]
