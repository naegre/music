"""Validation, replacement, feature metadata, and frozen device splits."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from subjective_audio_quality.config import load_json, save_json
from subjective_audio_quality.io import read_table

from .config import OverallSchema, ReplacementRule


@dataclass
class PreparedOverallData:
    """Model-ready device rows plus uncertainty and replacement audits."""

    frame: pd.DataFrame
    feature_columns: tuple[str, ...]
    feature_metadata: pd.DataFrame
    uncertainty: pd.DataFrame
    replacement_audit: pd.DataFrame


def load_and_validate_overall(
    path: str | Path,
    schema: OverallSchema,
    require_target: bool = True,
    allowed_names: set[str] | None = None,
) -> pd.DataFrame:
    """Load one-row-per-device data and enforce the declared 22-feature schema.

    When ``allowed_names`` is supplied, it is an authoritative whitelist and
    is applied before numeric validation.  Rows outside it cannot influence
    training audits, missingness checks, or downstream model statistics.
    """

    frame = read_table(path)
    if schema.name_column not in frame.columns:
        raise ValueError(f"Overall table is missing columns: [{schema.name_column!r}]")
    frame = frame.copy()
    frame[schema.name_column] = frame[schema.name_column].astype(str).str.strip()
    if allowed_names is not None:
        whitelist = {str(name).strip() for name in allowed_names}
        available = set(frame[schema.name_column])
        missing_devices = sorted(whitelist - available)
        if missing_devices:
            raise ValueError(
                "Overall table is missing authoritative whitelist devices: "
                f"{missing_devices}"
            )
        frame = frame[frame[schema.name_column].isin(whitelist)].copy()
    required = {schema.name_column, *schema.feature_columns}
    if require_target:
        required.add(schema.target_column)
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Overall table is missing columns: {missing}")
    if frame[schema.name_column].eq("").any() or frame[schema.name_column].duplicated().any():
        raise ValueError("Device names must be non-empty and unique")
    numeric = list(schema.feature_columns)
    if schema.target_column in frame:
        numeric.append(schema.target_column)
    for column in numeric:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    feature_values = frame[list(schema.feature_columns)].to_numpy(dtype=float)
    if np.isinf(feature_values).any():
        bad = frame.index[np.isinf(feature_values).any(axis=1)].tolist()
        raise ValueError(f"Infinite feature values in overall table at rows: {bad[:10]}")
    if np.isnan(feature_values).all(axis=0).any():
        columns = np.asarray(schema.feature_columns)[np.isnan(feature_values).all(axis=0)]
        raise ValueError(f"Overall feature columns are entirely missing: {columns.tolist()}")
    if schema.target_column in frame and not np.isfinite(
        frame[schema.target_column].to_numpy(dtype=float)
    ).all():
        raise ValueError("overall must be finite for every training device")
    if schema.target_column in frame and not frame[schema.target_column].between(0.0, 100.0).all():
        raise ValueError("overall must be within [0, 100]; subfeatures are not clipped")
    return frame


def load_domains(path: str | Path) -> pd.DataFrame:
    """Load ``name,domain`` where domain is exactly ``tablet`` or ``pc``."""

    domains = read_table(path)
    if not {"name", "domain"}.issubset(domains.columns):
        raise ValueError("Domain table requires name and domain columns")
    domains = domains[["name", "domain"]].copy()
    domains["name"] = domains["name"].astype(str).str.strip()
    domains["domain"] = domains["domain"].astype(str).str.strip().str.lower()
    if domains["name"].duplicated().any():
        raise ValueError("Domain table contains duplicate device names")
    invalid = sorted(set(domains["domain"]) - {"tablet", "pc"})
    if invalid:
        raise ValueError(f"Unsupported domains: {invalid}")
    return domains


def load_submodel_predictions(path: str | Path) -> pd.DataFrame:
    """Load long-form submodel percentiles and optional uncertainty/source fields."""

    predictions = read_table(path)
    required = {"name", "subdir", "predicted_percentile"}
    missing = sorted(required - set(predictions.columns))
    if missing:
        raise ValueError(f"Submodel prediction table is missing: {missing}")
    predictions = predictions.copy()
    predictions["name"] = predictions["name"].astype(str).str.strip()
    predictions["subdir"] = predictions["subdir"].astype(str).str.strip()
    if predictions[["name", "subdir"]].eq("").any().any():
        raise ValueError("Submodel prediction name and subdir cannot be empty")
    predictions["predicted_percentile"] = pd.to_numeric(
        predictions["predicted_percentile"], errors="coerce"
    )
    if "prediction_se" not in predictions:
        predictions["prediction_se"] = 0.0
    predictions["prediction_se"] = pd.to_numeric(predictions["prediction_se"], errors="coerce")
    if "prediction_source" not in predictions:
        predictions["prediction_source"] = "unspecified"
    predictions["prediction_source"] = (
        predictions["prediction_source"].astype(str).str.strip().str.lower()
    )
    if "prediction_sd" in predictions:
        predictions["prediction_sd"] = pd.to_numeric(
            predictions["prediction_sd"], errors="coerce"
        )
    if predictions[["name", "subdir"]].duplicated().any():
        raise ValueError("Submodel predictions require one row per name + subdir")
    if not np.isfinite(predictions["predicted_percentile"].to_numpy(dtype=float)).all():
        raise ValueError("predicted_percentile must be finite")
    if not predictions["predicted_percentile"].between(0.0, 100.0).all():
        raise ValueError("predicted_percentile must be within [0, 100]")
    if not np.isfinite(predictions["prediction_se"].to_numpy(dtype=float)).all():
        raise ValueError("prediction_se must be finite")
    if (predictions["prediction_se"] < 0).any():
        raise ValueError("prediction_se cannot be negative")
    if "prediction_sd" in predictions:
        if not np.isfinite(predictions["prediction_sd"].to_numpy(dtype=float)).all():
            raise ValueError("prediction_sd must be finite")
        if (predictions["prediction_sd"] < 0).any():
            raise ValueError("prediction_sd cannot be negative")
    return predictions


def validate_prediction_sources(
    predictions: pd.DataFrame,
    rules: tuple[ReplacementRule, ...],
    tablet_names: list[str],
    pc_names: list[str],
) -> None:
    """Enforce label-safe provenance for every replacement prediction.

    A tablet that contributed a submodel label must use an OOF prediction.
    A tablet never used by the submodel may legitimately be inductive, so both
    explicit values are accepted for tablets.  PCs are deployment-domain
    devices and must always be inductive.  ``unspecified`` and in-sample
    predictions are rejected.
    """

    allowed = {
        **{name: {"oof", "inductive"} for name in tablet_names},
        **{name: {"inductive"} for name in pc_names},
    }
    relevant_subdirs = {rule.key for rule in rules}
    relevant = predictions[
        predictions["subdir"].isin(relevant_subdirs)
        & predictions["name"].isin(allowed)
    ]
    mismatches = []
    for row in relevant[["name", "subdir", "prediction_source"]].itertuples(index=False):
        source = str(row.prediction_source).strip().lower()
        if source not in allowed[row.name]:
            mismatches.append(
                f"{row.name}/{row.subdir}: {row.prediction_source!r}, "
                f"allowed {sorted(allowed[row.name])!r}"
            )
    expected_count = len(allowed) * len(relevant_subdirs)
    if len(relevant) != expected_count:
        raise ValueError(
            "Cannot audit submodel prediction sources because required name + subdir rows are missing"
        )
    if mismatches:
        raise ValueError(
            "Unsafe submodel prediction sources (first 10): " + "; ".join(mismatches[:10])
        )
    inconsistent = (
        relevant.groupby("name")["prediction_source"]
        .nunique(dropna=False)
        .loc[lambda values: values > 1]
    )
    if not inconsistent.empty:
        raise ValueError(
            "A device has inconsistent prediction_source across replacement subdirs: "
            f"{inconsistent.index.astype(str).tolist()}"
        )


def apply_replacements(
    overall: pd.DataFrame,
    domains: pd.DataFrame,
    predictions: pd.DataFrame,
    schema: OverallSchema,
    rules: tuple[ReplacementRule, ...],
) -> PreparedOverallData:
    """Collapse configured raw feature groups into predicted percentile features."""

    frame = overall.merge(
        domains,
        left_on=schema.name_column,
        right_on="name",
        how="left",
        validate="one_to_one",
        suffixes=("", "__domain"),
    )
    if frame["domain"].isna().any():
        missing = frame.loc[frame["domain"].isna(), schema.name_column].tolist()
        raise ValueError(f"Missing domain labels for devices: {missing}")
    if schema.name_column != "name" and "name__domain" in frame:
        frame = frame.drop(columns="name__domain")

    removed: set[str] = set()
    predicted_columns: list[str] = []
    uncertainty_values: dict[str, pd.Series] = {}
    audit_rows: list[dict[str, object]] = []
    for rule in rules:
        unknown = sorted(set(rule.replace) - set(schema.feature_columns))
        if unknown:
            raise ValueError(f"Replacement {rule.key!r} references unknown columns: {unknown}")
        selected = predictions[predictions["subdir"].eq(rule.key)].copy()
        value_column = rule.prediction_column
        uncertainty_column = rule.uncertainty_column
        if value_column not in selected or uncertainty_column not in selected:
            raise ValueError(
                f"Prediction columns missing for {rule.key}: {value_column}, {uncertainty_column}"
            )
        lookup = selected.set_index("name")
        names = frame[schema.name_column].astype(str)
        missing_names = sorted(set(names) - set(lookup.index.astype(str)))
        if missing_names and rule.required:
            raise ValueError(
                f"Required replacement {rule.key!r} is missing devices: {missing_names}"
            )
        final_column = f"{rule.key}__predicted_percentile"
        values = names.map(lookup[value_column])
        uncertainty = names.map(lookup[uncertainty_column])
        if rule.required and (values.isna().any() or uncertainty.isna().any()):
            raise ValueError(f"Required replacement {rule.key!r} contains missing values")
        frame[final_column] = values.to_numpy(dtype=float)
        uncertainty_values[final_column] = pd.Series(
            uncertainty.to_numpy(dtype=float), index=names.to_numpy(), name=final_column
        )
        removed.update(rule.replace)
        predicted_columns.append(final_column)
        source_counts = (
            selected[selected["name"].isin(names)]["prediction_source"]
            .astype(str)
            .value_counts()
            .to_dict()
        )
        audit_rows.append(
            {
                "replacement_key": rule.key,
                "removed_columns": "|".join(rule.replace),
                "new_column": final_column,
                "n_removed": len(rule.replace),
                "n_devices": int(values.notna().sum()),
                "prediction_sources": "|".join(
                    f"{key}:{value}" for key, value in sorted(source_counts.items())
                ),
            }
        )

    remaining = [column for column in schema.feature_columns if column not in removed]
    final_features = tuple(remaining + predicted_columns)
    output_columns = [schema.name_column, "domain", *final_features]
    if schema.target_column in frame:
        output_columns.append(schema.target_column)
    prepared = frame[output_columns].copy()
    values = prepared[list(final_features)].to_numpy(dtype=float)
    if np.isinf(values).any():
        columns = np.asarray(final_features)[np.isinf(values).any(axis=0)]
        raise ValueError(f"Prepared overall features contain infinite values: {columns.tolist()}")
    if np.isnan(values).all(axis=0).any():
        columns = np.asarray(final_features)[np.isnan(values).all(axis=0)]
        raise ValueError(f"Prepared overall features are entirely missing: {columns.tolist()}")

    metadata_rows = []
    for column in remaining:
        metadata_rows.append(
            {
                "feature": column,
                "source": "measured",
                "subjective": bool(column.endswith(schema.subjective_suffix)),
                "group": column.split("_", 1)[0],
                "direction": "higher_is_better",
            }
        )
    for rule, column in zip(rules, predicted_columns, strict=True):
        metadata_rows.append(
            {
                "feature": column,
                "source": f"submodel:{rule.key}",
                "subjective": False,
                "group": rule.key,
                "direction": "higher_is_better",
            }
        )
    metadata = pd.DataFrame(metadata_rows)
    uncertainty_frame = pd.DataFrame(
        0.0, index=prepared[schema.name_column].astype(str), columns=final_features
    )
    for column, values in uncertainty_values.items():
        uncertainty_frame.loc[values.index, column] = values
    uncertainty_frame.index.name = schema.name_column
    return PreparedOverallData(
        frame=prepared,
        feature_columns=final_features,
        feature_metadata=metadata,
        uncertainty=uncertainty_frame,
        replacement_audit=pd.DataFrame(audit_rows),
    )


def create_stratified_split(
    frame: pd.DataFrame,
    target_column: str,
    pc_development_count: int,
    seed: int,
) -> dict[str, object]:
    """Select one PC from each score stratum and freeze all remaining PCs externally."""

    tablets = sorted(frame.loc[frame["domain"].eq("tablet"), "name"].astype(str))
    pcs = frame.loc[frame["domain"].eq("pc"), ["name", target_column]].sort_values(
        target_column
    )
    if len(pcs) <= pc_development_count:
        raise ValueError("Need more PCs than pc_development_count to create an external set")
    rng = np.random.default_rng(seed)
    strata = np.array_split(np.arange(len(pcs)), pc_development_count)
    selected_positions = sorted(int(rng.choice(stratum)) for stratum in strata)
    pc_development = sorted(pcs.iloc[selected_positions]["name"].astype(str))
    pc_external = sorted(set(pcs["name"].astype(str)) - set(pc_development))
    stratum_audit = []
    for index, stratum in enumerate(strata):
        candidate_names = pcs.iloc[stratum]["name"].astype(str).tolist()
        selected_name = str(pcs.iloc[selected_positions[index]]["name"])
        stratum_audit.append(
            {
                "stratum": index + 1,
                "candidate_devices": candidate_names,
                "selected_development_device": selected_name,
            }
        )
    return {
        "schema_version": 1,
        "seed": int(seed),
        "strategy": "overall-stratified-once-then-frozen",
        "counts": {
            "tablet_development": len(tablets),
            "pc_development": len(pc_development),
            "pc_external": len(pc_external),
        },
        "pc_strata": stratum_audit,
        "tablet_development": tablets,
        "pc_development": pc_development,
        "pc_external": pc_external,
    }


def save_split(split: dict[str, object], path: str | Path) -> None:
    """Persist the immutable development/external device lists."""

    save_json(split, path)


def load_and_validate_split(
    path: str | Path,
    frame: pd.DataFrame,
    pc_development_count: int | None = None,
) -> dict[str, object]:
    """Load a split and verify exclusivity, coverage, and domain membership."""

    split = load_json(path)
    groups = {
        key: list(map(str, split[key]))
        for key in ("tablet_development", "pc_development", "pc_external")
    }
    all_names = [name for values in groups.values() for name in values]
    if len(all_names) != len(set(all_names)):
        raise ValueError("A device appears in multiple split groups")
    unknown = sorted(set(all_names) - set(frame["name"].astype(str)))
    if unknown:
        raise ValueError(f"Split references unknown devices: {unknown}")
    domain_map = frame.set_index("name")["domain"].astype(str)
    if any(domain_map[name] != "tablet" for name in groups["tablet_development"]):
        raise ValueError("tablet_development contains a non-tablet")
    if any(
        domain_map[name] != "pc"
        for name in groups["pc_development"] + groups["pc_external"]
    ):
        raise ValueError("PC split contains a non-PC")
    expected = set(frame["name"].astype(str))
    if set(all_names) != expected:
        raise ValueError(f"Split does not cover all devices: {sorted(expected - set(all_names))}")
    if pc_development_count is not None:
        if len(groups["pc_development"]) != int(pc_development_count):
            raise ValueError(
                "Frozen split PC development count does not match experiment: "
                f"{len(groups['pc_development'])} != {int(pc_development_count)}"
            )
        expected_pc_total = int(frame["domain"].eq("pc").sum())
        if len(groups["pc_external"]) != expected_pc_total - int(pc_development_count):
            raise ValueError("Frozen split PC external count is inconsistent with the whitelist")
    return split


def development_names(split: dict[str, object]) -> list[str]:
    """Return all tablets plus the five development PCs."""

    return list(split["tablet_development"]) + list(split["pc_development"])


def domain_balanced_weights(domains: pd.Series) -> np.ndarray:
    """Give tablet and PC domains equal total training weight."""

    domains = domains.astype(str).to_numpy()
    unique = sorted(set(domains))
    weights = np.zeros(len(domains), dtype=float)
    for domain in unique:
        mask = domains == domain
        weights[mask] = 1.0 / (len(unique) * int(mask.sum()))
    return weights * len(weights)
