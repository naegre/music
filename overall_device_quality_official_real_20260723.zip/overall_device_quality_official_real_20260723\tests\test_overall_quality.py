from __future__ import annotations

import json

import joblib
import numpy as np
import pandas as pd
import pytest

from subjective_audio_quality.config import save_json
from subjective_audio_quality.overall.config import (
    OverallExperiment,
    OverallSchema,
    load_replacement_rules,
)
from subjective_audio_quality.overall.data import (
    apply_replacements,
    create_stratified_split,
    load_and_validate_overall,
    load_and_validate_split,
    load_domains,
    load_submodel_predictions,
    save_split,
    validate_prediction_sources,
)
from subjective_audio_quality.overall.ood import RobustOODDetector
from subjective_audio_quality.overall.prediction import predict_new_devices
from subjective_audio_quality.overall.preprocessing import FoldMedianImputer
from subjective_audio_quality.overall.rank_model import (
    OverallRankPipeline,
    RankSpec,
    make_within_domain_pairs,
)
from subjective_audio_quality.overall.score_model import OverallScorePipeline, ScoreSpec
from subjective_audio_quality.overall.synthetic import IPAD_VALUES, generate_synthetic_dataset
from subjective_audio_quality.overall.training import train_overall_models
from subjective_audio_quality.overall.uncertainty import monte_carlo_group_predictions


ROOT = __import__("pathlib").Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "configs/feature_schema.json"
RULES_PATH = ROOT / "configs/replacement_map.json"
EXPERIMENT_PATH = ROOT / "configs/experiment.json"


def _generate(tmp_path):
    schema = OverallSchema.load(SCHEMA_PATH)
    rules = load_replacement_rules(RULES_PATH)
    experiment = OverallExperiment.load(EXPERIMENT_PATH)
    paths = generate_synthetic_dataset(
        tmp_path / "data",
        schema,
        rules,
        experiment.random_seed,
        experiment.pc_development_count,
    )
    return schema, rules, paths


def test_synthetic_schema_and_exact_ipad_row(tmp_path):
    schema, _, paths = _generate(tmp_path)
    frame = pd.read_csv(paths["overall_data"])
    assert frame.shape == (26, 24)
    assert list(frame.columns) == ["name", *schema.feature_columns, "overall"]
    ipad = frame.set_index("name").loc["ipad"]
    np.testing.assert_allclose(
        ipad[list(schema.feature_columns)].to_numpy(dtype=float),
        np.asarray(IPAD_VALUES),
    )
    assert ipad["overall"] == pytest.approx(94.55)
    split = json.loads(paths["split"].read_text(encoding="utf-8"))
    assert len(split["tablet_development"]) == 15
    assert len(split["pc_development"]) == 5
    assert len(split["pc_external"]) == 6


def test_replacement_collapses_groups_and_rejects_missing_prediction(tmp_path):
    schema, rules, paths = _generate(tmp_path)
    overall = load_and_validate_overall(paths["overall_data"], schema)
    domains = load_domains(paths["domains"])
    predictions = load_submodel_predictions(paths["submodel_predictions"])
    prepared = apply_replacements(overall, domains, predictions, schema, rules)
    assert len(prepared.feature_columns) == 19
    assert "clarity_1_S" not in prepared.feature_columns
    assert "clarity__predicted_percentile" in prepared.feature_columns
    missing = predictions[
        ~(
            predictions["name"].eq("ipad")
            & predictions["subdir"].eq("clarity")
        )
    ]
    with pytest.raises(ValueError, match="missing devices"):
        apply_replacements(overall, domains, missing, schema, rules)
    inductive_tablet = predictions.copy()
    inductive_tablet.loc[
        inductive_tablet["name"].eq("ipad"),
        "prediction_source",
    ] = "inductive"
    validate_prediction_sources(
        inductive_tablet,
        rules,
        tablet_names=["ipad"],
        pc_names=[],
    )

    unsafe = inductive_tablet.copy()
    unsafe.loc[
        unsafe["name"].eq("ipad") & unsafe["subdir"].eq("clarity"),
        "prediction_source",
    ] = "in_sample"
    with pytest.raises(ValueError, match="Unsafe submodel prediction sources"):
        validate_prediction_sources(
            unsafe,
            rules,
            tablet_names=["ipad"],
            pc_names=[],
        )


def test_real_replacement_map_keeps_treble_and_uses_prediction_sd(tmp_path):
    schema, _, paths = _generate(tmp_path)
    real_rules_path = tmp_path / "replacement_map_real.json"
    save_json(
        {
            "clarity": {
                "replace": ["clarity_1_S", "clarity_2", "clarity_3_S"],
                "prediction_column": "predicted_percentile",
                "uncertainty_column": "prediction_sd",
                "required": True,
            },
            "lowfreq": {
                "replace": ["timber_1", "timber_2"],
                "prediction_column": "predicted_percentile",
                "uncertainty_column": "prediction_sd",
                "required": True,
            },
            "fullness": {
                "replace": ["fullness"],
                "prediction_column": "predicted_percentile",
                "uncertainty_column": "prediction_sd",
                "required": True,
            },
            "edginess": {
                "replace": ["edginess"],
                "prediction_column": "predicted_percentile",
                "uncertainty_column": "prediction_sd",
                "required": True,
            },
        },
        real_rules_path,
    )
    rules = load_replacement_rules(real_rules_path)
    overall = load_and_validate_overall(paths["overall_data"], schema)
    domains = load_domains(paths["domains"])
    predictions = load_submodel_predictions(paths["submodel_predictions"])
    lowfreq = predictions[predictions["subdir"].eq("treble")].copy()
    lowfreq["subdir"] = "lowfreq"
    predictions = pd.concat(
        [predictions[~predictions["subdir"].eq("treble")], lowfreq],
        ignore_index=True,
    )
    predictions["prediction_sd"] = 7.5

    prepared = apply_replacements(overall, domains, predictions, schema, rules)

    assert len(prepared.feature_columns) == 19
    assert {"treble_1", "treble_2"}.issubset(prepared.feature_columns)
    assert "lowfreq__predicted_percentile" in prepared.feature_columns
    assert "prediction_sd" not in prepared.feature_columns
    assert "prediction_se" not in prepared.feature_columns
    predicted_features = [
        column
        for column in prepared.feature_columns
        if column.endswith("__predicted_percentile")
    ]
    assert predicted_features == [
        "clarity__predicted_percentile",
        "lowfreq__predicted_percentile",
        "fullness__predicted_percentile",
        "edginess__predicted_percentile",
    ]
    assert (prepared.uncertainty[predicted_features] == 7.5).all().all()
    assert (
        prepared.uncertainty[
            [column for column in prepared.feature_columns if column not in predicted_features]
        ]
        == 0.0
    ).all().all()


def test_pair_builder_never_crosses_domains_and_rank_is_monotone():
    z = np.asarray([[0.0, 1.0], [1.0, 1.0], [2.0, 2.0], [3.0, 2.0]])
    y = np.asarray([70.0, 72.0, 75.0, 78.0])
    names = np.asarray(["t1", "t2", "p1", "p2"])
    domains = np.asarray(["tablet", "tablet", "pc", "pc"])
    pairs = make_within_domain_pairs(z, y, names, domains, 0.1)
    assert len(pairs["targets"]) == 2
    assert set(pairs["domains"]) == {"tablet", "pc"}

    x = pd.DataFrame(z, columns=["f1", "f2"])
    metadata = pd.DataFrame(
        {
            "feature": ["f1", "f2"],
            "subjective": [False, True],
            "group": ["g1", "g2"],
        }
    )
    model = OverallRankPipeline(RankSpec(alpha=1.0)).fit(
        x, pd.Series(domains), y, pd.Series(names), metadata
    )
    assert np.all(model.ranker_.coef_ >= 0.0)


def test_fold_local_median_imputation_for_score_rank_and_ood():
    training = pd.DataFrame(
        {
            "f1": [1.0, np.nan, 3.0, 5.0, 7.0, 9.0],
            "f2": [10.0, 20.0, np.nan, 40.0, 50.0, 60.0],
        }
    )
    held_out = pd.DataFrame({"f1": [np.nan, 1000.0], "f2": [np.nan, 80.0]})
    imputer = FoldMedianImputer().fit(training)
    np.testing.assert_allclose(imputer.impute_value_, [5.0, 40.0])
    np.testing.assert_allclose(
        imputer.transform(held_out),
        [[5.0, 40.0], [1000.0, 80.0]],
    )

    metadata = pd.DataFrame(
        {
            "feature": ["f1", "f2"],
            "subjective": [False, True],
            "group": ["g1", "g2"],
        }
    )
    domains = pd.Series(["tablet", "tablet", "tablet", "pc", "pc", "pc"])
    names = pd.Series(["t1", "t2", "t3", "p1", "p2", "p3"])
    target = np.asarray([60.0, 64.0, 68.0, 72.0, 76.0, 80.0])

    score = OverallScorePipeline(ScoreSpec("ridge", "robust", 1.0)).fit(
        training, domains, target, metadata
    )
    rank = OverallRankPipeline(RankSpec(alpha=1.0)).fit(
        training, domains, target, names, metadata
    )
    score_stats = score.statistics_frame().set_index("feature")
    rank_stats = rank.statistics_frame().set_index("feature")
    assert score_stats.loc["f1", "impute_value"] == pytest.approx(5.0)
    assert score_stats.loc["f2", "impute_value"] == pytest.approx(40.0)
    assert rank_stats.loc["f1", "impute_value"] == pytest.approx(5.0)
    assert rank_stats.loc["f2", "impute_value"] == pytest.approx(40.0)
    assert np.isfinite(score.predict(held_out, pd.Series(["pc", "pc"]))).all()
    assert np.isfinite(rank.utility(held_out)).all()

    detector = RobustOODDetector(z_threshold=3.5).fit(training, domains)
    summary, details = detector.report(held_out.iloc[[0]], pd.Series(["held_out"]))
    assert detector.impute_values_.to_dict() == {"f1": 5.0, "f2": 40.0}
    assert summary.loc[0, "all_development_n_features_imputed"] == 2
    assert bool(summary.loc[0, "ood_warning"])
    missing_details = details[
        details["reference"].eq("all_development")
        & details["input_was_missing"]
    ].set_index("feature")
    assert missing_details.loc["f1", "value"] == pytest.approx(5.0)
    assert missing_details.loc["f2", "value"] == pytest.approx(40.0)


def test_real_size_split_is_17_tablets_5_development_pcs_and_7_external(tmp_path):
    tablets = [f"tablet_{index:02d}" for index in range(17)]
    pcs = [f"pc_{index:02d}" for index in range(12)]
    frame = pd.DataFrame(
        {
            "name": tablets + pcs,
            "domain": ["tablet"] * 17 + ["pc"] * 12,
            "overall": np.linspace(55.0, 95.0, 29),
        }
    )
    split = create_stratified_split(
        frame,
        target_column="overall",
        pc_development_count=5,
        seed=20260721,
    )
    assert len(split["tablet_development"]) == 17
    assert len(split["pc_development"]) == 5
    assert len(split["pc_external"]) == 7
    assert set(split["pc_development"]).isdisjoint(split["pc_external"])

    split_path = tmp_path / "frozen_split.json"
    save_split(split, split_path)
    validated = load_and_validate_split(split_path, frame, pc_development_count=5)
    assert validated == split

    wrong_count = dict(split)
    wrong_count["pc_development"] = list(split["pc_development"][:-1])
    wrong_count["pc_external"] = sorted(
        list(split["pc_external"]) + [split["pc_development"][-1]]
    )
    wrong_count_path = tmp_path / "wrong_count_split.json"
    save_split(wrong_count, wrong_count_path)
    with pytest.raises(ValueError, match="PC development count"):
        load_and_validate_split(
            wrong_count_path,
            frame,
            pc_development_count=5,
        )


def test_monte_carlo_uses_configured_prediction_sd_values():
    feature = "clarity__predicted_percentile"
    frame = pd.DataFrame(
        {
            "name": ["uncertain", "certain"],
            "domain": ["pc", "pc"],
            feature: [50.0, 50.0],
        }
    )
    uncertainty = pd.DataFrame(
        {feature: [8.0, 0.0]},
        index=pd.Index(["uncertain", "certain"], name="name"),
    )

    class IdentityScore:
        @staticmethod
        def predict(x, domains):
            return x[feature].to_numpy(dtype=float)

    class IdentityRank:
        @staticmethod
        def utility(x):
            return x[feature].to_numpy(dtype=float) / 20.0

    device_rows, _ = monte_carlo_group_predictions(
        IdentityScore(),
        IdentityRank(),
        frame,
        uncertainty,
        (feature,),
        n_samples=1000,
        seed=123,
    )
    results = device_rows.set_index("name")
    uncertain_width = (
        results.loc["uncertain", "predicted_overall_ci95_high"]
        - results.loc["uncertain", "predicted_overall_ci95_low"]
    )
    certain_width = (
        results.loc["certain", "predicted_overall_ci95_high"]
        - results.loc["certain", "predicted_overall_ci95_low"]
    )
    assert uncertain_width > 20.0
    assert certain_width == pytest.approx(0.0)
    assert results.loc["uncertain", "predicted_overall"] == pytest.approx(50.0)


def test_reduced_grid_end_to_end_train_and_predict(tmp_path):
    schema, _, paths = _generate(tmp_path)
    experiment = {
        "random_seed": 20260721,
        "pc_development_count": 5,
        "score_ridge_alphas": [1.0],
        "score_huber_alphas": [1.0],
        "score_huber_delta": 1.35,
        "pca_components": [2],
        "allow_pca_deployment": False,
        "rank_alphas": [1.0],
        "score_simplicity_tolerance": 0.5,
        "rank_simplicity_tolerance": 0.01,
        "overall_probability_per_point": 0.1,
        "probability_clip": 1e-6,
        "monte_carlo_samples": 20,
        "ood_z_threshold": 3.5,
    }
    experiment_path = tmp_path / "experiment.json"
    save_json(experiment, experiment_path)
    outputs = train_overall_models(
        paths["overall_data"],
        paths["domains"],
        paths["submodel_predictions"],
        SCHEMA_PATH,
        RULES_PATH,
        experiment_path,
        paths["split"],
        tmp_path / "train_results",
        tmp_path / "models",
    )
    assert outputs["model"].exists()
    bundle = joblib.load(outputs["model"])
    assert np.all(bundle["models"]["score"].regressor_.quality_coef_ >= 0.0)
    assert np.all(bundle["models"]["rank"].ranker_.coef_ >= 0.0)
    assert bundle["models"]["rank"].training_pair_counts_ == {
        "pc": 10,
        "tablet": 105,
    }
    nested = pd.read_csv(tmp_path / "train_results/score_nested_oof.csv")
    external = pd.read_csv(tmp_path / "train_results/external_pc_predictions.csv")
    assert len(nested) == 5
    assert len(external) == 6

    prediction_outputs = predict_new_devices(
        outputs["model"],
        paths["prediction_overall_data"],
        paths["prediction_domains"],
        paths["prediction_submodel_predictions"],
        tmp_path / "predict_results",
        monte_carlo_samples=20,
        seed=123,
    )
    predicted = pd.read_csv(prediction_outputs["new_rankings"])
    comparisons = pd.read_csv(prediction_outputs["comparisons"])
    assert len(predicted) == 6
    assert len(comparisons) == 30
    assert predicted["estimated_rank_1_is_best"].between(1, 11).all()
    assert comparisons["P_new_better"].between(0.0, 1.0).all()
