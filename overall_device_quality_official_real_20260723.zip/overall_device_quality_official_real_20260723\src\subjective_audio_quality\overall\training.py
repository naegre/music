"""End-to-end training orchestration for numeric score and PC rank models."""

from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from subjective_audio_quality.config import save_json
from subjective_audio_quality.io import write_csv
from subjective_audio_quality.persistence import save_bundle

from .config import OverallExperiment, OverallSchema, load_replacement_rules
from .data import (
    apply_replacements,
    create_stratified_split,
    development_names,
    load_and_validate_overall,
    load_and_validate_split,
    load_domains,
    load_submodel_predictions,
    save_split,
    validate_prediction_sources,
)
from .metrics import device_rank_metrics, regression_metrics, soft_pair_metrics
from .ood import RobustOODDetector
from .rank_model import OverallRankPipeline, rank_candidates
from .score_model import OverallScorePipeline, score_candidates
from .uncertainty import monte_carlo_group_predictions
from .validation import (
    choose_rank_spec,
    choose_score_spec,
    compare_rank_candidates,
    compare_score_candidates,
    nested_rank_validation,
    nested_score_validation,
)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _metric_frame(section: str, metrics: dict[str, object]) -> pd.DataFrame:
    return pd.DataFrame(
        [{"section": section, "metric": key, "value": value} for key, value in metrics.items()]
    )


def _prepare_split(
    split_path: Path,
    frame: pd.DataFrame,
    experiment: OverallExperiment,
    target_column: str,
) -> dict[str, object]:
    if split_path.exists():
        return load_and_validate_split(
            split_path, frame, experiment.pc_development_count
        )
    split = create_stratified_split(
        frame,
        target_column,
        experiment.pc_development_count,
        experiment.random_seed,
    )
    save_split(split, split_path)
    return split


def _sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _external_evaluation_fingerprint(
    input_paths: dict[str, str | Path],
    split: dict[str, object],
) -> dict[str, object]:
    """Fingerprint every frozen input plus training-critical Python sources."""

    source_root = Path(__file__).resolve().parent
    source_hashes = {
        str(path.relative_to(source_root)): _sha256_file(path)
        for path in sorted(source_root.glob("*.py"))
    }
    file_hashes = {
        key: _sha256_file(path) for key, path in sorted(input_paths.items())
    }
    payload: dict[str, object] = {
        "schema_version": 1,
        "input_sha256": file_hashes,
        "training_source_sha256": source_hashes,
        "split": split,
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    payload["fingerprint_sha256"] = hashlib.sha256(canonical).hexdigest()
    return payload


def _lock_external_evaluation(
    path: Path,
    fingerprint: dict[str, object],
    external_names: list[str],
) -> dict[str, object]:
    """Create or verify the guard before any frozen-external metric is computed."""

    manifest = {
        **fingerprint,
        "status": "evaluation_started",
        "external_devices": list(external_names),
        "policy": (
            "Frozen external labels may be evaluated only after model selection and final "
            "development fitting. Changed inputs, configuration, split, or training source "
            "must not overwrite this evaluation."
        ),
    }
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        if existing.get("fingerprint_sha256") != fingerprint["fingerprint_sha256"]:
            raise ValueError(
                "Frozen external evaluation is already locked for a different input, "
                "configuration, split, or training-source fingerprint"
            )
        return existing
    save_json(manifest, path)
    return manifest


def train_overall_models(
    overall_data_path: str | Path,
    domains_path: str | Path,
    submodel_predictions_path: str | Path,
    schema_path: str | Path,
    replacements_path: str | Path,
    experiment_path: str | Path,
    split_path: str | Path,
    output_dir: str | Path,
    model_dir: str | Path,
) -> dict[str, Path]:
    """Train, validate, externally audit, and persist both overall models."""

    output = Path(output_dir)
    models = Path(model_dir)
    output.mkdir(parents=True, exist_ok=True)
    models.mkdir(parents=True, exist_ok=True)
    schema = OverallSchema.load(schema_path)
    rules = load_replacement_rules(replacements_path)
    experiment = OverallExperiment.load(experiment_path)
    domains = load_domains(domains_path)
    raw = load_and_validate_overall(
        overall_data_path,
        schema,
        require_target=True,
        allowed_names=set(domains["name"].astype(str)),
    )
    predictions = load_submodel_predictions(submodel_predictions_path)
    prepared = apply_replacements(raw, domains, predictions, schema, rules)
    split = _prepare_split(
        Path(split_path), prepared.frame, experiment, schema.target_column
    )
    tablet_names = list(map(str, split["tablet_development"]))
    pc_development = list(map(str, split["pc_development"]))
    pc_external = list(map(str, split["pc_external"]))
    validate_prediction_sources(
        predictions,
        rules,
        tablet_names,
        pc_development + pc_external,
    )
    development = development_names(split)
    frame = prepared.frame.copy()
    feature_columns = prepared.feature_columns
    metadata = prepared.feature_metadata

    missingness_rows = []
    development_set = set(development_names(split))
    external_set = set(pc_external)
    for column in feature_columns:
        missing = frame[column].isna()
        missingness_rows.append(
            {
                "feature": column,
                "n_missing_all": int(missing.sum()),
                "n_missing_development": int(
                    (missing & frame["name"].isin(development_set)).sum()
                ),
                "n_missing_external": int(
                    (missing & frame["name"].isin(external_set)).sum()
                ),
            }
        )
    source_audit = (
        predictions[
            predictions["name"].isin(frame["name"])
            & predictions["subdir"].isin([rule.key for rule in rules])
        ]
        .merge(domains, on="name", how="left", validate="many_to_one")
        .groupby(["domain", "subdir", "prediction_source"], dropna=False)
        .size()
        .rename("n_rows")
        .reset_index()
    )

    write_csv(frame, output / "prepared_features.csv")
    write_csv(metadata, output / "feature_metadata.csv")
    write_csv(prepared.replacement_audit, output / "replacement_audit.csv")
    write_csv(prepared.uncertainty.reset_index(), output / "feature_uncertainty.csv")
    write_csv(pd.DataFrame(missingness_rows), output / "missingness_audit.csv")
    write_csv(source_audit, output / "prediction_source_audit.csv")
    save_json(split, output / "frozen_split_copy.json")

    score_specs = score_candidates(
        experiment.score_ridge_alphas,
        experiment.score_huber_alphas,
        experiment.pca_components,
        experiment.score_huber_delta,
    )
    score_nested, score_nested_selection = nested_score_validation(
        frame,
        feature_columns,
        metadata,
        tablet_names,
        pc_development,
        schema.target_column,
        score_specs,
        experiment.score_simplicity_tolerance,
        experiment.allow_pca_deployment,
    )
    score_nested_metrics = regression_metrics(
        score_nested["actual_overall"], score_nested["predicted_overall"]
    )
    score_comparison, score_candidate_predictions = compare_score_candidates(
        frame,
        feature_columns,
        metadata,
        tablet_names,
        pc_development,
        schema.target_column,
        score_specs,
    )
    selected_score_spec = choose_score_spec(
        score_comparison,
        score_specs,
        experiment.score_simplicity_tolerance,
        experiment.allow_pca_deployment,
    )
    score_comparison["selected_final"] = score_comparison["spec"].eq(
        selected_score_spec.label
    )
    score_comparison["deployable"] = experiment.allow_pca_deployment | score_comparison[
        "preprocessing"
    ].ne("pca")
    development_frame = frame.set_index("name").loc[development].reset_index()
    score_model = OverallScorePipeline(selected_score_spec).fit(
        development_frame[list(feature_columns)],
        development_frame["domain"],
        development_frame[schema.target_column].to_numpy(dtype=float),
        metadata,
    )

    rank_specs = rank_candidates(experiment.rank_alphas)
    rank_nested_pairs, rank_nested_devices, rank_nested_selection = (
        nested_rank_validation(
            frame,
            feature_columns,
            metadata,
            tablet_names,
            pc_development,
            schema.target_column,
            rank_specs,
            experiment.overall_probability_per_point,
            experiment.probability_clip,
            experiment.rank_simplicity_tolerance,
        )
    )
    rank_nested_pair_metrics = soft_pair_metrics(
        rank_nested_pairs["target_probability_heldout_better"],
        rank_nested_pairs["predicted_probability_heldout_better"],
        experiment.probability_clip,
    )
    rank_nested_device_metrics = device_rank_metrics(
        rank_nested_devices["actual_overall"],
        rank_nested_devices["oof_expected_win_percent"],
    )
    rank_comparison, rank_candidate_pairs, rank_candidate_devices = (
        compare_rank_candidates(
            frame,
            feature_columns,
            metadata,
            tablet_names,
            pc_development,
            schema.target_column,
            rank_specs,
            experiment.overall_probability_per_point,
            experiment.probability_clip,
        )
    )
    selected_rank_spec = choose_rank_spec(
        rank_comparison, rank_specs, experiment.rank_simplicity_tolerance
    )
    rank_comparison["selected_final"] = rank_comparison["spec"].eq(
        selected_rank_spec.label
    )
    rank_model = OverallRankPipeline(
        selected_rank_spec,
        experiment.overall_probability_per_point,
        experiment.probability_clip,
    ).fit(
        development_frame[list(feature_columns)],
        development_frame["domain"],
        development_frame[schema.target_column].to_numpy(dtype=float),
        development_frame["name"],
        metadata,
    )

    ood_detector = RobustOODDetector(experiment.ood_z_threshold).fit(
        development_frame[list(feature_columns)], development_frame["domain"]
    )
    external_manifest_path = output / "external_evaluation_manifest.json"
    external_fingerprint = _external_evaluation_fingerprint(
        {
            "overall_data": overall_data_path,
            "domains": domains_path,
            "submodel_predictions": submodel_predictions_path,
            "schema": schema_path,
            "replacements": replacements_path,
            "experiment": experiment_path,
            "split": split_path,
        },
        split,
    )
    external_manifest = _lock_external_evaluation(
        external_manifest_path, external_fingerprint, pc_external
    )
    external_frame = frame.set_index("name").loc[pc_external].reset_index()
    external_devices, external_pairs = monte_carlo_group_predictions(
        score_model,
        rank_model,
        external_frame,
        prepared.uncertainty,
        feature_columns,
        experiment.monte_carlo_samples,
        experiment.random_seed + 17,
    )
    external_devices = external_devices.merge(
        external_frame[["name", schema.target_column]], on="name", validate="one_to_one"
    )
    external_devices["score_residual"] = (
        external_devices["predicted_overall"] - external_devices[schema.target_column]
    )
    external_devices["score_abs_error"] = external_devices["score_residual"].abs()
    external_score_metrics = regression_metrics(
        external_devices[schema.target_column], external_devices["predicted_overall"]
    )
    external_rank_device_metrics = device_rank_metrics(
        external_devices[schema.target_column], external_devices["rank_utility"]
    )
    score_lookup = external_frame.set_index("name")[schema.target_column].to_dict()
    external_pairs["left_overall"] = external_pairs["left_name"].map(score_lookup)
    external_pairs["right_overall"] = external_pairs["right_name"].map(score_lookup)
    external_pairs["target_probability_left_better"] = np.clip(
        0.5
        + experiment.overall_probability_per_point
        * (external_pairs["left_overall"] - external_pairs["right_overall"]),
        0.0,
        1.0,
    )
    external_pairs["probability_error"] = (
        external_pairs["predicted_probability_left_better"]
        - external_pairs["target_probability_left_better"]
    )
    external_pairs["direction_correct"] = (
        external_pairs["predicted_probability_left_better"].gt(0.5)
        == external_pairs["target_probability_left_better"].gt(0.5)
    )
    external_pairs["overconfident_wrong"] = (
        ~external_pairs["direction_correct"]
        & external_pairs["predicted_probability_left_better"].sub(0.5).abs().ge(0.25)
    )
    external_rank_pair_metrics = soft_pair_metrics(
        external_pairs["target_probability_left_better"],
        external_pairs["predicted_probability_left_better"],
        experiment.probability_clip,
    )
    ood_summary, ood_details = ood_detector.report(
        external_frame[list(feature_columns)], external_frame["name"]
    )
    external_devices = external_devices.merge(
        ood_summary, on="name", validate="one_to_one"
    ).sort_values("estimated_rank_1_is_best")

    write_csv(score_nested, output / "score_nested_oof.csv")
    write_csv(score_nested_selection, output / "score_nested_selections.csv")
    write_csv(score_comparison, output / "score_candidate_comparison.csv")
    write_csv(
        score_candidate_predictions, output / "score_candidate_oof_predictions.csv"
    )
    write_csv(score_model.coefficient_frame(), output / "score_coefficients.csv")
    write_csv(
        score_model.statistics_frame(), output / "score_preprocessing_statistics.csv"
    )
    write_csv(rank_nested_pairs, output / "rank_nested_oof_pairs.csv")
    write_csv(rank_nested_devices, output / "rank_nested_oof_devices.csv")
    write_csv(rank_nested_selection, output / "rank_nested_selections.csv")
    write_csv(rank_comparison, output / "rank_candidate_comparison.csv")
    write_csv(rank_candidate_pairs, output / "rank_candidate_oof_pairs.csv")
    write_csv(rank_candidate_devices, output / "rank_candidate_oof_devices.csv")
    write_csv(rank_model.coefficient_frame(), output / "rank_coefficients.csv")
    write_csv(
        rank_model.statistics_frame(), output / "rank_preprocessing_statistics.csv"
    )
    write_csv(external_devices, output / "external_pc_predictions.csv")
    write_csv(external_pairs, output / "external_pc_pair_probabilities.csv")
    write_csv(ood_summary, output / "external_ood_summary.csv")
    write_csv(ood_details, output / "external_ood_details.csv")

    metrics = {
        "score_nested_pc_loo": score_nested_metrics,
        "rank_nested_pc_loo_pairs": rank_nested_pair_metrics,
        "rank_nested_pc_loo_devices": rank_nested_device_metrics,
        "external_pc_score": external_score_metrics,
        "external_pc_rank_pairs": external_rank_pair_metrics,
        "external_pc_rank_devices": external_rank_device_metrics,
    }
    metric_frames = [
        _metric_frame(section, values) for section, values in metrics.items()
    ]
    write_csv(pd.concat(metric_frames, ignore_index=True), output / "metrics.csv")
    save_json(_json_safe(metrics), output / "metrics.json")
    external_manifest["status"] = "evaluation_complete"
    external_manifest["metrics_file"] = "metrics.json"
    save_json(_json_safe(external_manifest), external_manifest_path)
    leakage_audit = {
        "robust_scaling": "fitted inside every score fold",
        "rank_feature_scaling": "fitted inside every rank fold",
        "candidate_selection": "inner leave-one-PC-out inside each outer PC fold",
        "external_pc_use": "never used for fitting or candidate selection",
        "replacement_predictions": (
            "labelled tablets use OOF predictions; explicitly unlabelled tablets and "
            "all PCs use inductive predictions, as recorded in the source audit"
        ),
        "ranking_pairs": "within-domain only; no tablet-PC pairs",
        "pca": (
            "diagnostic fold-local candidate; deployment disabled"
            if not experiment.allow_pca_deployment
            else "fold-local and eligible for deployment"
        ),
        "uncertainty": (
            "prediction_sd is used only for Monte Carlo intervals, never as a quality "
            "input; intervals exclude imputation, label, measured-feature, and model-"
            "parameter uncertainty"
        ),
        "missing_value_imputation": (
            "feature medians fitted independently inside every score/rank training fold; "
            "external PCs never contribute imputation values"
        ),
        "prediction_source_counts": source_audit.to_dict(orient="records"),
    }
    save_json(_json_safe(leakage_audit), output / "leakage_audit.json")

    reference_pc = development_frame[development_frame["domain"].eq("pc")].copy()
    reference_uncertainty = prepared.uncertainty.loc[
        reference_pc["name"].astype(str), list(feature_columns)
    ].copy()
    metadata_payload = {
        "bundle_type": "overall_score_and_pc_rank",
        "schema_version": 1,
        "selected_score_spec": selected_score_spec.to_dict(),
        "selected_rank_spec": selected_rank_spec.to_dict(),
        "feature_columns": list(feature_columns),
        "development_devices": development,
        "pc_reference_devices": reference_pc["name"].astype(str).tolist(),
        "external_devices": pc_external,
        "external_evaluation_fingerprint": external_fingerprint[
            "fingerprint_sha256"
        ],
        "probability_rule": {
            "formula": "clip(0.5 + 0.1 * (overall_A - overall_B), 0, 1)",
            "probability_per_point": experiment.overall_probability_per_point,
        },
        "ci_source": (
            "configured submodel uncertainty columns only: "
            + ", ".join(sorted({rule.uncertainty_column for rule in rules}))
        ),
        "missing_value_policy": "fold-local median imputation",
        "synthetic_warning": (
            "Metrics are framework checks only when trained on generated synthetic data."
        ),
    }
    bundle = {
        "models": {"score": score_model, "rank": rank_model},
        "ood_detector": ood_detector,
        "schema": schema,
        "replacement_rules": rules,
        "feature_columns": feature_columns,
        "feature_metadata": metadata,
        "reference_pc_frame": reference_pc[
            ["name", "domain", *feature_columns, schema.target_column]
        ].copy(),
        "reference_pc_uncertainty": reference_uncertainty,
        "experiment": experiment,
        "metadata": metadata_payload,
    }
    model_path = models / "overall_model_bundle.joblib"
    metadata_path = models / "overall_model_metadata.json"
    save_bundle(bundle, model_path, metadata_path)
    return {
        "model": model_path,
        "metadata": metadata_path,
        "metrics": output / "metrics.json",
        "external_predictions": output / "external_pc_predictions.csv",
        "external_pairs": output / "external_pc_pair_probabilities.csv",
    }
