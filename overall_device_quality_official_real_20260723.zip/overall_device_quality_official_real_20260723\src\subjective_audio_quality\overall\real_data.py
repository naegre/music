"""Prepare the confirmed real-device CSV inputs without modifying the sources.

This module is deliberately limited to deterministic schema conversion,
whitelist filtering, provenance labelling, and audit output.  It does not
impute missing values, create a development/external split, or fit a model.
"""

from __future__ import annotations

import hashlib
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from subjective_audio_quality.config import load_json, save_json
from subjective_audio_quality.io import write_csv

from .config import OverallSchema


BOOTSTRAP_DRAWS = 1000
SELECTED_SUBDIRS = ("clarity", "lowfreq", "fullness", "edginess")
EXPECTED_DOMAIN_COUNTS = {"tablet": 17, "pc": 12}

# The canonical names follow configs/feature_schema.json.  The mapping is
# semantic rather than positional, and preserves the user's `_S` convention.
SOURCE_TO_CANONICAL = {
    "name": "name",
    "响度-Perceived Loudness": "loudness",
    "动态-Dynamics_S": "dynamics_1_S",
    "动态-单频次Attack and Punch": "dynamics_2",
    "音色-Bass Srength and Powerful": "timber_1",
    "音色-Bass depth": "timber_2",
    "音色-Treble Extension": "treble_1",
    "音色-Treble Srength": "treble_2",
    "音色-Softness": "edginess",
    "音色-Balance": "balance",
    "音色-Fullness": "fullness",
    "清晰度-Detailed_S": "clarity_1_S",
    "清晰度-Vocal Clarity": "clarity_2",
    "清晰度-Instrument Clarity_S": "clarity_3_S",
    "空间感-Balance": "spatial_1",
    "空间感-Spatial Width": "spatial_2",
    "空间感-Envelopment_S": "spatial_3_S",
    "空间感-Localisabilty_S": "spatial_4_S",
    "空间感-Spatial Height_S": "spatial_5_S",
    "空间感-Spatial depth_S": "spatial_6_S",
    "音损-THD_S": "artefacts_1_S",
    "音损-R&B": "artefacts_2",
    "音损-杂音底噪_S": "artefacts_3_S",
    "overall": "overall",
}


def _read_csv(path: str | Path) -> pd.DataFrame:
    input_path = Path(path)
    if not input_path.is_file():
        raise FileNotFoundError(f"Input CSV does not exist: {input_path}")
    return pd.read_csv(input_path, encoding="utf-8-sig")


def _sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _clean_names(frame: pd.DataFrame, label: str) -> pd.DataFrame:
    if "name" not in frame:
        raise ValueError(f"{label} is missing the name column")
    output = frame.copy()
    missing = output["name"].isna()
    output["name"] = output["name"].astype("string").str.strip()
    if missing.any() or output["name"].isna().any() or output["name"].eq("").any():
        rows = output.index[missing | output["name"].isna() | output["name"].eq("")]
        raise ValueError(f"{label} has blank device names at rows: {rows[:10].tolist()}")
    return output


def _validate_domains(frame: pd.DataFrame) -> pd.DataFrame:
    expected_columns = ["name", "domain"]
    if list(frame.columns) != expected_columns:
        raise ValueError(
            "device_domain.csv must contain exactly name,domain in that order; "
            f"found {list(frame.columns)}"
        )
    domains = _clean_names(frame, "device_domain.csv")
    domains["domain"] = domains["domain"].astype("string").str.strip().str.lower()
    if domains["name"].duplicated().any():
        names = domains.loc[domains["name"].duplicated(keep=False), "name"].tolist()
        raise ValueError(f"device_domain.csv contains duplicate names: {names[:10]}")
    invalid_domains = sorted(set(domains["domain"]) - set(EXPECTED_DOMAIN_COUNTS))
    if invalid_domains:
        raise ValueError(f"Unsupported domain values: {invalid_domains}")
    counts = domains["domain"].value_counts().to_dict()
    if len(domains) != sum(EXPECTED_DOMAIN_COUNTS.values()) or counts != EXPECTED_DOMAIN_COUNTS:
        raise ValueError(
            "Authoritative whitelist must contain exactly 17 tablets and 12 PCs; "
            f"found {counts}"
        )
    return domains.astype({"name": str, "domain": str})


def _coerce_numeric_allowing_blank(
    frame: pd.DataFrame,
    columns: list[str],
    label: str,
) -> pd.DataFrame:
    output = frame.copy()
    for column in columns:
        original = output[column]
        converted = pd.to_numeric(original, errors="coerce")
        nonblank = original.notna() & original.astype("string").str.strip().ne("")
        bad_text = nonblank & converted.isna()
        if bad_text.any():
            rows = output.index[bad_text].tolist()
            raise ValueError(
                f"{label} has non-numeric values in {column!r} at rows: {rows[:10]}"
            )
        infinite = converted.notna() & ~np.isfinite(converted.to_numpy(dtype=float, na_value=np.nan))
        if infinite.any():
            rows = output.index[infinite].tolist()
            raise ValueError(
                f"{label} has infinite values in {column!r} at rows: {rows[:10]}"
            )
        output[column] = converted.astype(float)
    return output


def _prepare_overall(
    raw: pd.DataFrame,
    domains: pd.DataFrame,
    schema: OverallSchema,
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict[str, Any]]]:
    expected_canonical = (schema.name_column, *schema.feature_columns, schema.target_column)
    mapped_canonical = tuple(SOURCE_TO_CANONICAL.values())
    if schema.name_column != "name" or schema.target_column != "overall":
        raise ValueError("Real-data mapping requires schema name='name' and target='overall'")
    if set(mapped_canonical) != set(expected_canonical) or len(mapped_canonical) != 24:
        raise ValueError("Built-in Chinese column mapping does not match the configured schema")
    source_columns = set(SOURCE_TO_CANONICAL)
    actual_columns = set(raw.columns)
    if actual_columns != source_columns or len(raw.columns) != len(source_columns):
        missing = sorted(source_columns - actual_columns)
        extra = sorted(actual_columns - source_columns)
        raise ValueError(
            "device_score.csv must contain exactly name + 22 mapped features + overall; "
            f"missing={missing}, extra={extra}"
        )
    scores = _clean_names(raw, "device_score.csv")
    if scores["name"].duplicated().any():
        names = scores.loc[scores["name"].duplicated(keep=False), "name"].tolist()
        raise ValueError(f"device_score.csv contains duplicate names: {names[:10]}")
    numeric_sources = [column for column in SOURCE_TO_CANONICAL if column != "name"]
    scores = _coerce_numeric_allowing_blank(scores, numeric_sources, "device_score.csv")
    whitelist = set(domains["name"])
    missing_names = sorted(whitelist - set(scores["name"]))
    if missing_names:
        raise ValueError(f"device_score.csv is missing whitelist devices: {missing_names}")
    selected = domains[["name"]].merge(scores, on="name", how="left", validate="one_to_one")
    selected = selected.rename(columns=SOURCE_TO_CANONICAL)
    selected = selected[[schema.name_column, *schema.feature_columns, schema.target_column]]
    if selected[schema.target_column].isna().any():
        names = selected.loc[selected[schema.target_column].isna(), "name"].tolist()
        raise ValueError(f"overall is missing for whitelist devices: {names}")
    if not selected[schema.target_column].between(0.0, 100.0).all():
        names = selected.loc[
            ~selected[schema.target_column].between(0.0, 100.0), "name"
        ].tolist()
        raise ValueError(f"overall must be within [0, 100] for devices: {names}")

    domain_lookup = domains.set_index("name")["domain"]
    missing_cells: list[dict[str, Any]] = []
    for row in selected.itertuples(index=False):
        name = str(row.name)
        for canonical in schema.feature_columns:
            if pd.isna(getattr(row, canonical)):
                source = next(
                    key for key, value in SOURCE_TO_CANONICAL.items() if value == canonical
                )
                missing_cells.append(
                    {
                        "name": name,
                        "domain": str(domain_lookup[name]),
                        "source_column": source,
                        "canonical_column": canonical,
                    }
                )

    excluded = scores.loc[~scores["name"].isin(whitelist), ["name"]].copy()
    excluded["source_file"] = "device_score.csv"
    excluded["source_row"] = excluded.index + 2
    excluded["subdir"] = ""
    excluded["reason"] = "not_in_device_domain_whitelist"
    excluded = excluded[
        ["source_file", "source_row", "name", "subdir", "reason"]
    ]
    return selected, excluded, missing_cells


def _validate_prediction_input(frame: pd.DataFrame, label: str) -> pd.DataFrame:
    required = {"name", "subdir", "predicted_percentile", "prediction_se"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{label} is missing required columns: {missing}")
    predictions = _clean_names(frame, label)
    predictions["subdir"] = predictions["subdir"].astype("string").str.strip()
    if predictions["subdir"].isna().any() or predictions["subdir"].eq("").any():
        raise ValueError(f"{label} contains blank subdir values")
    if predictions[["name", "subdir"]].duplicated().any():
        duplicate = predictions.loc[
            predictions[["name", "subdir"]].duplicated(keep=False), ["name", "subdir"]
        ]
        raise ValueError(
            f"{label} contains duplicate name + subdir rows: "
            f"{duplicate.head(10).to_dict(orient='records')}"
        )
    predictions = _coerce_numeric_allowing_blank(
        predictions,
        ["predicted_percentile", "prediction_se"],
        label,
    )
    if predictions[["predicted_percentile", "prediction_se"]].isna().any().any():
        raise ValueError(f"{label} contains blank prediction or uncertainty values")
    if not predictions["predicted_percentile"].between(0.0, 100.0).all():
        raise ValueError(f"{label} predicted_percentile must be within [0, 100]")
    if (predictions["prediction_se"] < 0.0).any():
        raise ValueError(f"{label} prediction_se cannot be negative")
    if "status" in predictions and not predictions["status"].astype(str).eq("ok").all():
        bad = predictions.loc[
            ~predictions["status"].astype(str).eq("ok"), ["name", "subdir", "status"]
        ]
        raise ValueError(
            f"{label} contains non-ok predictions: {bad.head(10).to_dict(orient='records')}"
        )
    return predictions


def _prediction_exclusions(
    predictions: pd.DataFrame,
    label: str,
    whitelist: set[str],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for index, row in predictions.iterrows():
        reasons = []
        if str(row["name"]) not in whitelist:
            reasons.append("not_in_device_domain_whitelist")
        if str(row["subdir"]) not in SELECTED_SUBDIRS:
            reasons.append("subdir_not_selected")
        if reasons:
            rows.append(
                {
                    "source_file": label,
                    "source_row": int(index) + 2,
                    "name": str(row["name"]),
                    "subdir": str(row["subdir"]),
                    "reason": "|".join(reasons),
                }
            )
    return pd.DataFrame(
        rows,
        columns=["source_file", "source_row", "name", "subdir", "reason"],
    )


def _prepare_predictions(
    table_raw: pd.DataFrame,
    pc_raw: pd.DataFrame,
    score_names: set[str],
    domains: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    table = _validate_prediction_input(table_raw, "table_predicted_score.csv")
    pc = _validate_prediction_input(pc_raw, "pc_predicted_score.csv")
    domain_lookup = domains.set_index("name")["domain"].to_dict()
    tablet_names = {name for name, domain in domain_lookup.items() if domain == "tablet"}
    pc_names = {name for name, domain in domain_lookup.items() if domain == "pc"}

    wrong_table = sorted(set(table["name"]) & pc_names)
    wrong_pc = sorted(set(pc["name"]) & tablet_names)
    if wrong_table or wrong_pc:
        raise ValueError(
            "Prediction inputs conflict with authoritative domains: "
            f"PCs in table file={wrong_table}, tablets in PC file={wrong_pc}"
        )

    table_selected = table[
        table["name"].isin(tablet_names) & table["subdir"].isin(SELECTED_SUBDIRS)
    ].copy()
    pc_selected = pc[
        pc["name"].isin(pc_names) & pc["subdir"].isin(SELECTED_SUBDIRS)
    ].copy()
    table_selected["prediction_source"] = np.where(
        table_selected["name"].isin(score_names)
        & table_selected["name"].ne("ipadPro2022-"),
        "oof",
        "inductive",
    )
    pc_selected["prediction_source"] = "inductive"
    selected = pd.concat([table_selected, pc_selected], ignore_index=True, sort=False)
    selected["prediction_sd"] = selected["prediction_se"] * math.sqrt(BOOTSTRAP_DRAWS)

    expected_pairs = pd.MultiIndex.from_product(
        [domains["name"].tolist(), SELECTED_SUBDIRS], names=["name", "subdir"]
    )
    actual_pairs = pd.MultiIndex.from_frame(selected[["name", "subdir"]])
    missing_pairs = expected_pairs.difference(actual_pairs)
    extra_pairs = actual_pairs.difference(expected_pairs)
    if len(selected) != len(expected_pairs) or len(missing_pairs) or len(extra_pairs):
        raise ValueError(
            "Required prediction coverage is not exactly one row per whitelist device and "
            f"selected subdir; missing={list(missing_pairs[:10])}, "
            f"extra={list(extra_pairs[:10])}"
        )

    source_lookup = selected.set_index(["name", "subdir"])["prediction_source"]
    mismatches: list[str] = []
    for name in domains["name"]:
        domain = domain_lookup[name]
        expected_source = (
            "inductive"
            if domain == "pc" or name == "ipadPro2022-"
            else "oof"
        )
        for subdir in SELECTED_SUBDIRS:
            actual_source = str(source_lookup.loc[(name, subdir)])
            if actual_source != expected_source:
                mismatches.append(
                    f"{name}/{subdir}: {actual_source!r}, expected {expected_source!r}"
                )
    if mismatches:
        raise ValueError("Prediction source validation failed: " + "; ".join(mismatches[:10]))

    order = {name: index for index, name in enumerate(domains["name"])}
    subdir_order = {name: index for index, name in enumerate(SELECTED_SUBDIRS)}
    selected["__name_order"] = selected["name"].map(order)
    selected["__subdir_order"] = selected["subdir"].map(subdir_order)
    selected = selected.sort_values(["__name_order", "__subdir_order"]).drop(
        columns=["__name_order", "__subdir_order"]
    )
    leading = [
        "name",
        "subdir",
        "predicted_percentile",
        "prediction_se",
        "prediction_sd",
        "prediction_source",
    ]
    selected = selected[
        leading + [column for column in selected.columns if column not in leading]
    ].reset_index(drop=True)

    exclusions = pd.concat(
        [
            _prediction_exclusions(
                table, "table_predicted_score.csv", set(domains["name"])
            ),
            _prediction_exclusions(pc, "pc_predicted_score.csv", set(domains["name"])),
        ],
        ignore_index=True,
    )
    coverage = {
        "selected_subdirs": list(SELECTED_SUBDIRS),
        "expected_rows": int(len(expected_pairs)),
        "actual_rows": int(len(selected)),
        "rows_by_domain": {
            domain: int(
                selected["name"].isin(
                    domains.loc[domains["domain"].eq(domain), "name"]
                ).sum()
            )
            for domain in EXPECTED_DOMAIN_COUNTS
        },
        "rows_by_subdir": {
            key: int(value)
            for key, value in selected["subdir"].value_counts().sort_index().items()
        },
        "rows_by_prediction_source": {
            key: int(value)
            for key, value in selected["prediction_source"].value_counts().items()
        },
        "unique_name_subdir_pairs": int(
            selected[["name", "subdir"]].drop_duplicates().shape[0]
        ),
        "treble_rows_in_output": int(selected["subdir"].eq("treble").sum()),
    }
    return selected, exclusions, coverage


def _column_mapping(schema: OverallSchema) -> pd.DataFrame:
    canonical_to_source = {value: key for key, value in SOURCE_TO_CANONICAL.items()}
    ordered = [schema.name_column, *schema.feature_columns, schema.target_column]
    rows = []
    for position, canonical in enumerate(ordered):
        source = canonical_to_source[canonical]
        rows.append(
            {
                "position": position + 1,
                "source_column": source,
                "canonical_column": canonical,
                "source_is_subjective": source.endswith("_S"),
                "canonical_is_subjective": canonical.endswith("_S"),
            }
        )
    return pd.DataFrame(rows)


def prepare_real_data(
    device_score_path: str | Path,
    device_domain_path: str | Path,
    table_predictions_path: str | Path,
    pc_predictions_path: str | Path,
    output_dir: str | Path,
    schema: OverallSchema,
) -> dict[str, Path]:
    """Validate and convert the four confirmed real-data CSV files.

    Missing overall feature values are preserved as missing.  Fold-local
    imputation belongs to the training pipeline and is intentionally not
    performed here.
    """

    input_paths = {
        "device_score": Path(device_score_path),
        "device_domain": Path(device_domain_path),
        "table_predictions": Path(table_predictions_path),
        "pc_predictions": Path(pc_predictions_path),
    }
    raw_domains = _read_csv(input_paths["device_domain"])
    raw_scores = _read_csv(input_paths["device_score"])
    raw_table = _read_csv(input_paths["table_predictions"])
    raw_pc = _read_csv(input_paths["pc_predictions"])
    domains = _validate_domains(raw_domains)
    overall, score_exclusions, missing_cells = _prepare_overall(
        raw_scores, domains, schema
    )
    predictions, prediction_exclusions, coverage = _prepare_predictions(
        raw_table,
        raw_pc,
        set(_clean_names(raw_scores, "device_score.csv")["name"]),
        domains,
    )
    excluded = pd.concat(
        [score_exclusions, prediction_exclusions], ignore_index=True
    ).sort_values(["source_file", "source_row"], kind="stable")
    mapping = _column_mapping(schema)

    output = Path(output_dir)
    paths = {
        "overall_data": output / "overall_features.csv",
        "domains": output / "device_domains.csv",
        "submodel_predictions": output / "submodel_predictions.csv",
        "audit": output / "data_audit.json",
        "column_mapping": output / "column_mapping.csv",
        "excluded_rows": output / "excluded_rows.csv",
    }
    audit: dict[str, Any] = {
        "schema_version": 1,
        "authoritative_whitelist": {
            "rows": int(len(domains)),
            "unique_devices": int(domains["name"].nunique()),
            "domain_counts": {
                key: int(value)
                for key, value in domains["domain"].value_counts().items()
            },
        },
        "overall_features": {
            "rows": int(len(overall)),
            "columns": int(len(overall.columns)),
            "feature_columns": int(len(schema.feature_columns)),
            "missing_feature_cells": int(
                overall[list(schema.feature_columns)].isna().sum().sum()
            ),
            "missing_cells": missing_cells,
            "imputation_performed": False,
        },
        "submodel_predictions": coverage,
        "prediction_source_policy": {
            "tablet": (
                "oof when the device occurs in device_score.csv, except "
                "ipadPro2022-; otherwise inductive"
            ),
            "pc": "inductive",
        },
        "uncertainty": {
            "bootstrap_draws": BOOTSTRAP_DRAWS,
            "raw_column": "prediction_se",
            "raw_definition": "prediction_sd / sqrt(1000)",
            "derived_column": "prediction_sd",
            "derived_formula": "prediction_se * sqrt(1000)",
        },
        "excluded_rows": {
            "rows": int(len(excluded)),
            "by_source_file": {
                key: int(value)
                for key, value in excluded["source_file"].value_counts().items()
            },
            "reason_token_counts": {
                reason: int(excluded["reason"].str.contains(reason, regex=False).sum())
                for reason in (
                    "not_in_device_domain_whitelist",
                    "subdir_not_selected",
                )
            },
        },
        "input_files": {
            key: {
                "path": str(path.resolve()),
                "sha256": _sha256(path),
                "rows": int(
                    {
                        "device_score": len(raw_scores),
                        "device_domain": len(raw_domains),
                        "table_predictions": len(raw_table),
                        "pc_predictions": len(raw_pc),
                    }[key]
                ),
            }
            for key, path in input_paths.items()
        },
    }

    # All validation is complete before the first output is written.
    write_csv(overall, paths["overall_data"])
    write_csv(domains, paths["domains"])
    write_csv(predictions, paths["submodel_predictions"])
    write_csv(mapping, paths["column_mapping"])
    write_csv(excluded, paths["excluded_rows"])
    save_json(audit, paths["audit"])
    return paths


def prepare_frozen_pc_prediction_inputs(
    overall_data_path: str | Path,
    domains_path: str | Path,
    submodel_predictions_path: str | Path,
    split_path: str | Path,
    output_dir: str | Path,
) -> dict[str, Path]:
    """Create reproducible inductive-prediction inputs for the seven frozen PCs.

    This is a row selection only.  It does not transform features, fit any
    statistic, or change the frozen split.  ``overall`` is retained solely so
    the prediction command can write an optional labelled audit.
    """

    overall = _clean_names(_read_csv(overall_data_path), "overall_features.csv")
    domains = _validate_domains(_read_csv(domains_path))
    predictions = _validate_prediction_input(
        _read_csv(submodel_predictions_path), "submodel_predictions.csv"
    )
    split = load_json(split_path)
    required_groups = {"tablet_development", "pc_development", "pc_external"}
    if not required_groups.issubset(split):
        raise ValueError(f"Frozen split is missing groups: {sorted(required_groups - set(split))}")
    external_names = list(map(str, split["pc_external"]))
    if len(external_names) != 7 or len(set(external_names)) != 7:
        raise ValueError("Confirmed real-data split must contain exactly seven external PCs")
    domain_lookup = domains.set_index("name")["domain"]
    missing = sorted(set(external_names) - set(domain_lookup.index))
    if missing:
        raise ValueError(f"Frozen external PCs are absent from the whitelist: {missing}")
    if any(domain_lookup[name] != "pc" for name in external_names):
        raise ValueError("Frozen external prediction subset contains a non-PC device")
    missing_overall = sorted(set(external_names) - set(overall["name"]))
    if missing_overall:
        raise ValueError(
            f"Frozen external PCs are missing from overall_features.csv: {missing_overall}"
        )

    order = pd.DataFrame({"name": external_names, "__order": range(len(external_names))})
    selected_overall = order.merge(overall, on="name", how="left", validate="one_to_one")
    selected_overall = selected_overall.sort_values("__order").drop(columns="__order")
    selected_domains = order.merge(domains, on="name", how="left", validate="one_to_one")
    selected_domains = selected_domains.sort_values("__order").drop(columns="__order")
    selected_predictions = predictions[
        predictions["name"].isin(external_names)
        & predictions["subdir"].isin(SELECTED_SUBDIRS)
    ].copy()
    expected_rows = len(external_names) * len(SELECTED_SUBDIRS)
    if len(selected_predictions) != expected_rows:
        raise ValueError(
            f"Frozen PC prediction subset requires {expected_rows} rows; "
            f"found {len(selected_predictions)}"
        )
    if "prediction_source" not in selected_predictions or not selected_predictions[
        "prediction_source"
    ].astype(str).str.lower().eq("inductive").all():
        raise ValueError("Every frozen-PC submodel prediction must be inductive")
    name_order = {name: index for index, name in enumerate(external_names)}
    subdir_order = {name: index for index, name in enumerate(SELECTED_SUBDIRS)}
    selected_predictions["__name_order"] = selected_predictions["name"].map(name_order)
    selected_predictions["__subdir_order"] = selected_predictions["subdir"].map(subdir_order)
    selected_predictions = selected_predictions.sort_values(
        ["__name_order", "__subdir_order"]
    ).drop(columns=["__name_order", "__subdir_order"])

    output = Path(output_dir)
    paths = {
        "overall_data": output / "prediction_pc_features.csv",
        "domains": output / "prediction_pc_domains.csv",
        "submodel_predictions": output / "prediction_pc_submodels.csv",
        "audit": output / "prediction_input_audit.json",
    }
    write_csv(selected_overall, paths["overall_data"])
    write_csv(selected_domains, paths["domains"])
    write_csv(selected_predictions, paths["submodel_predictions"])
    save_json(
        {
            "schema_version": 1,
            "operation": "row_selection_only",
            "external_devices": external_names,
            "device_count": len(external_names),
            "submodel_rows": len(selected_predictions),
            "prediction_source": "inductive",
            "split_path": str(Path(split_path).resolve()),
        },
        paths["audit"],
    )
    return paths
