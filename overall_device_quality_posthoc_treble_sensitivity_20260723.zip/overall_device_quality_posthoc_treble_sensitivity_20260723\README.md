# Treble 事后敏感性实验补充包（非正式模型）

日期：2026-07-23

> **警告：**本实验是在正式冻结 7 台 PC 的标签已经查看之后进行。它只能描述预测对 treble 补值/替换是否敏感，不是新的冻结外测，不能替代正式 `models/real`，也不能用 20/21 的事后设备对结果证明泛化能力已经改善。

正式模型仍是：

```text
19 维；保留原始 treble_1/treble_2
Score = robust nonnegative Ridge, alpha=10
Rank  = scaled nonnegative soft pairwise model, alpha=100
```

本补充包包含：

- `analysis/prepare_treble_sensitivity_data.py`：只用开发数据拟合 treble 补值器；
- `analysis/compare_treble_sensitivity.py`：与正式基线做描述性比较；
- `data/experiments/posthoc_treble_sensitivity/`：18维替换方案输入及补值审计；
- `models/experiments/posthoc_treble_sensitivity/`：非正式替代模型；
- `results/experiments/posthoc_treble_sensitivity/`：训练、预测和比较结果。

它是正式私有包的补充资料，不是独立工程。若要重跑，应将上述目录放回正式项目的相同相对路径，并使用正式包中的 `src/`、`cli/`、`configs/`、`data/real/` 和 Python 环境。

描述性变化：

- 正式基线：19/21 对方向正确；
- post-hoc treble：20/21 对方向正确；
- 修正了 `enzoh- > hookeg-`；
- `air13-` 与 `enzoh-` 的方向仍错；
- 开发 nested Score MAE 从 2.812 变为 3.614，变差；
- 开发 nested Rank log loss 从 0.209 变为 0.230，变差；
- 7 台外测分数仍全部低估，7/7 相对开发 PC 仍触发 OOD。

完整说明见：

[`results/experiments/posthoc_treble_sensitivity/comparison/POSTHOC_TREBLE_SENSITIVITY_REPORT.md`](results/experiments/posthoc_treble_sensitivity/comparison/POSTHOC_TREBLE_SENSITIVITY_REPORT.md)

