#!/usr/bin/env python3
"""Compare the official frozen result with the post-hoc treble sensitivity run."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from subjective_audio_quality.config import save_json  # noqa: E402
from subjective_audio_quality.io import write_csv  # noqa: E402


def _load_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    baseline = PROJECT_ROOT / "results/real/train"
    sensitivity = (
        PROJECT_ROOT / "results/experiments/posthoc_treble_sensitivity/train"
    )
    output = PROJECT_ROOT / "results/experiments/posthoc_treble_sensitivity/comparison"

    baseline_devices = pd.read_csv(baseline / "external_pc_predictions.csv")
    sensitivity_devices = pd.read_csv(sensitivity / "external_pc_predictions.csv")
    device = baseline_devices[
        [
            "name",
            "overall",
            "predicted_overall",
            "score_residual",
            "rank_utility",
            "estimated_rank_1_is_best",
        ]
    ].merge(
        sensitivity_devices[
            [
                "name",
                "overall",
                "predicted_overall",
                "score_residual",
                "rank_utility",
                "estimated_rank_1_is_best",
            ]
        ],
        on=["name", "overall"],
        validate="one_to_one",
        suffixes=("_baseline", "_treble"),
    )
    device["actual_rank_1_is_best"] = (
        -device["overall"]
    ).rank(method="min").astype(int)
    device["baseline_rank_error"] = (
        device["estimated_rank_1_is_best_baseline"]
        - device["actual_rank_1_is_best"]
    )
    device["treble_rank_error"] = (
        device["estimated_rank_1_is_best_treble"]
        - device["actual_rank_1_is_best"]
    )
    device["delta_predicted_overall"] = (
        device["predicted_overall_treble"] - device["predicted_overall_baseline"]
    )
    device["delta_rank_treble_minus_baseline"] = (
        device["estimated_rank_1_is_best_treble"]
        - device["estimated_rank_1_is_best_baseline"]
    )
    device = device.sort_values("actual_rank_1_is_best")

    baseline_pairs = pd.read_csv(baseline / "external_pc_pair_probabilities.csv")
    sensitivity_pairs = pd.read_csv(
        sensitivity / "external_pc_pair_probabilities.csv"
    )
    pair_keys = ["left_name", "right_name"]
    pair = baseline_pairs[
        pair_keys
        + [
            "predicted_probability_left_better",
            "target_probability_left_better",
            "direction_correct",
        ]
    ].merge(
        sensitivity_pairs[
            pair_keys
            + [
                "predicted_probability_left_better",
                "target_probability_left_better",
                "direction_correct",
                "probability_ci95_low",
                "probability_ci95_high",
            ]
        ],
        on=pair_keys,
        validate="one_to_one",
        suffixes=("_baseline", "_treble"),
    )
    pair["probability_delta_treble_minus_baseline"] = (
        pair["predicted_probability_left_better_treble"]
        - pair["predicted_probability_left_better_baseline"]
    )
    pair["corrected_by_treble"] = (
        ~pair["direction_correct_baseline"].astype(bool)
        & pair["direction_correct_treble"].astype(bool)
    )
    pair["new_error_from_treble"] = (
        pair["direction_correct_baseline"].astype(bool)
        & ~pair["direction_correct_treble"].astype(bool)
    )

    baseline_metrics = _load_json(baseline / "metrics.json")
    sensitivity_metrics = _load_json(sensitivity / "metrics.json")
    metric_paths = {
        "nested_score_mae": ("score_nested_pc_loo", "mae"),
        "nested_score_rmse": ("score_nested_pc_loo", "rmse"),
        "nested_rank_log_loss": ("rank_nested_pc_loo_pairs", "pairwise_log_loss"),
        "external_score_mae": ("external_pc_score", "mae"),
        "external_score_rmse": ("external_pc_score", "rmse"),
        "external_score_bias": ("external_pc_score", "bias"),
        "external_rank_pair_accuracy": (
            "external_pc_rank_pairs",
            "pairwise_accuracy",
        ),
        "external_rank_brier": ("external_pc_rank_pairs", "pairwise_brier"),
        "external_rank_log_loss": (
            "external_pc_rank_pairs",
            "pairwise_log_loss",
        ),
        "external_rank_spearman": ("external_pc_rank_devices", "spearman"),
        "external_rank_kendall": ("external_pc_rank_devices", "kendall_tau"),
    }
    metric_rows = []
    for label, (section, key) in metric_paths.items():
        before = float(baseline_metrics[section][key])
        after = float(sensitivity_metrics[section][key])
        metric_rows.append(
            {
                "metric": label,
                "official_baseline": before,
                "posthoc_treble": after,
                "delta_treble_minus_baseline": after - before,
            }
        )
    metrics = pd.DataFrame(metric_rows)

    summary = {
        "status": "post_hoc_sensitivity_only",
        "warning": (
            "The seven external labels had already been observed before this feature-map "
            "change. These differences are descriptive and are not a new frozen test."
        ),
        "official_results_overwritten": False,
        "baseline_correct_pairs": int(
            baseline_pairs["direction_correct"].astype(bool).sum()
        ),
        "posthoc_treble_correct_pairs": int(
            sensitivity_pairs["direction_correct"].astype(bool).sum()
        ),
        "total_pairs": int(len(pair)),
        "corrected_pairs": pair.loc[
            pair["corrected_by_treble"], pair_keys
        ].to_dict(orient="records"),
        "new_error_pairs": pair.loc[
            pair["new_error_from_treble"], pair_keys
        ].to_dict(orient="records"),
        "baseline_exact_rank_devices": int((device["baseline_rank_error"] == 0).sum()),
        "posthoc_treble_exact_rank_devices": int(
            (device["treble_rank_error"] == 0).sum()
        ),
        "baseline_mean_absolute_rank_error": float(
            device["baseline_rank_error"].abs().mean()
        ),
        "posthoc_treble_mean_absolute_rank_error": float(
            device["treble_rank_error"].abs().mean()
        ),
        "all_posthoc_scores_underpredicted": bool(
            (device["score_residual_treble"] < 0).all()
        ),
    }

    write_csv(device, output / "device_rank_comparison.csv")
    write_csv(pair, output / "pair_probability_comparison.csv")
    write_csv(metrics, output / "metric_comparison.csv")
    save_json(summary, output / "comparison_summary.json")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
