#!/usr/bin/env python3
"""Prepare a post-hoc treble-replacement sensitivity dataset.

This script is intentionally isolated from the official frozen run.  Missing
treble percentiles are reconstructed without using ``overall`` or any frozen
external treble target.  The resulting data may be used only for sensitivity
analysis, never as a replacement frozen-test result.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.base import clone
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from subjective_audio_quality.config import load_json, save_json  # noqa: E402
from subjective_audio_quality.io import write_csv  # noqa: E402


BOOTSTRAP_DRAWS = 1000
BASE_SUBDIRS = ("clarity", "lowfreq", "fullness", "edginess")
PREDICTOR_COLUMNS = (
    "treble_1",
    "treble_2",
    "clarity",
    "lowfreq",
    "fullness",
    "edginess",
)
EXPECTED_MISSING_TREBLE = {"air13-", "air15-", "pro14-", "pro16-"}
SELECTED_METHOD = "ridge_all6_alpha10"


def _sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read_csv(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8-sig")


def _metrics(name: str, actual: np.ndarray, predicted: np.ndarray) -> dict[str, object]:
    residual = np.asarray(predicted, dtype=float) - np.asarray(actual, dtype=float)
    rho = spearmanr(actual, predicted).statistic
    return {
        "method": name,
        "n": int(len(actual)),
        "mae": float(np.mean(np.abs(residual))),
        "rmse": float(np.sqrt(np.mean(residual**2))),
        "bias": float(np.mean(residual)),
        "spearman": float(rho),
    }


def _loo_predictions(model, x: pd.DataFrame, y: np.ndarray) -> np.ndarray:
    prediction = cross_val_predict(model, x, y, cv=LeaveOneOut())
    return np.clip(np.asarray(prediction, dtype=float), 0.0, 100.0)


def _candidate_study(x: pd.DataFrame, y: np.ndarray) -> tuple[pd.DataFrame, np.ndarray]:
    median_predictions = np.asarray(
        [np.median(np.delete(y, index)) for index in range(len(y))], dtype=float
    )
    candidates = {
        "ridge_other4_alpha10": (
            make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
            list(BASE_SUBDIRS),
        ),
        SELECTED_METHOD: (
            make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
            list(PREDICTOR_COLUMNS),
        ),
        "knn_all6_k5": (
            make_pipeline(
                StandardScaler(), KNeighborsRegressor(n_neighbors=5, weights="uniform")
            ),
            list(PREDICTOR_COLUMNS),
        ),
    }
    rows = [_metrics("development_median", y, median_predictions)]
    selected_prediction: np.ndarray | None = None
    for name, (model, columns) in candidates.items():
        prediction = _loo_predictions(model, x[columns], y)
        rows.append(_metrics(name, y, prediction))
        if name == SELECTED_METHOD:
            selected_prediction = prediction
    if selected_prediction is None:
        raise RuntimeError("Selected treble imputation candidate was not evaluated")
    return pd.DataFrame(rows).sort_values(["mae", "rmse"]), selected_prediction


def prepare(
    overall_path: str | Path,
    domains_path: str | Path,
    base_predictions_path: str | Path,
    table_predictions_path: str | Path,
    pc_predictions_path: str | Path,
    split_path: str | Path,
    output_dir: str | Path,
) -> dict[str, Path]:
    overall = _read_csv(overall_path)
    domains = _read_csv(domains_path)
    base = _read_csv(base_predictions_path)
    table_raw = _read_csv(table_predictions_path)
    pc_raw = _read_csv(pc_predictions_path)
    split = load_json(split_path)

    whitelist = domains["name"].astype(str).tolist()
    domain_map = domains.set_index("name")["domain"].astype(str).to_dict()
    development_names = list(map(str, split["tablet_development"])) + list(
        map(str, split["pc_development"])
    )
    external_names = list(map(str, split["pc_external"]))

    base_selected = base[
        base["name"].isin(whitelist) & base["subdir"].isin(BASE_SUBDIRS)
    ].copy()
    pivot = base_selected.pivot(
        index="name", columns="subdir", values="predicted_percentile"
    )
    if pivot[list(BASE_SUBDIRS)].isna().any().any():
        raise ValueError("Four base submodel predictors must be complete")
    raw_treble_features = overall.set_index("name")[["treble_1", "treble_2"]]
    # Deliberately exclude the overall column from every imputation operation.
    predictors = raw_treble_features.join(pivot[list(BASE_SUBDIRS)], how="inner")
    predictors = predictors.loc[whitelist, list(PREDICTOR_COLUMNS)].astype(float)
    if not np.isfinite(predictors.to_numpy()).all():
        raise ValueError("Treble imputation predictors must be finite")

    observed_raw = pd.concat(
        [
            table_raw[table_raw["subdir"].eq("treble")],
            pc_raw[pc_raw["subdir"].eq("treble")],
        ],
        ignore_index=True,
        sort=False,
    )
    observed = observed_raw[
        observed_raw["name"].isin(whitelist)
        & observed_raw["status"].astype(str).eq("ok")
    ].copy()
    if observed["name"].duplicated().any():
        raise ValueError("Observed treble predictions contain duplicate devices")
    observed_names = set(observed["name"].astype(str))
    missing_names = set(whitelist) - observed_names
    if missing_names != EXPECTED_MISSING_TREBLE:
        raise ValueError(
            "Unexpected whitelist treble coverage; "
            f"missing={sorted(missing_names)}"
        )

    observed_lookup = observed.set_index("name")["predicted_percentile"].astype(float)
    imputer_training_names = [
        name for name in development_names if name in observed_lookup.index
    ]
    if len(imputer_training_names) != 20:
        raise ValueError(
            "Expected 17 tablets plus 3 development PCs with observed treble; "
            f"found {len(imputer_training_names)}"
        )
    x_train = predictors.loc[imputer_training_names]
    y_train = observed_lookup.loc[imputer_training_names].to_numpy(dtype=float)
    candidate_metrics, selected_loo = _candidate_study(x_train, y_train)
    selected_row = candidate_metrics.set_index("method").loc[SELECTED_METHOD]
    best_mae = float(candidate_metrics["mae"].min())
    if float(selected_row["mae"]) > best_mae + 0.5:
        raise ValueError(
            "Locked Ridge bridge is no longer within the 0.5-point simplicity "
            "tolerance of the best development-only treble candidate"
        )

    model = make_pipeline(StandardScaler(), Ridge(alpha=10.0)).fit(x_train, y_train)
    missing_order = [
        name for name in whitelist if name in EXPECTED_MISSING_TREBLE
    ]
    imputed_values = np.clip(
        model.predict(predictors.loc[missing_order, list(PREDICTOR_COLUMNS)]),
        0.0,
        100.0,
    )

    observed["prediction_se"] = pd.to_numeric(observed["prediction_se"], errors="raise")
    observed["prediction_sd"] = observed["prediction_se"] * math.sqrt(BOOTSTRAP_DRAWS)
    observed["prediction_source"] = [
        "inductive"
        if domain_map[str(name)] == "pc" or str(name) == "ipadPro2022-"
        else "oof"
        for name in observed["name"]
    ]
    observed["treble_value_origin"] = "observed_submodel"
    observed["imputation_method"] = ""
    observed["uncertainty_source"] = "bootstrap_prediction_sd"

    dev_observed_sd = observed.loc[
        observed["name"].isin(imputer_training_names), "prediction_sd"
    ].to_numpy(dtype=float)
    median_observed_sd = float(np.median(dev_observed_sd))
    imputation_rmse = float(selected_row["rmse"])
    imputed_sd = float(np.sqrt(median_observed_sd**2 + imputation_rmse**2))
    imputed_se = imputed_sd / math.sqrt(BOOTSTRAP_DRAWS)
    imputed = pd.DataFrame(
        {
            "subdir": "treble",
            "name": missing_order,
            "status": "ok",
            "predicted_percentile": imputed_values,
            "prediction_se": imputed_se,
            "prediction_sd": imputed_sd,
            "prediction_source": "inductive",
            "treble_value_origin": "dev_only_ridge_imputed",
            "imputation_method": SELECTED_METHOD,
            "uncertainty_source": (
                "dev_loo_imputation_rmse_plus_median_bootstrap_sd"
            ),
            "warnings": (
                "post-hoc sensitivity only; treble percentile reconstructed without overall"
            ),
        }
    )
    treble = pd.concat([observed, imputed], ignore_index=True, sort=False)
    if len(treble) != len(whitelist) or set(treble["name"]) != set(whitelist):
        raise ValueError("Treble sensitivity rows must cover all 29 whitelist devices")

    combined = pd.concat([base, treble], ignore_index=True, sort=False)
    combined = combined[
        combined["name"].isin(whitelist)
        & combined["subdir"].isin((*BASE_SUBDIRS, "treble"))
    ].copy()
    if len(combined) != len(whitelist) * 5:
        raise ValueError("Sensitivity prediction table must contain 29 x 5 rows")
    if combined[["name", "subdir"]].duplicated().any():
        raise ValueError("Sensitivity prediction table has duplicate name + subdir rows")
    name_order = {name: index for index, name in enumerate(whitelist)}
    subdir_order = {
        name: index for index, name in enumerate((*BASE_SUBDIRS, "treble"))
    }
    combined["__name_order"] = combined["name"].map(name_order)
    combined["__subdir_order"] = combined["subdir"].map(subdir_order)
    combined = combined.sort_values(["__name_order", "__subdir_order"]).drop(
        columns=["__name_order", "__subdir_order"]
    )

    output = Path(output_dir)
    paths = {
        "predictions": output / "submodel_predictions_with_treble.csv",
        "prediction_pc_submodels": output / "prediction_pc_submodels_with_treble.csv",
        "treble_values": output / "treble_values_and_provenance.csv",
        "candidate_metrics": output / "treble_imputation_candidate_cv.csv",
        "audit": output / "treble_imputation_audit.json",
    }
    write_csv(combined, paths["predictions"])
    prediction_subset = combined[combined["name"].isin(external_names)].copy()
    if len(prediction_subset) != len(external_names) * 5:
        raise ValueError("Frozen-PC prediction subset must contain 7 x 5 rows")
    write_csv(prediction_subset, paths["prediction_pc_submodels"])
    write_csv(
        treble[
            [
                "name",
                "predicted_percentile",
                "prediction_se",
                "prediction_sd",
                "prediction_source",
                "treble_value_origin",
                "imputation_method",
                "uncertainty_source",
            ]
        ].sort_values("name"),
        paths["treble_values"],
    )
    write_csv(candidate_metrics, paths["candidate_metrics"])
    save_json(
        {
            "schema_version": 1,
            "status": "post_hoc_sensitivity_only",
            "official_frozen_results_overwritten": False,
            "selected_method": SELECTED_METHOD,
            "selection_rule": (
                "prefer the smooth parametric Ridge bridge when its development-only "
                "LOO MAE is within 0.5 percentile points of the best fixed candidate"
            ),
            "predictor_columns": list(PREDICTOR_COLUMNS),
            "overall_used_for_imputation": False,
            "external_overall_used_for_imputation": False,
            "external_observed_treble_used_for_imputation": False,
            "imputer_training_devices": imputer_training_names,
            "frozen_external_devices": external_names,
            "imputed_devices": {
                name: float(value)
                for name, value in zip(missing_order, imputed_values, strict=True)
            },
            "selected_dev_loo_metrics": {
                key: float(selected_row[key])
                for key in ("mae", "rmse", "bias", "spearman")
            },
            "uncertainty": {
                "median_development_observed_prediction_sd": median_observed_sd,
                "imputation_loo_rmse": imputation_rmse,
                "imputed_prediction_sd": imputed_sd,
                "imputed_prediction_se": imputed_se,
                "formula": "sqrt(median_observed_prediction_sd^2 + imputation_loo_rmse^2)",
            },
            "inputs_sha256": {
                "overall": _sha256(overall_path),
                "domains": _sha256(domains_path),
                "base_predictions": _sha256(base_predictions_path),
                "table_predictions": _sha256(table_predictions_path),
                "pc_predictions": _sha256(pc_predictions_path),
                "split": _sha256(split_path),
            },
        },
        paths["audit"],
    )
    return paths


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--overall", default=PROJECT_ROOT / "data/real/overall_features.csv"
    )
    parser.add_argument(
        "--domains", default=PROJECT_ROOT / "data/real/device_domains.csv"
    )
    parser.add_argument(
        "--base-predictions",
        default=PROJECT_ROOT / "data/real/submodel_predictions.csv",
    )
    parser.add_argument(
        "--table-predictions",
        default=Path.home() / "Desktop/table_predicted_score.csv",
    )
    parser.add_argument(
        "--pc-predictions", default=Path.home() / "Desktop/pc_predicted_score.csv"
    )
    parser.add_argument(
        "--split", default=PROJECT_ROOT / "data/real/frozen_pc_split.json"
    )
    parser.add_argument(
        "--output-dir",
        default=PROJECT_ROOT / "data/experiments/posthoc_treble_sensitivity",
    )
    args = parser.parse_args()
    paths = prepare(
        args.overall,
        args.domains,
        args.base_predictions,
        args.table_predictions,
        args.pc_predictions,
        args.split,
        args.output_dir,
    )
    print(
        json.dumps(
            {key: str(path.resolve()) for key, path in paths.items()},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
