# 2026-07-23 交付包说明

本项目生成两个互相隔离的归档，避免把正式模型与查看冻结标签后的敏感性实验混为一谈。

## 1. 正式私有包

文件名：

```text
overall_device_quality_official_real_20260723.zip
```

它以以下内容为唯一正式基线：

- `configs/replacement_map_real.json`；
- `configs/experiment_real.json`；
- `data/real/`；
- `models/real/`；
- `results/real/`。

正式方案替换 clarity、lowfreq、fullness、edginess，保留原始 `treble_1/treble_2`。正式 Score 为 robust nonnegative Ridge `alpha=10`；正式 Rank 为 scaled nonnegative soft pairwise model `alpha=100`。

归档包含：

- 项目说明、详细模型分析、复现说明、环境版本和函数参考；
- `main.py`、`cli/`、完整 `src/`、`configs/`、`scripts/`、`tests/`；
- 规范化真实输入与审计：`data/real/`；
- 正式模型和元数据：`models/real/`；
- 正式训练、冻结评估和部署式预测结果：`results/real/`；
- 用户本轮提供的四个原始 CSV：`source_inputs/`；
- 包内所有文件的 `SHA256SUMS.txt`。

该包含真实设备评分和模型，应按私有数据处理，不建议直接上传公开仓库。

为了保留测试和统一入口，`configs/` 中仍包含 synthetic/test 配置，源码中也保留 synthetic 生成器；但归档不包含 synthetic 生成数据、synthetic 模型或 synthetic 结果。任何正式复训都必须显式使用 `*_real.json`。

## 2. Treble 事后敏感性补充包

文件名：

```text
overall_device_quality_posthoc_treble_sensitivity_20260723.zip
```

该包包含：

- `analysis/` 中的 treble 补值和比较代码；
- `data/experiments/posthoc_treble_sensitivity/`；
- `models/experiments/posthoc_treble_sensitivity/`；
- `results/experiments/posthoc_treble_sensitivity/`；
- 独立 `SHA256SUMS.txt`。

该实验发生在正式冻结 7 台 PC 的标签已经查看之后，只能用于描述预测对 treble 处理是否敏感。它不是新的冻结外测，不能替代 `models/real`，也不能依据 20/21 的事后结果升级为正式模型。

## 3. 明确排除

两个包均排除：

- `__pycache__/`、`.pytest_cache/`、`*.pyc`；
- 旧 ZIP 和临时文件；
- `NEW_CHAT_HANDOFF_PROMPT.md` 中的本机会话交接信息；
- synthetic 生成数据、模型和结果；
- 与本次正式模型无关的其他工程。

## 4. 完整性标识

正式模型 SHA-256：

```text
b30bb4cef9118d51719d2d6d7ad1d6eb0e6c254af340f111aeb32e7223001ac4
```

正式冻结评估联合指纹：

```text
1af987fabea2366eb9a0c14033a4681fea318f18010a024c16b2aeaf7643564e
```

每个 ZIP 解压后，以其中的 `SHA256SUMS.txt` 校验单个文件。ZIP 本身的 SHA-256 在交付完成后另行报告。

