# 配置说明

- `aliases.json`：`原录音名 -> 产品 canonical name`。只合并确认是同一硬件产品的录音；不要按名字相似自动合并。
- `subjective_scores.json`：三套已乘 overall 权重的主观贡献。未知/不完整必须是 `null`。
- `experiment.json`：默认方案、K 网格、保守 K、显式排除、列映射、模型网格、容忍分差。

修改列映射示例：

```json
{
  "columns": {
    "subdir": "类型",
    "name": "设备名称",
    "x": "音频序号",
    "n_windows": "窗口数",
    "cos_mean": "cosim_mean",
    "cos_var": "cosim_var",
    "l2_mean": "l2_mean",
    "l2_var": "l2_var"
  }
}
```

改变配置后先重新 `prepare`，再 `train`。模型 metadata 会记录主观方案、K 和最终 spec。

