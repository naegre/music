"""Small synthetic train/save/predict integration test."""

from __future__ import annotations

from dataclasses import replace

import numpy as np
import pandas as pd

from subjective_audio_quality.config import ExperimentConfig
from subjective_audio_quality.merge import merge_metric_rows
from subjective_audio_quality.prediction import predict_new_devices
from subjective_audio_quality.targets import percentile_rank
from subjective_audio_quality.training import train_models


def make_synthetic(seed: int = 7) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    rows = []
    target_rows = []
    devices = [f"device_{index}" for index in range(7)]
    quality = np.linspace(-1.5, 1.5, len(devices))
    for subdir, x_count in (("clarity", 3), ("edginess", 1)):
        scores = 75.0 + 6.0 * quality + rng.normal(0, 0.3, len(devices))
        ranks = percentile_rank(scores)
        for name, score, rank in zip(devices, scores, ranks, strict=True):
            target_rows.append(
                {
                    "subdir": subdir,
                    "name": name,
                    "k": 0.5,
                    "adjusted_score_centered": score,
                    "target_percentile": rank,
                }
            )
        for name, latent in zip(devices, quality, strict=True):
            for audio_id in range(x_count):
                rows.append(
                    {
                        "subdir": subdir,
                        "x": str(audio_id),
                        "name": name,
                        "n_windows": 8,
                        "l2_mean": max(0.05, 3.0 - 0.45 * latent + rng.normal(0, 0.04)),
                        "l2_var": 0.02,
                        "cos_mean": np.clip(0.35 + 0.07 * latent + rng.normal(0, 0.01), -0.9, 0.9),
                        "cos_var": 0.0004,
                    }
                )
    merged, _ = merge_metric_rows(pd.DataFrame(rows), {})
    return merged, pd.DataFrame(target_rows)


def test_train_and_predict_end_to_end() -> None:
    data, targets = make_synthetic()
    config = replace(
        ExperimentConfig(),
        ridge_alphas=(0.1, 10.0),
        huber_alphas=(1.0,),
        huber_deltas=(1.35,),
    )
    bundle, outputs = train_models(
        data,
        targets,
        config,
        families=("positive_ridge",),
        min_devices=6,
        final_reference_scope="labelled_only",
    )
    assert set(bundle["models"]) == {"clarity", "edginess"}
    assert outputs["selected_models"]["status"].eq("trained").all()
    predictions, pairwise = predict_new_devices(data, bundle, n_bootstrap=20, random_seed=3)
    assert predictions["status"].eq("ok").all()
    assert predictions["predicted_percentile"].between(0, 100).all()
    assert predictions.loc[predictions["subdir"].eq("edginess"), "ci_source"].eq(
        "within_only_parametric"
    ).all()
    assert not pairwise.empty
