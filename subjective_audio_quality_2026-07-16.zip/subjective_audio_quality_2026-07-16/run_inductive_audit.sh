#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

python main.py train \
  --families positive_ridge \
  --reference-scope labelled_only \
  --output-dir results/train_inductive \
  --model models/model_bundle_inductive.joblib

python main.py predict \
  --data data/raw/data.txt \
  --model models/model_bundle_inductive.joblib \
  --output-dir results/predict_inductive

python main.py evaluate-predictions \
  --predictions results/predict_inductive/new_device_rankings.csv \
  --scores data/raw/new.json \
  --output-dir results/external_evaluation_inductive

