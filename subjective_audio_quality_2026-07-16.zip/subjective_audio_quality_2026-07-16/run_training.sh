#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

python -m pip install -r requirements.txt
python main.py prepare --use-recommended-k
python -m pytest -q
python main.py train --output-dir results/train --model models/model_bundle.joblib

