# 数据目录

## raw

- `data.txt`：697 行 TSV。每行已经是 `name + subdir + x` 的窗口统计，不是单窗口数据。
- `overall.json`：原始 subdir-first 客观评分；`overall` 在本项目中不训练。
- `new.json`：更新后的 iPad Pro 2022 客观评分，用于外部审计。

原始指标列：

```text
subdir, x, name, n_windows,
cosine_similarity_mean, cosine_similarity_var,
l2_distance_mean, l2_distance_var,
cosine_distance_mean, cosine_distance_var,
kl_pq_mean, kl_pq_var, kl_qp_mean, kl_qp_var, js_mean, js_var
```

KL/JS 列被保留以便复查，但默认训练器只读取 L2/cosine。

## processed

运行 `python main.py prepare --use-recommended-k` 生成：

- `x_metrics_merged.csv`：别名合并、明确排除后的产品/x 表。
- `targets.csv`：每个 subdir/name 的客观值、主观贡献、K、调整后值和百分位。
- `alias_merge_audit.csv`：每行由哪些录音名合并而来。
- `row_exclusion_audit.csv`：删了什么、多少行、为什么。
- `target_coverage_audit.csv`：缺主观、缺指标等状态。
- `objective_scores_merged.json`、`subjective_selected.json`、`targets.json`：便于脚本或人工检查的 JSON。

`x_metrics_merged.csv` 中：

- `n_windows_total` 是原始重叠窗口总数。
- `n_effective = sum(max(1, (n_windows_recording+4)/5))`。
- `n_recordings` 是合并的源录音行数。
- `source_names` 用于追踪原录音名称。

不要手工编辑 processed 文件；修改配置后重新运行 prepare，审计链才完整。
