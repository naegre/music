#!/usr/bin/env python3
"""Compare nested Ridge/Huber candidates without saving a deployable model."""

from __future__ import annotations

from train import build_parser, run_training


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    parser.description = __doc__
    args = parser.parse_args(argv)
    run_training(args, save_model=False)


if __name__ == "__main__":
    main()
