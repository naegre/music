"""Command-line entry modules."""

