#!/usr/bin/env python3
"""Compare prediction CSV ranks with updated/external objective+subjective labels."""

from __future__ import annotations

import argparse
from pathlib import Path

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.config import load_experiment, load_json
from subjective_audio_quality.evaluation import evaluate_prediction_table
from subjective_audio_quality.io import read_table, write_csv
from subjective_audio_quality.merge import merge_nullable_values, merge_score_maps
from subjective_audio_quality.targets import build_target_table


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--scores", default=str(PROJECT_ROOT / "data/raw/new.json"))
    parser.add_argument(
        "--subjective", default=str(PROJECT_ROOT / "configs/subjective_scores.json")
    )
    parser.add_argument("--aliases", default=str(PROJECT_ROOT / "configs/aliases.json"))
    parser.add_argument("--config", default=str(PROJECT_ROOT / "configs/experiment.json"))
    parser.add_argument("--variant", default="")
    parser.add_argument("--k", type=float, default=None)
    parser.add_argument("--k-map", default="")
    parser.add_argument("--output-dir", default=str(PROJECT_ROOT / "results/external_evaluation"))
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    config = load_experiment(args.config)
    aliases = load_json(args.aliases)
    objective, _ = merge_score_maps(load_json(args.scores), aliases)
    variant = args.variant or config.subjective_variant
    subjective = merge_nullable_values(load_json(args.subjective)[variant], aliases)
    if args.k_map:
        k_value = load_json(args.k_map)
    elif args.k is not None:
        k_value = float(args.k)
    else:
        k_value = config.recommended_k_by_subdir
    targets, _ = build_target_table(objective, subjective, k_value)
    metrics, audit = evaluate_prediction_table(
        read_table(args.predictions),
        targets,
        config.material_score_gap,
        config.near_tie_score_gap,
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(metrics, output / "external_metrics.csv")
    write_csv(audit, output / "external_device_rank_audit.csv")
    print(metrics.to_string(index=False))
    print("External labels are an audit set; do not use this output to retune k.")


if __name__ == "__main__":
    main()

