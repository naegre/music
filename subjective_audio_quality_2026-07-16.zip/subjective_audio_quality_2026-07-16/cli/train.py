#!/usr/bin/env python3
"""Run strict model selection, fit final subdir models, and save a bundle."""

from __future__ import annotations

import argparse
from pathlib import Path

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.config import load_experiment
from subjective_audio_quality.io import read_table, write_csv
from subjective_audio_quality.persistence import save_bundle
from subjective_audio_quality.training import train_models


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data", default=str(PROJECT_ROOT / "data/processed/x_metrics_merged.csv")
    )
    parser.add_argument("--targets", default=str(PROJECT_ROOT / "data/processed/targets.csv"))
    parser.add_argument("--config", default=str(PROJECT_ROOT / "configs/experiment.json"))
    parser.add_argument(
        "--families", default="positive_ridge,positive_huber",
        help="Comma-separated: positive_ridge,positive_huber",
    )
    parser.add_argument("--min-devices", type=int, default=6)
    parser.add_argument(
        "--reference-scope",
        choices=("all_reference", "labelled_only"),
        default="all_reference",
        help="Use labelled_only for a strict inductive external audit.",
    )
    parser.add_argument("--output-dir", default=str(PROJECT_ROOT / "results/train"))
    parser.add_argument("--model", default=str(PROJECT_ROOT / "models/model_bundle.joblib"))
    return parser


def run_training(args: argparse.Namespace, save_model: bool = True) -> tuple[dict, dict]:
    config = load_experiment(args.config)
    data = read_table(args.data)
    targets = read_table(args.targets)
    families = tuple(value.strip() for value in args.families.split(",") if value.strip())
    bundle, outputs = train_models(
        data,
        targets,
        config,
        families,
        args.min_devices,
        args.reference_scope,
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for name, frame in outputs.items():
        write_csv(frame, output / f"{name}.csv")
    if save_model:
        model_path = Path(args.model)
        save_bundle(bundle, model_path, model_path.with_suffix(".metadata.json"))
    print(outputs["selected_models"].to_string(index=False))
    print(f"Results: {output.resolve()}")
    if save_model:
        print(f"Model: {Path(args.model).resolve()}")
    return bundle, outputs


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    run_training(args, save_model=True)


if __name__ == "__main__":
    main()
