#!/usr/bin/env python3
"""Merge aliases, apply explicit exclusions, and build subjective targets."""

from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.config import load_experiment, load_json, save_json
from subjective_audio_quality.io import (
    canonicalize_columns,
    read_table,
    summarize_input,
    write_csv,
)
from subjective_audio_quality.merge import (
    apply_row_exclusions,
    merge_metric_rows,
    merge_nullable_values,
    merge_score_maps,
)
from subjective_audio_quality.targets import build_target_table, target_table_to_nested_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default=str(PROJECT_ROOT / "data/raw/data.txt"))
    parser.add_argument("--scores", default=str(PROJECT_ROOT / "data/raw/overall.json"))
    parser.add_argument(
        "--subjective", default=str(PROJECT_ROOT / "configs/subjective_scores.json")
    )
    parser.add_argument("--aliases", default=str(PROJECT_ROOT / "configs/aliases.json"))
    parser.add_argument("--config", default=str(PROJECT_ROOT / "configs/experiment.json"))
    parser.add_argument("--variant", default="")
    parser.add_argument("--k", type=float, default=None)
    parser.add_argument("--k-map", default="")
    parser.add_argument("--use-recommended-k", action="store_true")
    parser.add_argument("--output-dir", default=str(PROJECT_ROOT / "data/processed"))
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    config = load_experiment(args.config)
    if args.variant:
        config = replace(config, subjective_variant=args.variant)
    aliases = load_json(args.aliases)
    raw = canonicalize_columns(read_table(args.data), config.columns)
    merged, alias_audit = merge_metric_rows(raw, aliases)
    revised, exclusion_audit = apply_row_exclusions(merged, config.drop_rows)
    objective, score_audit = merge_score_maps(load_json(args.scores), aliases)
    subjective_variants = load_json(args.subjective)
    if config.subjective_variant not in subjective_variants:
        raise KeyError(f"Unknown subjective variant: {config.subjective_variant}")
    subjective = merge_nullable_values(subjective_variants[config.subjective_variant], aliases)
    if args.k_map:
        k_value = {str(key): float(value) for key, value in load_json(args.k_map).items()}
    elif args.use_recommended_k:
        k_value = config.recommended_k_by_subdir
    else:
        k_value = config.default_k if args.k is None else float(args.k)
    targets, target_audit = build_target_table(objective, subjective, k_value)
    data_pairs = set(zip(revised["subdir"].astype(str), revised["name"].astype(str)))
    target_audit["has_metric_data"] = [
        (str(row.subdir), str(row.name)) in data_pairs for row in target_audit.itertuples()
    ]

    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(revised, output / "x_metrics_merged.csv")
    write_csv(alias_audit, output / "alias_merge_audit.csv")
    write_csv(exclusion_audit, output / "row_exclusion_audit.csv")
    write_csv(score_audit, output / "score_merge_audit.csv")
    write_csv(targets, output / "targets.csv")
    write_csv(target_audit, output / "target_coverage_audit.csv")
    save_json(objective, output / "objective_scores_merged.json")
    save_json(subjective, output / "subjective_selected.json")
    save_json(target_table_to_nested_json(targets), output / "targets.json")
    save_json(
        {
            "input": summarize_input(raw),
            "after_alias_merge": summarize_input(
                revised.rename(columns={"n_windows_total": "n_windows"})
            ),
            "subjective_variant": config.subjective_variant,
            "k": k_value,
            "excluded_rows": int(exclusion_audit["rows_removed"].sum()),
            "supervised_target_rows": int(len(targets)),
        },
        output / "preparation_summary.json",
    )
    print(f"Prepared {len(raw)} raw rows -> {len(revised)} product/x rows")
    print(f"Targets: {len(targets)} rows across {targets['subdir'].nunique()} subdirs")
    print(f"Output: {output.resolve()}")


if __name__ == "__main__":
    main()

