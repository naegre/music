"""Shared CLI path setup and output helpers."""

from __future__ import annotations

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = PROJECT_ROOT / "src"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))


def resolve_project_path(value: str) -> Path:
    """Resolve a CLI path relative to the current shell, not this module."""

    return Path(value).expanduser().resolve()

