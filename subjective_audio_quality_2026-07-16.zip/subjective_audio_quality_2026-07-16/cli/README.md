# CLI 入口

所有命令既可单独运行，例如 `python cli/prepare_data.py`，也可通过根目录 `main.py`：

| main 命令 | 文件 | 输入 | 主要输出 |
|---|---|---|---|
| `prepare` | `prepare_data.py` | raw x 表、客观/主观/别名/配置 | processed 数据、targets、审计 |
| `evaluate` | `evaluate_models.py` | processed 数据、targets | 嵌套模型比较，不存 bundle |
| `train` | `train.py` | 同上 | 比较表、最终 joblib |
| `predict` | `predict.py` | 新 raw x 表、joblib | 排名、CI、逐参考胜率 |
| `evaluate-predictions` | `evaluate_predictions.py` | prediction CSV、冻结标签 | 外部指标、逐设备错误 |
| `tune-k` | `tune_k.py` | processed 数据、客观/主观标签 | K 网格 OOF 与选择 |
| `audit-filter` | `audit_window_filter.py` | raw 单窗口表 | 过滤审计，不删除 |

每个脚本执行 `-h` 可查看参数。路径可为绝对路径；默认路径均指向本项目内数据。

