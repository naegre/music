#!/usr/bin/env python3
"""Choose subjective contribution k using internal nested LOODO only."""

from __future__ import annotations

import argparse
from pathlib import Path

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.config import load_experiment, load_json, save_json
from subjective_audio_quality.io import read_table, write_csv
from subjective_audio_quality.merge import merge_nullable_values
from subjective_audio_quality.tuning import tune_k_grid


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data", default=str(PROJECT_ROOT / "data/processed/x_metrics_merged.csv")
    )
    parser.add_argument(
        "--scores", default=str(PROJECT_ROOT / "data/processed/objective_scores_merged.json")
    )
    parser.add_argument(
        "--subjective", default=str(PROJECT_ROOT / "configs/subjective_scores.json")
    )
    parser.add_argument("--aliases", default=str(PROJECT_ROOT / "configs/aliases.json"))
    parser.add_argument("--config", default=str(PROJECT_ROOT / "configs/experiment.json"))
    parser.add_argument("--variant", default="")
    parser.add_argument("--k-values", default="")
    parser.add_argument("--near-best-tolerance", type=float, default=0.02)
    parser.add_argument("--output-dir", default=str(PROJECT_ROOT / "results/k_tuning"))
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    config = load_experiment(args.config)
    variant = args.variant or config.subjective_variant
    aliases = load_json(args.aliases)
    subjective = merge_nullable_values(load_json(args.subjective)[variant], aliases)
    k_values = (
        [float(value) for value in args.k_values.split(",")]
        if args.k_values
        else list(config.k_grid)
    )
    metrics, predictions, selected, global_summary = tune_k_grid(
        read_table(args.data),
        load_json(args.scores),
        subjective,
        config,
        k_values,
        args.near_best_tolerance,
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(metrics, output / "k_internal_metrics.csv")
    write_csv(predictions, output / "k_internal_oof_predictions.csv")
    write_csv(selected, output / "k_selected_by_subdir.csv")
    write_csv(global_summary, output / "k_global_summary.csv")
    selected_map = dict(zip(selected["subdir"], selected["k"], strict=True))
    save_json(selected_map, output / "k_selected_by_subdir.json")
    print("Model-aligned internal selection (not an identified ground-truth k):")
    print(selected[["subdir", "k", "spearman", "pairwise_accuracy_gap_ge_2"]].to_string(index=False))
    print("\nGlobal k summary:")
    print(global_summary.to_string(index=False))
    print("Use frozen external subjective evidence before replacing the domain k config.")


if __name__ == "__main__":
    main()
