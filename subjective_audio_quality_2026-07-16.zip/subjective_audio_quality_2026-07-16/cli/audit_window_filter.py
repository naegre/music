#!/usr/bin/env python3
"""Audit the old all-device window filter on raw window-level data."""

from __future__ import annotations

import argparse

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.filtering import audit_window_thresholds
from subjective_audio_quality.io import read_table, write_csv


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--windows", required=True)
    parser.add_argument("--cos-threshold", type=float, default=0.21)
    parser.add_argument("--l2-threshold", type=float, default=6.0)
    parser.add_argument("--consensus", type=float, default=0.8)
    parser.add_argument("--output", required=True)
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    audit = audit_window_thresholds(
        read_table(args.windows), args.cos_threshold, args.l2_threshold, args.consensus
    )
    write_csv(audit, args.output)
    print(audit["suggested_status"].value_counts(dropna=False).to_string())
    print("This command creates an audit only; it never deletes source observations.")


if __name__ == "__main__":
    main()

