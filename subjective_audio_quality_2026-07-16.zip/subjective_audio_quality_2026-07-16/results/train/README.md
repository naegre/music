# 正式训练结果

本目录由 2026-07-16 的 Ridge + Huber 完整嵌套 LOODO 生成。模型采用当前领域保守 K 配置；模型综合分在最优值 0.01 内时优先更简单的 Ridge/mean。

## 最终部署 spec

| subdir | 模型 | 特征 | alpha |
|---|---|---|---:|
| clarity | non-negative Ridge | mean | 10 |
| clarity_voice | non-negative Ridge | mean | 1 |
| edginess | non-negative Ridge | mean | 1 |
| fullness | non-negative Ridge | mean | 100 |
| lowfreq | non-negative Ridge | mean + stability | 10 |
| treble | non-negative Ridge | mean | 1 |

Huber 在部分 exact 候选上只领先约 `0.000001~0.0057` selection score，未超过 0.01 的复杂度门槛，故没有进入最终 bundle。

## 主要无偏近似结果

以下来自 `selected_models.csv` 的 `nested_auto_outer_LOODO`，即每个外层 held-out 设备从未参与本折 normalizer、imputer、scaler 或模型/参数选择：

| subdir | Spearman | >=2 分 pair acc | percentile MAE | 判断 |
|---|---:|---:|---:|---|
| clarity | 0.588 | 0.750 | 19.99 | 探索性，不足以稳定部署 |
| clarity_voice | 0.643 | 0.810 | 18.39 | 排名中等，设备对勉强可用 |
| edginess | 0.699 | 0.787 | 17.31 | 接近 strong，仍需外部设备 |
| fullness | 0.769 | 0.830 | 20.62 | 排名 strong，但大误差仍明显 |
| lowfreq | 0.853 | 0.926 | 11.30 | 当前最可靠，接近优秀标准 |
| treble | 0.685 | 0.741 | 21.10 | 中等，material pair 不足 |

结论：当前代码可给粗略排名，但只有 lowfreq 接近稳定可用；不能把六类都描述成“高精度”。尤其 clarity 与 treble 需要更多标签设备、重复录音和能覆盖对应主观维度的新特征。

## 文件

- `model_comparison.csv`：nested group 与 final exact candidates。
- `oof_predictions.csv`：逐设备 OOF。
- `selected_models.csv`：最终 spec 和 selection-aware 指标。
- `coefficients.csv`：已检查，无负系数。
- `aggregated_features.csv`：name/subdir 特征与可靠性。
- `reference_predictions.csv`：最终模型对固定参考设备的统一尺度预测。
