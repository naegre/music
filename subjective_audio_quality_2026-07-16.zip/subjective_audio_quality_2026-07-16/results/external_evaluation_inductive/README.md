# 严格 inductive iPad 审计

此结果来自 `models/model_bundle_inductive.joblib`。训练时 `ipadPro2022-` 既没有人工标签，也没有参与最终 median/MAD 参考统计；因此其标签审计比默认 all-reference bundle 更严格。

| subdir | 真实名次 | 预测名次 | 名次误差 | >=2 分 crossings |
|---|---:|---:|---:|---:|
| clarity_voice | 3 | 4 | 1 | 1 |
| edginess | 7 | 3 | 4 | 3 |
| fullness | 4 | 1 | 3 | 3 |
| lowfreq | 5 | 1 | 4 | 4 |
| treble | 3 | 1 | 2 | 0 |

`clarity` 没有 iPad Pro 2022 指标，无法预测。voice 与 treble 的相对顺序较可接受；edge/fullness/lowfreq 存在一致高估，不应通过查看此结果后继续调 K，否则会污染外部测试。

同目录总表包含 13 台有新标签产品，其中 12 台参与过旧监督训练，所以总 Spearman 不是纯外部指标。真正未见标签设备的结论应以表中 iPad 行为准。

