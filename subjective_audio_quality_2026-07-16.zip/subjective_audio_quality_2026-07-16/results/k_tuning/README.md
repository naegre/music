# K 搜索结果

严格嵌套搜索使用 8 个 K、6 个 subdir，仅用非负 Ridge mean/stability。数值输出完整保留，不用外部 iPad 标签调参。

## 模型对齐选择

```text
clarity=2.0
clarity_voice=0.0
edginess=0.0
fullness=0.0
lowfreq=1.0
treble=2.0
```

这表示“现有 L2/cosine 最容易复现的混合目标”，不是已识别的人类真实权重。全局 selection score 最好的是 K=2，但平均 Spearman 与两分以上设备对准确率在 K=1 略高；单个综合分无法消除冲突。

正式训练仍使用 `configs/experiment.json` 的领域保守 K。只有独立新增设备、完整主观标签和预先冻结的选择规则支持新 K 时，才应修改配置。
