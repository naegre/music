# 结果目录

- `train/`：正式训练结果。
- `k_tuning/`：K 网格和保守选择。
- `predict/`：新设备预测与 bootstrap。
- `external_evaluation/`：冻结标签审计。

`smoke_*` 若存在，只表示开发时的流程冒烟测试，不应当作正式实验报告。正式比较优先读取 `train/model_comparison.csv` 的 `nested_auto` 行和 `train/oof_predictions.csv`，不要用训练内拟合值汇报泛化能力。
