"""Construct subdir targets from objective labels and subjective contributions."""

from __future__ import annotations

from collections.abc import Mapping

import numpy as np
import pandas as pd
from scipy.stats import rankdata


IGNORED_SCORE_SECTIONS = {"overall", "loudness"}


def percentile_rank(values: np.ndarray | list[float]) -> np.ndarray:
    """Map scores to mid-rank percentiles in ``(0, 100)``; ties share a rank."""

    array = np.asarray(values, dtype=float)
    if array.size == 0:
        return array
    return 100.0 * (rankdata(array, method="average") - 0.5) / array.size


def resolve_k(k: float | Mapping[str, float], subdir: str) -> float:
    """Return a global k or the subdir-specific value from a mapping."""

    if isinstance(k, Mapping):
        if subdir not in k:
            raise KeyError(f"No k configured for subdir {subdir!r}")
        return float(k[subdir])
    return float(k)


def build_target_table(
    objective_scores: Mapping[str, Mapping[str, float]],
    subjective: Mapping[str, float | None],
    k: float | Mapping[str, float],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build adjusted targets and a complete inclusion/exclusion audit.

    The fitted ranking target is based on
    ``objective_score + k * subjective_weighted_contribution``. A centered
    version is included only to display values on a more familiar scale;
    centering does not change within-subdir ranks.
    """

    rows: list[dict[str, object]] = []
    audit_rows: list[dict[str, object]] = []
    for subdir, score_map in objective_scores.items():
        if subdir in IGNORED_SCORE_SECTIONS:
            continue
        subdir_k = resolve_k(k, subdir)
        valid_subjective = {
            name: float(value)
            for name, value in subjective.items()
            if value is not None and name in score_map
        }
        center = float(np.median(list(valid_subjective.values()))) if valid_subjective else np.nan
        subdir_rows: list[dict[str, object]] = []
        for name, objective in score_map.items():
            subjective_value = subjective.get(name)
            status = "included" if subjective_value is not None else "missing_subjective"
            audit_rows.append(
                {
                    "subdir": str(subdir),
                    "name": str(name),
                    "has_objective": True,
                    "has_subjective": subjective_value is not None,
                    "status": status,
                }
            )
            if subjective_value is None:
                continue
            raw = float(objective) + subdir_k * float(subjective_value)
            centered = float(objective) + subdir_k * (float(subjective_value) - center)
            subdir_rows.append(
                {
                    "subdir": str(subdir),
                    "name": str(name),
                    "objective_score": float(objective),
                    "subjective_contribution": float(subjective_value),
                    "subjective_center": center,
                    "k": subdir_k,
                    "adjusted_score_raw": raw,
                    "adjusted_score_centered": centered,
                }
            )
        if subdir_rows:
            ranks = percentile_rank([row["adjusted_score_raw"] for row in subdir_rows])
            for row, percentile in zip(subdir_rows, ranks, strict=True):
                row["target_percentile"] = float(percentile)
                rows.append(row)
    return pd.DataFrame(rows), pd.DataFrame(audit_rows)


def target_table_to_nested_json(
    targets: pd.DataFrame, value_column: str = "adjusted_score_centered"
) -> dict[str, dict[str, float]]:
    """Convert a target table to the subdir-first JSON shape used by CLIs."""

    output: dict[str, dict[str, float]] = {}
    for subdir, group in targets.groupby("subdir", sort=True):
        output[str(subdir)] = {
            str(row["name"]): float(row[value_column]) for _, row in group.iterrows()
        }
    return output
