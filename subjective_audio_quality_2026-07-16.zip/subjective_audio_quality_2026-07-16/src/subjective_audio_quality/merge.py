"""Merge aliases that are repeated recordings of the same physical product."""

from __future__ import annotations

from collections.abc import Mapping

import numpy as np
import pandas as pd


def effective_window_count(n_windows: float) -> float:
    """Conservative effective count for 5 s windows with a 1 s hop."""

    return max(1.0, (float(n_windows) + 4.0) / 5.0)


def _pooled_mean_variance(
    group: pd.DataFrame, mean_column: str, variance_column: str
) -> tuple[float, float]:
    counts = group["n_windows"].to_numpy(dtype=float)
    means = group[mean_column].to_numpy(dtype=float)
    variances = np.maximum(group[variance_column].to_numpy(dtype=float), 0.0)
    total = float(counts.sum())
    pooled_mean = float(np.average(means, weights=counts))
    if total <= 1.0:
        return pooled_mean, float(np.average(variances, weights=counts))
    numerator = np.sum(
        np.maximum(counts - 1.0, 0.0) * variances
        + counts * np.square(means - pooled_mean)
    )
    return pooled_mean, float(numerator / (total - 1.0))


def metric_pairs(frame: pd.DataFrame) -> list[tuple[str, str]]:
    """Discover ``*_mean``/``*_var`` pairs, including optional KL/JS fields."""

    pairs: list[tuple[str, str]] = []
    for mean_column in frame.columns:
        if not mean_column.endswith("_mean"):
            continue
        variance_column = f"{mean_column[:-5]}_var"
        if variance_column in frame.columns:
            pairs.append((mean_column, variance_column))
    return pairs


def merge_metric_rows(
    frame: pd.DataFrame, aliases: Mapping[str, str]
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Pool repeated recordings at canonical ``name + subdir + x`` level.

    ``n_windows_total`` is the raw number of overlapping windows. In contrast,
    ``n_effective`` is computed per source recording and then summed, so merging
    aliases does not pretend that all overlapping windows are independent.
    """

    source = frame.copy()
    source["source_name"] = source["name"].astype(str)
    source["name"] = source["source_name"].map(aliases).fillna(source["source_name"])
    source["source_n_effective"] = source["n_windows"].map(effective_window_count)
    pairs = metric_pairs(source)
    rows: list[dict[str, object]] = []
    audit_rows: list[dict[str, object]] = []

    for (name, subdir, audio_id), group in source.groupby(
        ["name", "subdir", "x"], sort=False, dropna=False
    ):
        source_names = sorted(group["source_name"].astype(str).unique())
        row: dict[str, object] = {
            "subdir": str(subdir),
            "x": str(audio_id),
            "name": str(name),
            "n_windows_total": int(group["n_windows"].sum()),
            "n_effective": float(group["source_n_effective"].sum()),
            "n_recordings": int(len(group)),
            "source_names": "|".join(source_names),
        }
        for mean_column, variance_column in pairs:
            mean, variance = _pooled_mean_variance(group, mean_column, variance_column)
            row[mean_column] = mean
            row[variance_column] = variance
        rows.append(row)
        audit_rows.append(
            {
                "subdir": str(subdir),
                "x": str(audio_id),
                "name": str(name),
                "source_names": "|".join(source_names),
                "source_rows": int(len(group)),
                "n_windows_total": int(group["n_windows"].sum()),
                "n_effective": float(group["source_n_effective"].sum()),
            }
        )

    merged = pd.DataFrame(rows).sort_values(["subdir", "x", "name"]).reset_index(drop=True)
    audit = pd.DataFrame(audit_rows).sort_values(["subdir", "x", "name"]).reset_index(drop=True)
    return merged, audit


def merge_score_maps(
    scores: Mapping[str, Mapping[str, float]], aliases: Mapping[str, str]
) -> tuple[dict[str, dict[str, float]], pd.DataFrame]:
    """Average duplicate alias labels while retaining an explicit audit table."""

    merged: dict[str, dict[str, float]] = {}
    audit_rows: list[dict[str, object]] = []
    for subdir, score_map in scores.items():
        grouped: dict[str, list[tuple[str, float]]] = {}
        for source_name, score in score_map.items():
            canonical = aliases.get(str(source_name), str(source_name))
            grouped.setdefault(canonical, []).append((str(source_name), float(score)))
        merged[str(subdir)] = {}
        for canonical, entries in sorted(grouped.items()):
            merged_score = float(np.mean([score for _, score in entries]))
            merged[str(subdir)][canonical] = merged_score
            audit_rows.append(
                {
                    "subdir": str(subdir),
                    "name": canonical,
                    "source_names": "|".join(sorted(name for name, _ in entries)),
                    "source_label_count": len(entries),
                    "merged_score": merged_score,
                }
            )
    return merged, pd.DataFrame(audit_rows)


def merge_nullable_values(
    values: Mapping[str, float | None], aliases: Mapping[str, str]
) -> dict[str, float | None]:
    """Merge optional subjective contributions; ``None`` remains missing."""

    grouped: dict[str, list[float]] = {}
    known_names: set[str] = set()
    for source_name, value in values.items():
        canonical = aliases.get(str(source_name), str(source_name))
        known_names.add(canonical)
        if value is not None:
            grouped.setdefault(canonical, []).append(float(value))
    return {
        name: (float(np.mean(grouped[name])) if name in grouped else None)
        for name in sorted(known_names)
    }


def apply_row_exclusions(
    frame: pd.DataFrame, rules: tuple[dict[str, str], ...] | list[dict[str, str]]
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Apply explicit, auditable ``subdir + x`` exclusions from configuration."""

    keep = pd.Series(True, index=frame.index)
    audit_rows: list[dict[str, object]] = []
    for rule in rules:
        mask = (
            frame["subdir"].astype(str).eq(str(rule["subdir"]))
            & frame["x"].astype(str).eq(str(rule["x"]))
        )
        audit_rows.append(
            {
                "subdir": str(rule["subdir"]),
                "x": str(rule["x"]),
                "rows_removed": int((keep & mask).sum()),
                "reason": str(rule.get("reason", "configured exclusion")),
            }
        )
        keep &= ~mask
    return frame.loc[keep].reset_index(drop=True), pd.DataFrame(audit_rows)

