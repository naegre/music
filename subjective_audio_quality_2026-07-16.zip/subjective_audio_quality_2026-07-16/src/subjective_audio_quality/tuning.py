"""Internal-only k grid search using nested device-level validation."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import pandas as pd

from .config import ExperimentConfig
from .models import candidate_grid
from .targets import build_target_table
from .validation import ValidationRunner, eligible_devices


def tune_k_grid(
    merged_x_data: pd.DataFrame,
    objective_scores: Mapping[str, Mapping[str, float]],
    subjective: Mapping[str, float | None],
    config: ExperimentConfig,
    k_values: Sequence[float] | None = None,
    conservative_tolerance: float = 0.02,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Tune k without consulting the external ``new.json`` holdout.

    Ridge mean/stability candidates are used here to keep the k question
    separate from the Huber-vs-Ridge model-family comparison.
    """

    k_values = list(k_values or config.k_grid)
    candidates = candidate_grid(
        config.ridge_alphas,
        config.huber_alphas,
        config.huber_deltas,
        families=("positive_ridge",),
    )
    runner = ValidationRunner(
        merged_x_data,
        config.material_score_gap,
        config.near_tie_score_gap,
        config.model_simplicity_tolerance,
    )
    metric_frames: list[pd.DataFrame] = []
    prediction_frames: list[pd.DataFrame] = []
    for k in k_values:
        targets, _ = build_target_table(objective_scores, subjective, float(k))
        for subdir, target_group in targets.groupby("subdir", sort=True):
            score_map = dict(
                zip(
                    target_group["name"].astype(str),
                    target_group["adjusted_score_centered"],
                    strict=True,
                )
            )
            devices = eligible_devices(merged_x_data, str(subdir), score_map)
            if len(devices) < 6:
                continue
            predictions, metrics = runner.nested_groups_oof(
                str(subdir), devices, score_map, {"ridge_auto": candidates}
            )
            predictions["k"] = float(k)
            metrics["k"] = float(k)
            prediction_frames.append(predictions)
            metric_frames.append(metrics)
    metrics = pd.concat(metric_frames, ignore_index=True)
    predictions = pd.concat(prediction_frames, ignore_index=True)

    selected_rows: list[pd.Series] = []
    for _, group in metrics.groupby("subdir", sort=True):
        best_score = float(group["selection_score"].max())
        near_best = group[group["selection_score"] >= best_score - conservative_tolerance]
        selected_rows.append(near_best.sort_values(["k", "percentile_mae"]).iloc[0])
    selected = pd.DataFrame(selected_rows).reset_index(drop=True)
    global_summary = (
        metrics.groupby("k", as_index=False)
        .agg(
            mean_selection_score=("selection_score", "mean"),
            mean_spearman=("spearman", "mean"),
            mean_material_pair_accuracy=("pairwise_accuracy_gap_ge_2", "mean"),
            mean_percentile_mae=("percentile_mae", "mean"),
        )
        .sort_values(["mean_selection_score", "k"], ascending=[False, True])
    )
    return metrics, predictions, selected, global_summary
