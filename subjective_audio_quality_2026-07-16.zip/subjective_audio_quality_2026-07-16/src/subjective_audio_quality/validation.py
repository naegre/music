"""Strict nested Leave-One-Device-Out validation with fold-local preprocessing."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence

import numpy as np
import pandas as pd

from .features import aggregate_name_subdir, feature_columns
from .metrics import ranking_metrics, selection_score
from .models import ModelSpec, make_model
from .normalization import PairedRobustNormalizer
from .targets import percentile_rank


class FoldFeatureCache:
    """Cache fold-local robust features; cache keys are training device sets."""

    def __init__(self, merged_x_data: pd.DataFrame):
        self.data = merged_x_data.copy()
        self._cache: dict[tuple[str, tuple[str, ...]], pd.DataFrame] = {}

    def get(self, subdir: str, fit_devices: Sequence[str]) -> pd.DataFrame:
        key = (str(subdir), tuple(sorted(map(str, fit_devices))))
        if key in self._cache:
            return self._cache[key]
        task = self.data[self.data["subdir"].astype(str).eq(str(subdir))]
        fit_rows = task[task["name"].astype(str).isin(key[1])]
        if fit_rows.empty:
            raise ValueError(f"No fit rows for subdir={subdir!r}, devices={key[1]}")
        normalizer = PairedRobustNormalizer().fit(fit_rows)
        transformed = normalizer.transform(task)
        aggregated = aggregate_name_subdir(transformed, normalizer.expected_x_).set_index("name")
        self._cache[key] = aggregated
        return aggregated


def eligible_devices(
    merged_x_data: pd.DataFrame,
    subdir: str,
    score_map: Mapping[str, float],
) -> list[str]:
    """Return devices that have both x-level metrics and a supervised target."""

    data_devices = set(
        merged_x_data.loc[
            merged_x_data["subdir"].astype(str).eq(str(subdir)), "name"
        ].astype(str)
    )
    return sorted(data_devices & set(map(str, score_map)))


def fit_predict_one(
    features: pd.DataFrame,
    train_devices: Sequence[str],
    target_device: str,
    score_map: Mapping[str, float],
    spec: ModelSpec,
) -> tuple[float, object]:
    """Fit one fold model and predict one held-out device percentile."""

    columns = feature_columns(spec.feature_mode)
    train_target = percentile_rank([score_map[name] for name in train_devices])
    model = make_model(spec)
    model.fit(features.loc[list(train_devices), columns], train_target)
    prediction = float(model.predict(features.loc[[target_device], columns])[0])
    return float(np.clip(prediction, 0.0, 100.0)), model


class ValidationRunner:
    """Run exact-candidate and nested-family LOODO evaluations."""

    def __init__(
        self,
        merged_x_data: pd.DataFrame,
        material_gap: float = 2.0,
        near_tie_gap: float = 1.0,
        simplicity_tolerance: float = 0.01,
    ):
        self.features = FoldFeatureCache(merged_x_data)
        self.material_gap = float(material_gap)
        self.near_tie_gap = float(near_tie_gap)
        self.simplicity_tolerance = float(simplicity_tolerance)
        self._oof_cache: dict[tuple[object, ...], pd.DataFrame] = {}

    @staticmethod
    def _target_key(devices: Sequence[str], score_map: Mapping[str, float]) -> tuple[float, ...]:
        return tuple(round(float(score_map[name]), 12) for name in devices)

    def exact_spec_oof(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        spec: ModelSpec,
    ) -> pd.DataFrame:
        """Evaluate one fixed spec with fold-local preprocessing."""

        devices = tuple(sorted(map(str, devices)))
        cache_key = (
            str(subdir),
            devices,
            self._target_key(devices, score_map),
            spec,
        )
        if cache_key in self._oof_cache:
            return self._oof_cache[cache_key].copy()
        global_percentiles = dict(
            zip(devices, percentile_rank([score_map[name] for name in devices]), strict=True)
        )
        rows: list[dict[str, object]] = []
        for heldout in devices:
            train_devices = [name for name in devices if name != heldout]
            fold_features = self.features.get(subdir, train_devices)
            prediction, _ = fit_predict_one(
                fold_features, train_devices, heldout, score_map, spec
            )
            rows.append(
                {
                    "subdir": str(subdir),
                    "name": heldout,
                    "adjusted_score": float(score_map[heldout]),
                    "target_percentile": float(global_percentiles[heldout]),
                    "oof_prediction": prediction,
                    "spec": spec.label,
                    "spec_json": json.dumps(spec.to_dict(), sort_keys=True),
                }
            )
        result = pd.DataFrame(rows)
        self._oof_cache[cache_key] = result.copy()
        return result

    def evaluate_exact_specs(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        candidates: Sequence[ModelSpec],
    ) -> pd.DataFrame:
        """Score every exact candidate using LOODO on the provided devices."""

        rows: list[dict[str, object]] = []
        for spec in candidates:
            predictions = self.exact_spec_oof(subdir, devices, score_map, spec)
            metrics = ranking_metrics(
                predictions["adjusted_score"],
                predictions["oof_prediction"],
                self.material_gap,
                self.near_tie_gap,
            )
            rows.append(
                {
                    "subdir": str(subdir),
                    "spec": spec.label,
                    "spec_json": json.dumps(spec.to_dict(), sort_keys=True),
                    **metrics,
                    "selection_score": selection_score(metrics),
                }
            )
        return pd.DataFrame(rows)

    def select_spec(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        candidates: Sequence[ModelSpec],
    ) -> tuple[ModelSpec, pd.DataFrame]:
        """Choose a spec inside a training fold, preferring simpler ties."""

        comparison = self.evaluate_exact_specs(subdir, devices, score_map, candidates)
        spec_lookup = {spec.label: spec for spec in candidates}
        comparison["family_preference"] = comparison["spec"].map(
            lambda label: 1 if spec_lookup[label].family == "positive_ridge" else 0
        )
        comparison["mode_preference"] = comparison["spec"].map(
            lambda label: 1 if spec_lookup[label].feature_mode == "mean" else 0
        )
        comparison["alpha_preference"] = comparison["spec"].map(
            lambda label: spec_lookup[label].alpha
        )
        best_score = float(comparison["selection_score"].max())
        near_best = comparison[
            comparison["selection_score"] >= best_score - self.simplicity_tolerance
        ]
        ordered = near_best.sort_values(
            [
                "family_preference",
                "mode_preference",
                "selection_score",
                "pairwise_accuracy_gap_ge_2",
                "spearman",
                "percentile_mae",
                "alpha_preference",
            ],
            ascending=[False, False, False, False, False, True, False],
            na_position="last",
        )
        selected = spec_lookup[str(ordered.iloc[0]["spec"])]
        return selected, comparison.drop(
            columns=["family_preference", "mode_preference", "alpha_preference"]
        )

    def nested_groups_oof(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        groups: Mapping[str, Sequence[ModelSpec]],
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Outer LOODO evaluation; every outer fold selects specs by inner LOODO."""

        devices = tuple(sorted(map(str, devices)))
        global_percentiles = dict(
            zip(devices, percentile_rank([score_map[name] for name in devices]), strict=True)
        )
        prediction_rows: list[dict[str, object]] = []
        for heldout in devices:
            outer_train = [name for name in devices if name != heldout]
            outer_features = self.features.get(subdir, outer_train)
            for group_label, candidates in groups.items():
                selected, _ = self.select_spec(
                    subdir, outer_train, score_map, list(candidates)
                )
                prediction, _ = fit_predict_one(
                    outer_features, outer_train, heldout, score_map, selected
                )
                prediction_rows.append(
                    {
                        "subdir": str(subdir),
                        "model_group": str(group_label),
                        "name": heldout,
                        "adjusted_score": float(score_map[heldout]),
                        "target_percentile": float(global_percentiles[heldout]),
                        "oof_prediction": prediction,
                        "selected_spec": selected.label,
                        "selected_spec_json": json.dumps(selected.to_dict(), sort_keys=True),
                    }
                )
        predictions = pd.DataFrame(prediction_rows)
        metric_rows: list[dict[str, object]] = []
        for group_label, group in predictions.groupby("model_group", sort=True):
            metrics = ranking_metrics(
                group["adjusted_score"],
                group["oof_prediction"],
                self.material_gap,
                self.near_tie_gap,
            )
            metric_rows.append(
                {
                    "subdir": str(subdir),
                    "model_group": str(group_label),
                    **metrics,
                    "selection_score": selection_score(metrics),
                }
            )
        return predictions, pd.DataFrame(metric_rows)


def candidate_groups(candidates: Sequence[ModelSpec]) -> dict[str, list[ModelSpec]]:
    """Group exact candidates for interpretable ablation and nested auto-selection."""

    groups: dict[str, list[ModelSpec]] = {"nested_auto": list(candidates)}
    for family in ("positive_ridge", "positive_huber"):
        for mode in ("mean", "stability"):
            subset = [
                spec
                for spec in candidates
                if spec.family == family and spec.feature_mode == mode
            ]
            if subset:
                groups[f"{family}_{mode}"] = subset
    return groups
