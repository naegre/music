"""Equal-x aggregation and model/reliability feature separation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .normalization import METRIC_SPECS


PRIMARY_FEATURES = (
    "l2_quality_mean",
    "l2_quality_median",
    "cos_quality_mean",
    "cos_quality_median",
)

STABILITY_FEATURES = (
    "l2_between_x_stability",
    "l2_within_x_stability",
    "cos_between_x_stability",
    "cos_within_x_stability",
)


def feature_columns(mode: str) -> list[str]:
    """Return quality-only columns for ``mean`` or ``stability`` mode."""

    if mode == "mean":
        return list(PRIMARY_FEATURES)
    if mode == "stability":
        return list(PRIMARY_FEATURES + STABILITY_FEATURES)
    raise ValueError(f"Unknown feature mode: {mode}")


def aggregate_transformed_group(
    group: pd.DataFrame, expected_x_count: int | None = None
) -> dict[str, object]:
    """Aggregate transformed x rows, giving every x exactly equal weight."""

    n_x = int(len(group))
    row: dict[str, object] = {
        "name": str(group["name"].iloc[0]),
        "subdir": str(group["subdir"].iloc[0]),
        "n_x": n_x,
        "n_windows_total": int(group["n_windows_total"].sum()),
        "n_effective_total": float(group["n_effective"].sum()),
        "n_recordings_total": int(group["n_recordings"].sum()),
        "has_multiple_x": int(n_x > 1),
        "normalization_fallback_count": int(group["normalization_fallback_count"].sum()),
    }
    denominator = expected_x_count if expected_x_count and expected_x_count > 0 else n_x
    row["coverage_ratio"] = float(min(n_x / denominator, 1.0))
    row["uncertainty_mode"] = "between_and_within" if n_x > 1 else "within_only"

    for metric in METRIC_SPECS:
        values = group[f"{metric}_quality"].to_numpy(dtype=float)
        per_x_se = group[f"{metric}_quality_se"].to_numpy(dtype=float)
        within_sd = group[f"{metric}_within_sd"].to_numpy(dtype=float)
        between_std = float(np.std(values, ddof=1)) if n_x > 1 else np.nan
        between_se = between_std / np.sqrt(n_x) if n_x > 1 else np.nan
        aggregate_within_se = float(np.sqrt(np.sum(np.square(per_x_se))) / n_x)
        total_se = (
            float(np.sqrt(between_se**2 + aggregate_within_se**2))
            if n_x > 1
            else aggregate_within_se
        )
        row[f"{metric}_quality_mean"] = float(np.mean(values))
        row[f"{metric}_quality_median"] = float(np.median(values))
        row[f"{metric}_between_x_std"] = between_std
        row[f"{metric}_between_x_se"] = between_se
        row[f"{metric}_within_x_se"] = aggregate_within_se
        row[f"{metric}_total_se"] = total_se
        row[f"{metric}_between_x_stability"] = -between_std if n_x > 1 else np.nan
        row[f"{metric}_within_x_stability"] = -float(np.mean(within_sd))
    return row


def aggregate_name_subdir(
    transformed: pd.DataFrame,
    expected_x: dict[str, tuple[str, ...]] | None = None,
) -> pd.DataFrame:
    """Aggregate x-level quality rows to one row per ``name + subdir``."""

    rows: list[dict[str, object]] = []
    for (_, subdir), group in transformed.groupby(["name", "subdir"], sort=True):
        expected_count = len(expected_x.get(str(subdir), ())) if expected_x else None
        rows.append(aggregate_transformed_group(group, expected_count))
    return pd.DataFrame(rows).sort_values(["subdir", "name"]).reset_index(drop=True)


def reliability_warnings(row: pd.Series) -> str:
    """Create a semicolon-delimited warning string for prediction reports."""

    warnings: list[str] = []
    if int(row.get("n_x", 0)) <= 1:
        warnings.append("n_x=1: CI uses within-window uncertainty only")
    if float(row.get("coverage_ratio", 1.0)) < 0.8:
        warnings.append("coverage<80%")
    if int(row.get("normalization_fallback_count", 0)) > 0:
        warnings.append("unseen x/subdir used fallback normalization")
    return "; ".join(warnings)
