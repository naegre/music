"""Audit, but do not silently delete, raw 5-second window observations."""

from __future__ import annotations

import numpy as np
import pandas as pd


def audit_window_thresholds(
    windows: pd.DataFrame,
    cos_threshold: float = 0.21,
    l2_threshold: float = 6.0,
    consensus_fraction: float = 0.8,
) -> pd.DataFrame:
    """Compare the old all-device rule with a robust consensus proposal.

    Parameters
    ----------
    windows:
        One row per ``subdir + x + window_id + name``. This function rejects
        x-level aggregates because window filtering cannot be reconstructed
        after means/variances have replaced individual windows.
    """

    required = {"subdir", "x", "window_id", "name", "cosim", "l2"}
    missing = sorted(required - set(windows.columns))
    if missing:
        raise ValueError(
            f"Window audit requires raw window columns {sorted(required)}; missing {missing}"
        )
    rows: list[dict[str, object]] = []
    for keys, group in windows.groupby(["subdir", "x", "window_id"], sort=True):
        cos = pd.to_numeric(group["cosim"], errors="coerce").to_numpy(dtype=float)
        l2 = pd.to_numeric(group["l2"], errors="coerce").to_numpy(dtype=float)
        if not np.isfinite(cos).all() or not np.isfinite(l2).all():
            status = "hard_fail_non_finite"
        else:
            cos_fraction = float(np.mean(cos < cos_threshold))
            l2_fraction = float(np.mean(l2 > l2_threshold))
            if cos_fraction >= consensus_fraction and l2_fraction >= consensus_fraction:
                status = "hard_fail_both_metrics_consensus"
            elif cos_fraction >= consensus_fraction or l2_fraction >= consensus_fraction:
                status = "gray_zone_keep_or_downweight"
            else:
                status = "keep"
        rows.append(
            {
                "subdir": str(keys[0]),
                "x": str(keys[1]),
                "window_id": str(keys[2]),
                "n_devices": int(group["name"].nunique()),
                "cos_below_fraction": float(np.mean(cos < cos_threshold)),
                "l2_above_fraction": float(np.mean(l2 > l2_threshold)),
                "cos_median": float(np.nanmedian(cos)),
                "l2_median": float(np.nanmedian(l2)),
                "old_all_device_rule_filters": bool(
                    np.all(cos < cos_threshold) or np.all(l2 > l2_threshold)
                ),
                "suggested_status": status,
            }
        )
    return pd.DataFrame(rows)
