"""Subjective-adjusted, rank-focused audio device quality modelling."""

__version__ = "0.1.0"

