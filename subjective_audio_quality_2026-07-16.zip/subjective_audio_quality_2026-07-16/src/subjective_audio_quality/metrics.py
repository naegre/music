"""Rank, error, pairwise, tail, and tolerance-aware evaluation metrics."""

from __future__ import annotations

import math

import numpy as np
from scipy.special import expit
from scipy.stats import kendalltau, pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error

from .targets import percentile_rank


def _finite_correlation(function, left: np.ndarray, right: np.ndarray) -> float:
    if len(left) < 2 or np.all(left == left[0]) or np.all(right == right[0]):
        return float("nan")
    result = function(left, right)
    value = result.statistic if hasattr(result, "statistic") else result[0]
    return float(value)


def correlation_band(value: float) -> str:
    """Return a descriptive association band, not a universal pass/fail rule."""

    if not np.isfinite(value):
        return "undefined"
    absolute = abs(float(value))
    if absolute < 0.10:
        return "negligible"
    if absolute < 0.40:
        return "weak"
    if absolute < 0.70:
        return "moderate"
    if absolute < 0.90:
        return "strong"
    return "very_strong"


def _pair_records(
    scores: np.ndarray,
    prediction: np.ndarray,
    probability_temperature: float,
) -> list[dict[str, float | bool]]:
    records: list[dict[str, float | bool]] = []
    for left in range(len(scores)):
        for right in range(left + 1, len(scores)):
            score_difference = float(scores[left] - scores[right])
            if score_difference == 0.0:
                continue
            prediction_difference = float(prediction[left] - prediction[right])
            truth = float(score_difference > 0.0)
            probability = float(expit(prediction_difference / probability_temperature))
            records.append(
                {
                    "score_gap": abs(score_difference),
                    "correct": bool(np.sign(score_difference) == np.sign(prediction_difference)),
                    "truth": truth,
                    "probability": probability,
                }
            )
    return records


def ranking_metrics(
    scores,
    prediction,
    material_gap: float = 2.0,
    near_tie_gap: float = 1.0,
    probability_temperature: float = 10.0,
) -> dict[str, float | int | str]:
    """Evaluate OOF predictions with rank and user-defined tolerance metrics."""

    score_array = np.asarray(scores, dtype=float)
    prediction_array = np.asarray(prediction, dtype=float)
    target = percentile_rank(score_array)
    pairs = _pair_records(score_array, prediction_array, probability_temperature)
    material = [row for row in pairs if float(row["score_gap"]) >= material_gap]
    gap_gt_1 = [row for row in pairs if float(row["score_gap"]) > near_tie_gap]
    misordered_near = sum(
        (not bool(row["correct"])) and float(row["score_gap"]) <= near_tie_gap
        for row in pairs
    )
    misordered_minor = sum(
        (not bool(row["correct"]))
        and near_tie_gap < float(row["score_gap"]) < material_gap
        for row in pairs
    )
    misordered_material = sum(not bool(row["correct"]) for row in material)
    epsilon = 1e-12
    probabilities = np.clip(
        np.asarray([row["probability"] for row in pairs], dtype=float), epsilon, 1.0 - epsilon
    )
    truths = np.asarray([row["truth"] for row in pairs], dtype=float)
    top_count = min(3, len(score_array))
    true_top = set(np.argsort(score_array)[-top_count:])
    predicted_top = set(np.argsort(prediction_array)[-top_count:])
    true_bottom = set(np.argsort(score_array)[:top_count])
    predicted_bottom = set(np.argsort(prediction_array)[:top_count])
    spearman = _finite_correlation(spearmanr, score_array, prediction_array)
    result: dict[str, float | int | str] = {
        "n": int(len(score_array)),
        "percentile_mae": float(mean_absolute_error(target, prediction_array)),
        "percentile_rmse": float(math.sqrt(mean_squared_error(target, prediction_array))),
        "pearson": _finite_correlation(pearsonr, target, prediction_array),
        "spearman": spearman,
        "spearman_band": correlation_band(spearman),
        "kendall_tau": _finite_correlation(kendalltau, score_array, prediction_array),
        "pairwise_accuracy": float(np.mean([row["correct"] for row in pairs])) if pairs else np.nan,
        "pairwise_accuracy_gap_gt_1": (
            float(np.mean([row["correct"] for row in gap_gt_1])) if gap_gt_1 else np.nan
        ),
        "pairwise_accuracy_gap_ge_2": (
            float(np.mean([row["correct"] for row in material])) if material else np.nan
        ),
        "pairwise_brier": float(np.mean(np.square(probabilities - truths))) if pairs else np.nan,
        "pairwise_log_loss": (
            float(-np.mean(truths * np.log(probabilities) + (1.0 - truths) * np.log(1.0 - probabilities)))
            if pairs
            else np.nan
        ),
        "n_pairs": int(len(pairs)),
        "n_material_pairs": int(len(material)),
        "misordered_gap_le_1": int(misordered_near),
        "misordered_gap_1_to_2": int(misordered_minor),
        "misordered_gap_ge_2": int(misordered_material),
        "accurate_under_2pt_tolerance": (
            float(1.0 - misordered_material / len(pairs)) if pairs else np.nan
        ),
        "top3_recall": float(len(true_top & predicted_top) / top_count),
        "bottom3_recall": float(len(true_bottom & predicted_bottom) / top_count),
    }
    return result


def selection_score(metrics: dict[str, float | int | str]) -> float:
    """Combine rank, material-pair, tail, and percentile errors for selection."""

    rho = float(metrics.get("spearman", -1.0))
    rho = rho if np.isfinite(rho) else -1.0
    material = float(metrics.get("pairwise_accuracy_gap_ge_2", 0.0))
    material = material if np.isfinite(material) else 0.0
    top = float(metrics.get("top3_recall", 0.0))
    bottom = float(metrics.get("bottom3_recall", 0.0))
    mae = float(metrics.get("percentile_mae", 50.0))
    return float(
        0.45 * ((rho + 1.0) / 2.0)
        + 0.30 * material
        + 0.10 * top
        + 0.10 * bottom
        + 0.05 * (1.0 - min(max(mae, 0.0), 50.0) / 50.0)
    )
