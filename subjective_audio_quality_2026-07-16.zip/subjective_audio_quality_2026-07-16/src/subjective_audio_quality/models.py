"""Small monotonic regressors suitable for roughly 10-20 labelled devices."""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
from scipy.optimize import minimize
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


@dataclass(frozen=True)
class ModelSpec:
    """Serializable description of one model candidate."""

    family: str
    feature_mode: str
    alpha: float
    delta: float | None = None

    @property
    def label(self) -> str:
        suffix = f"_delta{self.delta:g}" if self.delta is not None else ""
        return f"{self.family}_{self.feature_mode}_alpha{self.alpha:g}{suffix}"

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class PositiveHuberRegressor(RegressorMixin, BaseEstimator):
    """Huber regression with non-negative coefficients and L2 shrinkage.

    Positive coefficients preserve the declared quality direction after
    standardization. The intercept is unconstrained. This is intentionally
    small and deterministic; it is not a general replacement for sklearn's
    unconstrained ``HuberRegressor``.
    """

    def __init__(self, alpha: float = 1.0, delta: float = 1.35, max_iter: int = 5000):
        self.alpha = alpha
        self.delta = delta
        self.max_iter = max_iter

    def fit(self, x, y):
        x_array = np.asarray(x, dtype=float)
        y_array = np.asarray(y, dtype=float)
        n_features = x_array.shape[1]
        center = float(np.median(y_array))
        mad = 1.4826 * float(np.median(np.abs(y_array - center)))
        scale = mad if mad > 1e-8 else max(float(np.std(y_array)), 1.0)
        threshold = max(float(self.delta) * scale, 1e-6)

        def objective(parameters):
            weights = parameters[:n_features]
            intercept = parameters[-1]
            residual = x_array @ weights + intercept - y_array
            absolute = np.abs(residual)
            quadratic = absolute <= threshold
            loss = np.where(
                quadratic,
                0.5 * np.square(residual),
                threshold * (absolute - 0.5 * threshold),
            )
            psi = np.where(quadratic, residual, threshold * np.sign(residual))
            value = float(np.sum(loss) + 0.5 * float(self.alpha) * np.dot(weights, weights))
            gradient = np.concatenate(
                [x_array.T @ psi + float(self.alpha) * weights, [np.sum(psi)]]
            )
            return value, gradient

        initial = np.concatenate([np.zeros(n_features), [float(np.mean(y_array))]])
        bounds = [(0.0, None)] * n_features + [(None, None)]
        result = minimize(
            objective,
            initial,
            method="L-BFGS-B",
            jac=True,
            bounds=bounds,
            options={"maxiter": int(self.max_iter)},
        )
        if not result.success and not np.isfinite(result.fun):
            raise RuntimeError(f"Positive Huber optimization failed: {result.message}")
        self.coef_ = np.maximum(result.x[:n_features], 0.0)
        self.intercept_ = float(result.x[-1])
        self.n_features_in_ = n_features
        self.optimization_success_ = bool(result.success)
        return self

    def predict(self, x):
        return np.asarray(x, dtype=float) @ self.coef_ + self.intercept_


class PositiveAffineCalibrator:
    """Robustly map percentile predictions to scores with non-negative slope."""

    def __init__(self, method: str = "theil_sen", alpha: float = 10.0):
        self.method = method
        self.alpha = float(alpha)

    def fit(self, prediction, score):
        x = np.asarray(prediction, dtype=float)
        y = np.asarray(score, dtype=float)
        if self.method == "theil_sen":
            slopes = [
                (y[right] - y[left]) / (x[right] - x[left])
                for left in range(len(x))
                for right in range(left + 1, len(x))
                if abs(x[right] - x[left]) > 1e-9
            ]
            self.slope_ = max(0.0, float(np.median(slopes)) if slopes else 0.0)
            self.intercept_ = float(np.median(y - self.slope_ * x))
        elif self.method == "ridge":
            x_center = float(np.mean(x))
            y_center = float(np.mean(y))
            numerator = float(np.dot(x - x_center, y - y_center))
            denominator = float(np.dot(x - x_center, x - x_center) + self.alpha)
            self.slope_ = max(0.0, numerator / denominator)
            self.intercept_ = y_center - self.slope_ * x_center
        else:
            raise ValueError(f"Unknown calibration method: {self.method}")
        return self

    def predict(self, prediction):
        return self.intercept_ + self.slope_ * np.asarray(prediction, dtype=float)


def make_model(spec: ModelSpec) -> Pipeline:
    """Build an impute-scale-regress pipeline from ``ModelSpec``."""

    if spec.family == "positive_ridge":
        regressor = Ridge(
            alpha=float(spec.alpha),
            positive=True,
            solver="lbfgs",
            max_iter=10000,
        )
    elif spec.family == "positive_huber":
        regressor = PositiveHuberRegressor(
            alpha=float(spec.alpha),
            delta=float(spec.delta if spec.delta is not None else 1.35),
        )
    else:
        raise ValueError(f"Unknown model family: {spec.family}")
    return Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
            ("scaler", StandardScaler()),
            ("regressor", regressor),
        ]
    )


def candidate_grid(
    ridge_alphas: tuple[float, ...],
    huber_alphas: tuple[float, ...],
    huber_deltas: tuple[float, ...],
    families: tuple[str, ...] = ("positive_ridge", "positive_huber"),
    modes: tuple[str, ...] = ("mean", "stability"),
) -> list[ModelSpec]:
    """Create the finite candidate grid searched by nested LOODO."""

    output: list[ModelSpec] = []
    for mode in modes:
        if "positive_ridge" in families:
            output.extend(ModelSpec("positive_ridge", mode, alpha) for alpha in ridge_alphas)
        if "positive_huber" in families:
            output.extend(
                ModelSpec("positive_huber", mode, alpha, delta)
                for alpha in huber_alphas
                for delta in huber_deltas
            )
    return output


def model_coefficients(model: Pipeline, feature_names: list[str]) -> list[dict[str, float | str]]:
    """Return coefficients in both standardized and original feature units."""

    scaler = model.named_steps["scaler"]
    regressor = model.named_steps["regressor"]
    standardized = np.asarray(regressor.coef_, dtype=float)
    scales = np.asarray(scaler.scale_, dtype=float)
    original = standardized / np.where(scales > 0, scales, 1.0)
    return [
        {
            "feature": feature,
            "coefficient_standardized": float(coef_std),
            "coefficient_original_units": float(coef_original),
        }
        for feature, coef_std, coef_original in zip(
            feature_names, standardized, original, strict=True
        )
    ]
