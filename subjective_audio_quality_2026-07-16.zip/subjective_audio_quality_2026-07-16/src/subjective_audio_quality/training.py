"""Subdir model comparison, final fitting, calibration, and model packaging."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd

from .config import ExperimentConfig
from .features import aggregate_name_subdir, feature_columns
from .metrics import ranking_metrics
from .models import (
    ModelSpec,
    PositiveAffineCalibrator,
    candidate_grid,
    make_model,
    model_coefficients,
)
from .normalization import PairedRobustNormalizer
from .targets import percentile_rank
from .validation import ValidationRunner, candidate_groups, eligible_devices


def _score_map(targets: pd.DataFrame, subdir: str) -> dict[str, float]:
    group = targets[targets["subdir"].astype(str).eq(str(subdir))]
    return dict(zip(group["name"].astype(str), group["adjusted_score_centered"], strict=True))


def _subdir_k(targets: pd.DataFrame, subdir: str) -> float:
    values = targets.loc[targets["subdir"].astype(str).eq(str(subdir)), "k"].unique()
    if len(values) != 1:
        raise ValueError(f"Expected exactly one k for subdir {subdir!r}, got {values}")
    return float(values[0])


def train_models(
    merged_x_data: pd.DataFrame,
    targets: pd.DataFrame,
    config: ExperimentConfig,
    families: Sequence[str] = ("positive_ridge", "positive_huber"),
    min_devices: int = 6,
    final_reference_scope: str = "all_reference",
) -> tuple[dict, dict[str, pd.DataFrame]]:
    """Evaluate and fit independent rank models for every labelled subdir.

    Returns
    -------
    bundle:
        Joblib-serializable dictionary containing fitted normalizers, models,
        calibrators, and reference predictions.
    outputs:
        DataFrames for CSV reporting: OOF predictions, model comparison,
        selected models, coefficients, aggregated features, and references.
    """

    candidates = candidate_grid(
        config.ridge_alphas,
        config.huber_alphas,
        config.huber_deltas,
        tuple(families),
    )
    runner = ValidationRunner(
        merged_x_data,
        material_gap=config.material_score_gap,
        near_tie_gap=config.near_tie_score_gap,
        simplicity_tolerance=config.model_simplicity_tolerance,
    )
    model_bundles: dict[str, dict] = {}
    oof_frames: list[pd.DataFrame] = []
    comparison_frames: list[pd.DataFrame] = []
    selected_rows: list[dict[str, object]] = []
    coefficient_rows: list[dict[str, object]] = []
    feature_frames: list[pd.DataFrame] = []
    reference_frames: list[pd.DataFrame] = []

    subdirs = sorted(set(targets["subdir"].astype(str)) & set(merged_x_data["subdir"].astype(str)))
    for subdir in subdirs:
        score_map = _score_map(targets, subdir)
        devices = eligible_devices(merged_x_data, subdir, score_map)
        if len(devices) < min_devices:
            selected_rows.append(
                {
                    "subdir": subdir,
                    "status": "skipped_too_few_devices",
                    "n_devices": len(devices),
                }
            )
            continue

        nested_predictions, nested_metrics = runner.nested_groups_oof(
            subdir, devices, score_map, candidate_groups(candidates)
        )
        oof_frames.append(nested_predictions)
        comparison_frames.append(nested_metrics)

        selected_spec, exact_comparison = runner.select_spec(
            subdir, devices, score_map, candidates
        )
        exact_comparison = exact_comparison.copy()
        exact_comparison["model_group"] = "final_exact_candidate_search"
        comparison_frames.append(exact_comparison)
        selected_oof = runner.exact_spec_oof(subdir, devices, score_map, selected_spec)
        selected_oof = selected_oof.assign(model_group="selected_final_spec")
        oof_frames.append(selected_oof)
        selected_metrics = ranking_metrics(
            selected_oof["adjusted_score"],
            selected_oof["oof_prediction"],
            config.material_score_gap,
            config.near_tie_score_gap,
        )

        task = merged_x_data[merged_x_data["subdir"].astype(str).eq(subdir)].copy()
        if final_reference_scope == "all_reference":
            normalizer_fit_rows = task
        elif final_reference_scope == "labelled_only":
            normalizer_fit_rows = task[task["name"].astype(str).isin(devices)]
        else:
            raise ValueError(
                "final_reference_scope must be 'all_reference' or 'labelled_only'"
            )
        final_normalizer = PairedRobustNormalizer().fit(normalizer_fit_rows)
        transformed = final_normalizer.transform(task)
        aggregated = aggregate_name_subdir(transformed, final_normalizer.expected_x_)
        feature_frames.append(aggregated)
        indexed = aggregated.set_index("name")
        columns = feature_columns(selected_spec.feature_mode)
        training_target = percentile_rank([score_map[name] for name in devices])
        final_model = make_model(selected_spec)
        final_model.fit(indexed.loc[devices, columns], training_target)

        calibrator = PositiveAffineCalibrator(method="theil_sen").fit(
            selected_oof["oof_prediction"], selected_oof["adjusted_score"]
        )
        reference_names = sorted(indexed.index.astype(str).unique())
        reference_percentile = np.clip(
            final_model.predict(indexed.loc[reference_names, columns]), 0.0, 100.0
        )
        reference = pd.DataFrame(
            {
                "subdir": subdir,
                "name": reference_names,
                "predicted_percentile": reference_percentile,
                "predicted_adjusted_score": calibrator.predict(reference_percentile),
                "is_labelled": [name in score_map for name in reference_names],
            }
        )
        reference["reference_rank"] = reference["predicted_percentile"].rank(
            method="min", ascending=False
        ).astype(int)
        reference_frames.append(reference)

        for coefficient in model_coefficients(final_model, columns):
            coefficient_rows.append({"subdir": subdir, **coefficient})
        nested_auto_row = nested_metrics[
            nested_metrics["model_group"].eq("nested_auto")
        ].iloc[0]
        primary_metrics = {
            column: nested_auto_row[column]
            for column in nested_metrics.columns
            if column not in {"subdir", "model_group"}
        }
        selected_rows.append(
            {
                "subdir": subdir,
                "status": "trained",
                "n_devices": len(devices),
                "k": _subdir_k(targets, subdir),
                "selected_spec": selected_spec.label,
                "feature_mode": selected_spec.feature_mode,
                "family": selected_spec.family,
                "alpha": selected_spec.alpha,
                "delta": selected_spec.delta,
                "reported_validation": "nested_auto_outer_LOODO",
                **primary_metrics,
                "selected_spec_oof_spearman": selected_metrics["spearman"],
                "selected_spec_oof_material_pair_accuracy": selected_metrics[
                    "pairwise_accuracy_gap_ge_2"
                ],
                "selected_spec_oof_percentile_mae": selected_metrics["percentile_mae"],
            }
        )
        model_bundles[subdir] = {
            "subdir": subdir,
            "k": _subdir_k(targets, subdir),
            "normalizer": final_normalizer,
            "model": final_model,
            "calibrator": calibrator,
            "spec": selected_spec,
            "feature_columns": columns,
            "labelled_devices": devices,
            "score_map": score_map,
            "reference_predictions": reference,
            "selected_oof": selected_oof,
        }

    outputs = {
        "oof_predictions": pd.concat(oof_frames, ignore_index=True) if oof_frames else pd.DataFrame(),
        "model_comparison": (
            pd.concat(comparison_frames, ignore_index=True) if comparison_frames else pd.DataFrame()
        ),
        "selected_models": pd.DataFrame(selected_rows),
        "coefficients": pd.DataFrame(coefficient_rows),
        "aggregated_features": (
            pd.concat(feature_frames, ignore_index=True) if feature_frames else pd.DataFrame()
        ),
        "reference_predictions": (
            pd.concat(reference_frames, ignore_index=True) if reference_frames else pd.DataFrame()
        ),
    }
    metadata = {
        "schema_version": 1,
        "package": "subjective_audio_quality",
        "subjective_variant": config.subjective_variant,
        "subdirs": sorted(model_bundles),
        "feature_policy": "L2/cosine only; KL/JS excluded",
        "validation": "nested Leave-One-Device-Out with fold-local normalization/imputation/scaling",
        "model_simplicity_tolerance": config.model_simplicity_tolerance,
        "final_reference_scope": final_reference_scope,
        "n_models": len(model_bundles),
        "selected_models": [
            {
                "subdir": subdir,
                "k": payload["k"],
                "spec": payload["spec"].to_dict(),
                "n_labelled_devices": len(payload["labelled_devices"]),
            }
            for subdir, payload in sorted(model_bundles.items())
        ],
    }
    return {"metadata": metadata, "models": model_bundles}, outputs
