"""Leakage-safe paired robust normalization within each ``subdir + x``."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class MetricSpec:
    """Columns, transform, and quality direction for one metric."""

    mean_column: str
    variance_column: str
    transform: str
    direction: float


METRIC_SPECS = {
    "l2": MetricSpec("l2_mean", "l2_var", "log1p", -1.0),
    "cos": MetricSpec("cos_mean", "cos_var", "fisher", 1.0),
}


def transform_values(values: np.ndarray, transform: str) -> np.ndarray:
    """Apply log1p or clipped Fisher/atanh transformation."""

    array = np.asarray(values, dtype=float)
    if transform == "log1p":
        return np.log1p(np.maximum(array, 0.0))
    if transform == "fisher":
        return np.arctanh(np.clip(array, -0.999999, 0.999999))
    raise ValueError(f"Unknown transform: {transform}")


def transformed_variance(mean: float, variance: float, transform: str) -> float:
    """Approximate transformed variance using the delta method."""

    variance = max(float(variance), 0.0)
    if transform == "log1p":
        return variance / max((1.0 + max(float(mean), 0.0)) ** 2, 1e-12)
    if transform == "fisher":
        clipped = float(np.clip(mean, -0.999999, 0.999999))
        return variance / max((1.0 - clipped**2) ** 2, 1e-12)
    raise ValueError(f"Unknown transform: {transform}")


def robust_location_scale(
    values: np.ndarray | pd.Series,
    fallback_scale: float | None = None,
    epsilon: float = 1e-9,
) -> tuple[float, float, str]:
    """Estimate median/MAD scale with IQR, standard deviation, then fallback."""

    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    if array.size == 0:
        raise ValueError("Cannot fit robust statistics to an empty array")
    center = float(np.median(array))
    mad_scale = float(1.4826 * np.median(np.abs(array - center)))
    if mad_scale > epsilon:
        return center, mad_scale, "mad"
    if array.size >= 2:
        q25, q75 = np.quantile(array, [0.25, 0.75])
        iqr_scale = float((q75 - q25) / 1.349)
        if iqr_scale > epsilon:
            return center, iqr_scale, "iqr"
        std_scale = float(np.std(array, ddof=1))
        if std_scale > epsilon:
            return center, std_scale, "std"
    if fallback_scale is not None and np.isfinite(fallback_scale) and fallback_scale > epsilon:
        return center, float(fallback_scale), "fallback"
    return center, 1.0, "unit"


class PairedRobustNormalizer:
    """Fit robust references without looking at held-out devices.

    During cross-validation, call :meth:`fit` with outer-training rows only.
    The final saved model may use all fixed reference devices, including devices
    without human labels. A future device never refits these statistics.
    """

    def __init__(self, z_clip: float = 8.0):
        self.z_clip = float(z_clip)
        self.exact_stats_: dict[tuple[str, str, str], tuple[float, float, str, int]] = {}
        self.subdir_stats_: dict[tuple[str, str], tuple[float, float, str, int]] = {}
        self.global_stats_: dict[str, tuple[float, float, str, int]] = {}
        self.expected_x_: dict[str, tuple[str, ...]] = {}
        self.fitted_ = False

    def fit(self, frame: pd.DataFrame) -> "PairedRobustNormalizer":
        """Fit metric references from a canonical, alias-merged x-level table."""

        if frame.empty:
            raise ValueError("Cannot fit normalizer on an empty table")
        self.exact_stats_.clear()
        self.subdir_stats_.clear()
        self.global_stats_.clear()
        self.expected_x_ = {
            str(subdir): tuple(sorted(group["x"].astype(str).unique()))
            for subdir, group in frame.groupby("subdir")
        }
        for metric, spec in METRIC_SPECS.items():
            transformed = transform_values(frame[spec.mean_column].to_numpy(), spec.transform)
            working = frame[["subdir", "x"]].copy()
            working["value"] = transformed
            global_stat = robust_location_scale(working["value"])
            self.global_stats_[metric] = (*global_stat, int(len(working)))
            for subdir, group in working.groupby("subdir"):
                stat = robust_location_scale(group["value"], fallback_scale=global_stat[1])
                self.subdir_stats_[(metric, str(subdir))] = (*stat, int(len(group)))
            for (subdir, audio_id), group in working.groupby(["subdir", "x"]):
                fallback = self.subdir_stats_[(metric, str(subdir))][1]
                stat = robust_location_scale(group["value"], fallback_scale=fallback)
                self.exact_stats_[(metric, str(subdir), str(audio_id))] = (
                    *stat,
                    int(len(group)),
                )
        self.fitted_ = True
        return self

    def _statistics(self, metric: str, subdir: str, audio_id: str):
        exact = self.exact_stats_.get((metric, subdir, audio_id))
        if exact is not None:
            return exact, "subdir_x"
        subdir_stat = self.subdir_stats_.get((metric, subdir))
        if subdir_stat is not None:
            return subdir_stat, "subdir_fallback"
        return self.global_stats_[metric], "global_fallback"

    def transform(self, frame: pd.DataFrame) -> pd.DataFrame:
        """Add per-x quality, within-x SD, uncertainty, and fallback columns."""

        if not self.fitted_:
            raise RuntimeError("PairedRobustNormalizer.fit must be called first")
        output = frame.copy()
        fallback_counts = np.zeros(len(output), dtype=int)
        for metric, spec in METRIC_SPECS.items():
            transformed = transform_values(output[spec.mean_column].to_numpy(), spec.transform)
            qualities: list[float] = []
            within_sds: list[float] = []
            quality_ses: list[float] = []
            levels: list[str] = []
            for position, (_, row) in enumerate(output.iterrows()):
                stats, level = self._statistics(metric, str(row["subdir"]), str(row["x"]))
                center, scale, _, _ = stats
                z_value = float(np.clip((transformed[position] - center) / scale, -self.z_clip, self.z_clip))
                qualities.append(spec.direction * z_value)
                transformed_var = transformed_variance(
                    float(row[spec.mean_column]), float(row[spec.variance_column]), spec.transform
                )
                within_sd = float(np.sqrt(transformed_var) / scale)
                n_effective = float(row.get("n_effective", 1.0))
                within_sds.append(within_sd)
                quality_ses.append(within_sd / np.sqrt(max(n_effective, 1.0)))
                levels.append(level)
                if level != "subdir_x":
                    fallback_counts[position] += 1
            output[f"{metric}_quality"] = qualities
            output[f"{metric}_within_sd"] = within_sds
            output[f"{metric}_quality_se"] = quality_ses
            output[f"{metric}_normalization_level"] = levels
        output["normalization_fallback_count"] = fallback_counts
        return output

    def statistics_frame(self) -> pd.DataFrame:
        """Return exact fitted centers/scales for audit and reproducibility."""

        rows = []
        for (metric, subdir, audio_id), (center, scale, method, n) in self.exact_stats_.items():
            rows.append(
                {
                    "metric": metric,
                    "subdir": subdir,
                    "x": audio_id,
                    "center": center,
                    "scale": scale,
                    "scale_method": method,
                    "n_reference_devices": n,
                }
            )
        return pd.DataFrame(rows).sort_values(["subdir", "x", "metric"]).reset_index(drop=True)

