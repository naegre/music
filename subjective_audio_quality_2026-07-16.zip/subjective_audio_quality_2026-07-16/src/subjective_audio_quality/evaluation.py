"""Evaluate saved predictions against updated or external subdir labels."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .metrics import ranking_metrics


def evaluate_prediction_table(
    predictions: pd.DataFrame,
    targets: pd.DataFrame,
    material_gap: float = 2.0,
    near_tie_gap: float = 1.0,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return per-subdir metrics and per-device rank/crossing audits."""

    valid_predictions = predictions[predictions["status"].eq("ok")].copy()
    joined = valid_predictions.merge(
        targets[
            ["subdir", "name", "adjusted_score_centered", "target_percentile"]
        ],
        on=["subdir", "name"],
        how="inner",
        validate="many_to_one",
    )
    metric_rows: list[dict[str, object]] = []
    audit_rows: list[dict[str, object]] = []
    for subdir, group in joined.groupby("subdir", sort=True):
        group = group.copy().reset_index(drop=True)
        if len(group) >= 3:
            metric_rows.append(
                {
                    "subdir": str(subdir),
                    **ranking_metrics(
                        group["adjusted_score_centered"],
                        group["predicted_percentile"],
                        material_gap,
                        near_tie_gap,
                    ),
                }
            )
        true_rank = group["adjusted_score_centered"].rank(method="min", ascending=False)
        predicted_rank = group["predicted_percentile"].rank(method="min", ascending=False)
        for index, row in group.iterrows():
            material_pairs = 0
            material_crossings = 0
            acceptable_crossings = 0
            for other_index, other in group.iterrows():
                if index == other_index:
                    continue
                score_gap = abs(
                    float(row["adjusted_score_centered"])
                    - float(other["adjusted_score_centered"])
                )
                correct = np.sign(
                    float(row["adjusted_score_centered"])
                    - float(other["adjusted_score_centered"])
                ) == np.sign(
                    float(row["predicted_percentile"])
                    - float(other["predicted_percentile"])
                )
                if score_gap >= material_gap:
                    material_pairs += 1
                    material_crossings += int(not correct)
                elif not correct:
                    acceptable_crossings += 1
            audit_rows.append(
                {
                    "subdir": str(subdir),
                    "name": str(row["name"]),
                    "true_score": float(row["adjusted_score_centered"]),
                    "predicted_percentile": float(row["predicted_percentile"]),
                    "true_rank": int(true_rank.iloc[index]),
                    "predicted_rank": int(predicted_rank.iloc[index]),
                    "rank_error": int(abs(true_rank.iloc[index] - predicted_rank.iloc[index])),
                    "material_pairs": material_pairs,
                    "material_crossings": material_crossings,
                    "acceptable_crossings_under_2pt": acceptable_crossings,
                }
            )
    return pd.DataFrame(metric_rows), pd.DataFrame(audit_rows)

