# 源码模块

包名为 `subjective_audio_quality`。依赖方向大致为：

```text
config/io -> merge/targets -> normalization -> features
features/models/metrics -> validation -> training/tuning
training bundle -> prediction/evaluation
```

`normalization` 和 `validation` 是防泄漏核心；修改时必须运行 `tests/test_core.py` 中的 held-out extreme 测试。`training` 负责 orchestration，不应在这里重新实现统计公式。逐函数说明见 [FUNCTION_REFERENCE.md](../docs/FUNCTION_REFERENCE.md)。

