# K 值筛选

## K 的作用

目标排序来自：

```text
objective_subdir_score + k * subjective_weighted_contribution
```

K 不是由物理单位唯一决定的真值，而是“主观贡献改变客观 subdir 排名的强度”。K 越大，模型被要求更接近主客观综合顺序；但现有 L2/cosine 未必能观测所有主观因素，因此 K 过大可能降低可预测性。

还要注意目标内生性：每个 K 都会生成一个不同的“真值排序”。内部搜索只能回答“哪一种主客观混合最容易被当前 L2/cosine 模型复现”，不能单独识别真实人类权重。若 `k=0` 获胜，可能只是特征主要测到客观维度；若 `k=2` 获胜，也可能只是某次设备换位恰好与特征一致。

## 代码流程

`tuning.tune_k_grid()` 对每个 K、每个 subdir：

1. 重新构造调整后标签和百分位。
2. 只用非负 Ridge 的 mean/stability 候选，避免把“选 K”和“选复杂模型”混成一个问题。
3. 外层 Leave-One-Device-Out 评估；每个外层训练折内部再选择 alpha 和 feature mode。
4. 计算 Spearman、两分以上 pair accuracy、Top/Bottom-3 与 percentile MAE。
5. 计算综合 selection score。
6. 在最优分 `0.02` 内选更小 K，降低小样本曲线抖动造成的过拟合。

## 运行

```bash
python main.py tune-k

python main.py tune-k \
  --k-values 0,0.25,0.5,0.75,1,1.25,1.5,2 \
  --near-best-tolerance 0.02
```

输入：processed x 表、合并后的客观 JSON、主观方案和 experiment 配置。

输出：

- `k_internal_metrics.csv`：每个 subdir/K 的严格嵌套指标。
- `k_internal_oof_predictions.csv`：每台设备在每个 K 的 OOF 预测。
- `k_selected_by_subdir.csv/json`：保守 K。
- `k_global_summary.csv`：若必须统一 K 时的跨 subdir 摘要。

## 当前领域保守配置

```json
{
  "clarity": 0.25,
  "clarity_voice": 1.5,
  "edginess": 0.25,
  "fullness": 0.5,
  "lowfreq": 1.0,
  "treble": 0.5
}
```

这是结合旧网格结果、实际测试是否包含声像/THD及保守性得到的配置，不是假设永远正确。新增足够设备后应重跑；若不同 bootstrap/设备子集下 K 频繁跳变，优先统一使用 `k=0.5`，而不是追逐逐 subdir 点最优。

2026-07-16 新严格实现的“模型对齐选择”为：`clarity=2, clarity_voice=0, edginess=0, fullness=0, lowfreq=1, treble=2`；全局综合分偏好 `k=2`，但全局平均 Spearman 和 material-pair accuracy 实际在 `k=1` 略高。这个冲突，加上 K 改变目标本身，说明不能把新数值直接覆盖领域配置。相关表完整保存在 `results/k_tuning/`。

## 不能做的事

- 不能用 `new.json` 的 iPad 结果选 K，再把同一个 iPad 叫作外部验证。
- 不能仅凭某个设备名次改善选择 K；应看跨全部 outer folds 的结果。
- 不能因为 K 大让人工目标看起来“更主观”就默认更好；特征必须有能力预测这部分变化。
