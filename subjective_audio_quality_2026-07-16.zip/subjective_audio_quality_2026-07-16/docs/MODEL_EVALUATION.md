# 模型筛选与指标

## 先说明“优秀”的含义

不存在跨数据集通用的 Spearman、MAE 或 pairwise accuracy 及格线。相关系数还受样本范围、噪声和设备数量影响。[Schober 等, 2018](https://doi.org/10.1213/ANE.0000000000002864)给出的相关强度可作描述：`0-.09` negligible、`.10-.39` weak、`.40-.69` moderate、`.70-.89` strong、`.90-1.0` very strong；这不是部署标准。

本项目只有约 10 到 12 个标签设备，以下“优秀”是针对当前目标制定的工程验收线，必须基于外层 OOF 或真正新增设备，而不是训练拟合值。

| 指标 | 含义 | 当前可用 | 当前优秀 |
|---|---|---:|---:|
| Spearman rho | 单调排名相关；允许非线性 | >=0.70 | >=0.85 |
| Kendall tau | 一致/不一致设备对的净比例 | >=0.50 | >=0.65 |
| 2 分以上 pair accuracy | 真正有感知差异设备对的顺序正确率 | >=0.80 | >=0.90 |
| Percentile MAE | 0-100 排名百分位的平均绝对误差 | <=15 | <=10 |
| Percentile RMSE | 更惩罚大幅名次错误 | <=20 | <=15 |
| Top/Bottom-3 recall | 前三/后三设备找回比例 | >=0.667 | 1.0 |
| Pairwise Brier | 概率误差，0 最好；平衡问题恒报 0.5 约为 0.25 | <=0.18 | <=0.10 |
| Pairwise log loss | 概率置信错误惩罚；恒报 0.5 为 0.693 | <=0.60 | <=0.40 |

Kendall 的 pair concordance 思路来自 [Kendall, 1938](https://doi.org/10.1093/biomet/30.1-2.81)。Brier score 的概率预测定义来自 [Brier, 1950](https://doi.org/10.1175/1520-0493%281950%29078%3C0001%3AVOFEIT%3E2.0.CO%3B2)。

## 各指标如何读

### MAE 与 RMSE

两者针对目标百分位，不是原始人工分。MAE 表示典型误差；RMSE 对少数大错更敏感。RMSE 明显大于 MAE 时，应逐台检查是否存在 QXS/Magicpad 一类系统性残差。

### Pearson、Spearman、Kendall

- Pearson 衡量百分位预测与目标百分位的线性关系，是次要指标。
- Spearman 衡量单调排名，是主指标；适合有极端原始分数的 subdir。
- Kendall tau 直接从设备对一致性解释，小样本下很直观。

高 rho 不保证 Top-3 正确，也不保证两分以上设备对没有翻转，所以三者不能单独使用。

### 两分容忍规则

- 分差 `<=1`：近似并列，翻转不视为实际问题。
- `1<分差<2`：轻微误差，可接受但记录。
- 分差 `>=2`：material pair，翻转计为真实错误。

因此重点看 `pairwise_accuracy_gap_ge_2` 和 `misordered_gap_ge_2`。`accurate_under_2pt_tolerance` 会把两分以内翻转视为可接受，数值通常偏高，只能作辅助。

### Brier 与 log loss

代码把百分位差通过固定 sigmoid 温度 10 转成设备对概率。Brier/log loss 评估概率是否校准，而不只是顺序。温度未经过独立校准时，它们只能比较同一版本模型，不能与其他项目横向对标。

## 小样本风险

12 台设备只有 66 对，若只有 50 个 material pair，多错 2 对准确率就下降 4 个百分点。Top-3 recall 也只能取 `0, .333, .667, 1`。因此：

1. 先看 nested outer-LOODO。
2. 再看每台设备 material crossings。
3. 报 bootstrap 区间，不只报点估计；bootstrap 方法的基础见 [Efron, 1979](https://doi.org/10.1214/aos/1176344552)。
4. 最终以持续新增设备的冻结外部测试为准。

## 选择规则

代码的内部 selection score 为：

```text
0.45 * scaled_spearman
+ 0.30 * material_pair_accuracy
+ 0.10 * top3_recall
+ 0.10 * bottom3_recall
+ 0.05 * scaled_percentile_mae
```

它只用于内层选择。报告仍应展示每个原始指标，不能只展示综合分。
