# 模型训练与选择

## 为什么是小模型

每个 subdir 约 10 到 12 个有标签产品，特征维度必须非常小。深度网络、随机森林或复杂 stacking 在这个样本量下几乎一定产生高方差；即使训练集排名漂亮，也难以说明对新设备有效。

训练标签先变成 0 到 100 的 mid-rank percentile。它保留顺序和并列关系，并阻止 `169.803` 之类的原始尺度极值主宰损失。

## 特征候选

`mean` 模式：

```text
l2_quality_mean, l2_quality_median,
cos_quality_mean, cos_quality_median
```

`stability` 模式另外加入：

```text
- L2/Cos quality 的 between-x std
- L2/Cos 变换后 within-x SD 的均值
```

所有字段都转换成“越大越好”。SE、coverage、`n_windows` 和 `n_x` 不进入模型。

## 候选 1：非负 Ridge

Ridge 最小化平方误差并对系数平方和加惩罚：

```text
min sum((y - Xb)^2) + alpha * ||b||^2, subject to b >= 0
```

正则化在 L2/cosine 特征高度相关时降低系数方差；非负约束保证任何已定义为“质量改善”的特征不会反向拉低预测。原始 Ridge 方法见 [Hoerl 与 Kennard, 1970](https://doi.org/10.1080/00401706.1970.10488634)。

## 候选 2：非负 Huber

Huber 损失对小残差使用平方损失，对大残差转为线性增长，因此单台异常设备的影响小于普通最小二乘。本项目用带 L2 惩罚和非负系数约束的自定义实现。原始稳健估计理论见 [Huber, 1964](https://doi.org/10.1214/aoms/1177703732)。

Huber 不是默认赢家。只有严格 OOF 同时改善排名、两分以上设备对和误差时才选择；否则保留更简单的 Ridge。

模型综合分在最优值 `0.01` 内时执行简化规则：先选 Ridge，再选 mean，最后才比较该简化组内的综合分。这是针对 10 到 12 个标签设备的保守选择，不把万分位的小差异解释成模型优势。

## 嵌套 Leave-One-Device-Out

外层每次完全留出一台设备，用于最终验证。内层在剩余设备上选择：

- Ridge 或 Huber；
- mean 或 stability 特征；
- alpha；
- Huber delta。

每个内外折都重新拟合 paired median/MAD、缺失值中位数和 StandardScaler。训练/调参共用同一层 CV 会产生乐观偏差；嵌套 CV 的必要性见 [Varma 与 Simon, 2006](https://doi.org/10.1186/1471-2105-7-91)，实现上的防泄漏原则也与 [scikit-learn 官方指南](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage)一致。

`model_comparison.csv` 中 `nested_auto` 是主要的 selection-aware 泛化估计。`final_exact_candidate_search` 用全标签 LOODO 选择最终部署 spec，它对“已选择模型”的性能会略乐观，不能替代 `nested_auto`。

## 分数校准

模型本体输出百分位。为了便于展示，使用 OOF 百分位和 centered adjusted score 拟合非负 Theil-Sen 直线。它只改变显示尺度，不改变排名；极端 subdir 下绝对预测分数仍不应被解释为 MOS。

## KL/JS

KL_PQ、KL_QP、JS 均保留在 raw/processed 表，但今天的默认模型不读取。原因是它们在现有设备上的方向和方差不稳定，加入后没有跨 subdir 的一致 OOF 改善。未来若重新启用，必须只拟合 primary 模型的 OOF 残差，并将修正系数限制为很小的离散 gamma；不能与主特征无约束混合。

## 运行

```bash
# 只比较，不保存 bundle
python main.py evaluate

# 比较后拟合最终模型
python main.py train

# 快速验证 Ridge 路径
python main.py train --families positive_ridge

# 严格 inductive 外部审计：无标签设备也不参与最终 robust 基准
python main.py train --families positive_ridge --reference-scope labelled_only \
  --output-dir results/train_inductive \
  --model models/model_bundle_inductive.joblib
```

输入：`x_metrics_merged.csv`、`targets.csv`、experiment 配置。输出：OOF、模型比较、选择表、系数、聚合特征、参考预测和 joblib bundle。
