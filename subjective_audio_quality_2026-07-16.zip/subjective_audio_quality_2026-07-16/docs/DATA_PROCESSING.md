# 数据处理

## 输入单位

输入一行是一个设备 `name`、一个任务 `subdir`、一段固定测试音频 `x` 的统计。它已经由 5 秒窗口、1 秒步长聚合，因此这里绝不能再执行一次“窗口到 x”的聚合。

同一 `subdir + x` 在所有设备中对应同一原始内容，这是 paired robust 标准化成立的前提。

## 1. 列映射与检查

`io.canonicalize_columns()` 把实际列名映射为：

```text
subdir, name, x, n_windows,
l2_mean, l2_var, cos_mean, cos_var
```

它检查缺列、非有限值、负方差、`n_windows<1` 和负 L2。中文列名可直接改 `configs/experiment.json` 的 `columns` 映射。

## 2. 产品别名合并

`merge.merge_metric_rows()` 以产品、subdir、x 为单位合并重复录音。均值按原始窗口数加权；方差使用组内方差与录音均值差组成的 pooled variance，而不是简单平均方差。

窗口数分成三个字段：

```text
n_windows_total = 各录音原始窗口数之和
n_effective = sum(max(1, (n_windows_i + 4) / 5))
n_recordings = 合并的录音行数
```

5 秒窗、1 秒步长相邻窗口重叠 80%，不能把所有窗口当独立样本。重复录音之间近似独立，所以先对每次录音估计有效样本数，再相加；不能先把窗口总数相加再只套一次公式。

## 3. 明确排除

`merge.apply_row_exclusions()` 只执行配置中有 subdir、x 和理由的规则。当前唯一规则是 `fullness x=0`。输出 `row_exclusion_audit.csv`，不会静默删除。

## 4. 主观贡献

主观 JSON 中的值已经乘过 overall 权重。缺失值必须是 JSON `null`。

`targets.build_target_table()` 计算：

```text
raw = objective + k * subjective_contribution
centered = objective + k * (subjective_contribution - subdir_subjective_median)
```

两者排名完全相同。训练百分位取自 `raw`，输出和校准使用 `centered`，因此显示值仍接近原客观尺度。每个 subdir 可使用不同 K。

## 5. paired robust 标准化

对每个指标先变换：

```text
L2 transformed = log1p(max(L2, 0))
Cos transformed = atanh(clip(cosim, -0.999999, 0.999999))
```

在每个 `subdir + x` 内跨训练设备估计 median 和 scale：

```text
scale = 1.4826 * MAD
MAD=0 时依次 fallback: IQR/1.349 -> sample std -> subdir scale -> 1
```

统一质量方向：

```text
l2_quality = -robust_z(log1p(l2_mean))
cos_quality = robust_z(atanh(cos_mean))
```

交叉验证时 median/MAD 仅使用本折训练设备。最终模型可以让无人工标签的固定参考设备参与 robust 基准，但未来新设备只能使用保存的 normalizer，不能重新拟合。

## 6. 聚合不同 x

`features.aggregate_name_subdir()` 对同一 `name + subdir` 的 x 等权求 mean/median。它还输出：

```text
between_x_std, between_x_se
within_x_se, total_se
n_x, coverage_ratio, n_windows_total, n_effective_total
has_multiple_x, uncertainty_mode
```

当 `n_x=1`：mean=median，`between_x_std` 与 `between_x_se` 为 NaN，`total_se` 仅来自 x 内方差，`uncertainty_mode=within_only`。写 0 会错误表达“已确认完全稳定”。

窗口方差先经 delta method 变换，再除以 `n_effective` 得到 x 的 SE。多个 x 的总 SE 同时考虑 x 间波动和 x 内测量波动。

## 运行与输出

```bash
python main.py prepare --use-recommended-k
python main.py prepare --k 0.5
python main.py prepare --k-map results/k_tuning/k_selected_by_subdir.json
```

输入是原始 TSV/CSV、客观 JSON、主观 JSON、别名 JSON 和 experiment JSON；输出字段见 [data/README.md](../data/README.md)。

