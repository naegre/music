# 模型预测与结果好坏

## 预测流程

`python main.py predict --data NEW.csv` 会：

1. 验证列并合并新数据中的录音别名。
2. 应用与训练完全相同的明确排除规则。
3. 使用 bundle 内保存的 `subdir+x` median/MAD；不允许用新设备重新拟合。
4. 对 x 等权聚合，并输出 subdir 百分位与辅助校准分数。
5. 与有标签参考设备比较，计算名次、最近明显更好/更差设备和近似同档设备。
6. 按 x bootstrap，给出百分位、分数和名次的 95% 区间。

当 `n_x=1`，无法重采样不同音频，只能依据窗口方差和 `n_effective` 参数化采样。结果标为 `within_only_parametric`，其区间没有包含“换一首测试音频”的不确定性，可信度有限。

## new_device_rankings.csv

| 字段 | 含义 |
|---|---|
| `predicted_percentile` | 主输出，越高越好 |
| `predicted_adjusted_score` | robust 线性校准值，只作辅助 |
| `estimated_rank` | 相对有标签参考设备的估计名次 |
| `rank_denominator` | 本次排名总设备数 |
| `percentile_ci_*` | x bootstrap 的 95% 百分位区间 |
| `rank_ci_*` | 相对固定参考设备的可能名次区间 |
| `nearest_clearly_better/worse` | 校准分至少相差约 2 的最近参考设备 |
| `approximately_same` | 校准分相差不超过约 1 的参考设备 |
| `coverage_ratio` | 新设备 x 覆盖/训练参考 x 覆盖 |
| `ci_source` | `x_bootstrap` 或 `within_only_parametric` |
| `warnings` | n_x=1、覆盖不足或 unseen-x fallback |

`new_vs_reference_probabilities.csv` 的 `p_new_better` 是 bootstrap 样本中，新设备百分位高于该参考设备的比例。它是基于测量不确定性的经验概率，不是“80% 听众一定更喜欢”的心理测量概率。

## 如何判断新预测好不好

有真实主观+客观标签后，运行：

```bash
python main.py evaluate-predictions \
  --predictions results/predict/new_device_rankings.csv \
  --scores /path/to/frozen_external_scores.json
```

先看：

1. 新设备对分差 >=2 的已知设备产生了多少 `material_crossings`。
2. 真实名次是否落在 `rank_ci_low~rank_ci_high`。
3. Top/Bottom-3 是否正确，避免只看平均名次误差。
4. 多台连续新设备上的 Spearman 和 material-pair accuracy，而不是一台设备的偶然结果。
5. 错误是否集中在同一 subdir 或同类设备；集中错误意味着缺特征或采集域偏移。

排名差两三位不一定坏：若跨过的设备真实分差都小于 1，实际没有明显问题；若跨过一台相差 3 分设备，即使名次只错 1 位也应重点处理。

## 冻结外部评估

K、特征、阈值和模型族确定后，把新设备标签冻结为外部集。查看结果后继续改规则会造成测试泄漏。应积累多批新设备，按时间做 rolling external validation；一批只用于报告，下一批才能验证修改是否真正改善。

默认部署 bundle 的 `all_reference` 模式允许无人工标签的固定设备参与最终 median/MAD，这符合半监督参考基准，但不是完全 inductive。若某台设备要作为严格外部测试，它的特征也不应进入 normalizer；请用训练命令的 `--reference-scope labelled_only` 生成独立审计 bundle。
