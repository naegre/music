# 函数输入输出参考

以下列出源码中的公共入口；以下划线开头的函数是模块内部实现，不应由外部脚本依赖。

## config.py

- `ColumnConfig.from_mapping(mapping) -> ColumnConfig`：输入 canonical-name 到实际列名的字典；输出冻结列配置。
- `ColumnConfig.rename_to_canonical() -> dict`：输出 pandas rename 所需的反向映射。
- `ExperimentConfig.from_dict(payload) -> ExperimentConfig`：把 JSON 字典转为带类型配置。
- `load_json(path) -> Any`：输入 UTF-8 JSON 路径；输出 Python 对象。
- `save_json(payload, path) -> None`：写 UTF-8 JSON，保留中文。
- `load_experiment(path) -> ExperimentConfig`：读取 experiment JSON。

## io.py

- `read_table(path) -> DataFrame`：自动识别 CSV/TSV 分隔符；不改变列。
- `canonicalize_columns(frame, columns) -> DataFrame`：输入 raw 表和 `ColumnConfig`；输出 canonical x 表并检查数值域。
- `write_csv(frame, path) -> None`：输出 UTF-8-SIG CSV，方便 Excel 打开。
- `summarize_input(frame) -> dict`：输出 rows/devices/subdirs/subdir-x 数量。

## merge.py

- `effective_window_count(n_windows) -> float`：计算 `max(1,(n+4)/5)`。
- `metric_pairs(frame) -> list[(mean,var)]`：发现所有可 pooled 的均值/方差列，包括保留的 KL/JS。
- `merge_metric_rows(frame, aliases) -> (merged, audit)`：输入 canonical raw x 表和别名字典；输出产品/x pooled 表及来源审计。
- `merge_score_maps(scores, aliases) -> (dict, audit)`：输入 subdir-first 客观标签；输出别名合并标签及审计。
- `merge_nullable_values(values, aliases) -> dict`：合并可为 `None` 的主观值。
- `apply_row_exclusions(frame, rules) -> (kept, audit)`：应用显式 subdir/x 规则，输出保留表和删除原因。

## targets.py

- `percentile_rank(values) -> ndarray`：输入分数；输出 `(0,100)` mid-rank percentile。
- `resolve_k(k, subdir) -> float`：接受单一 K 或 subdir-K 字典。
- `build_target_table(objective_scores, subjective, k) -> (targets, audit)`：输出客观/主观/K/调整分/百分位长表及缺失审计。
- `target_table_to_nested_json(targets, value_column) -> dict`：把长表转成 subdir-first JSON。

## normalization.py

- `transform_values(values, transform) -> ndarray`：执行 `log1p` 或 clipped Fisher transform。
- `transformed_variance(mean, variance, transform) -> float`：delta method 输出变换域方差。
- `robust_location_scale(values, fallback_scale) -> (center,scale,method)`：median/MAD，必要时 IQR/std/fallback。
- `PairedRobustNormalizer.fit(frame) -> self`：输入本折训练 x 表；保存 exact/subdir/global robust 统计和 expected x。
- `PairedRobustNormalizer.transform(frame) -> DataFrame`：输出附加 `*_quality`、within SD、SE 和 fallback 标记的 x 表。
- `PairedRobustNormalizer.statistics_frame() -> DataFrame`：输出每个 subdir/x/metric 的中心、尺度、方法和参考设备数。

## features.py

- `feature_columns(mode) -> list[str]`：`mean` 返回四个主质量特征，`stability` 再加四个稳定性特征。
- `aggregate_transformed_group(group, expected_x_count) -> dict`：输入一个 name/subdir 的变换后 x 行；输出等权聚合字段。
- `aggregate_name_subdir(transformed, expected_x) -> DataFrame`：整表聚合为 name/subdir 行。
- `reliability_warnings(row) -> str`：根据 n_x、coverage、fallback 生成报告告警。

## models.py

- `ModelSpec`：记录 family、feature mode、alpha、Huber delta；`label` 可作为稳定字符串 ID。
- `PositiveHuberRegressor.fit(X,y) -> self` / `predict(X)`：非负系数、L2 正则的 Huber 回归。
- `PositiveAffineCalibrator.fit(prediction,score) -> self` / `predict(prediction)`：非负 Theil-Sen 或 Ridge 线性校准。
- `make_model(spec) -> Pipeline`：输出 `SimpleImputer -> StandardScaler -> regressor`。
- `candidate_grid(...) -> list[ModelSpec]`：构造有限搜索网格。
- `model_coefficients(model, feature_names) -> list[dict]`：输出标准化和原单位系数。

## metrics.py

- `correlation_band(value) -> str`：输出描述性相关强度，不作自动部署判定。
- `ranking_metrics(scores, prediction, material_gap, near_tie_gap) -> dict`：输出误差、相关、设备对、概率、Top/Bottom 和容忍指标。
- `selection_score(metrics) -> float`：输出内层模型/K 选择综合分。

## validation.py

- `FoldFeatureCache.get(subdir, fit_devices) -> DataFrame`：只用 `fit_devices` 拟合 robust 统计，再转换所有目标设备；key 含训练设备集合。
- `eligible_devices(data, subdir, score_map) -> list[str]`：返回同时有指标和标签的设备。
- `fit_predict_one(features, train_devices, target_device, score_map, spec) -> (prediction,model)`：单折拟合/预测。
- `ValidationRunner.exact_spec_oof(...) -> DataFrame`：固定 spec 的严格 LOODO。
- `ValidationRunner.evaluate_exact_specs(...) -> DataFrame`：比较完整参数候选。
- `ValidationRunner.select_spec(...) -> (ModelSpec,comparison)`：在当前训练集合内部选择 spec。
- `ValidationRunner.nested_groups_oof(...) -> (predictions,metrics)`：外层评估、内层选择的核心入口。
- `candidate_groups(candidates) -> dict`：生成 Ridge/Huber、mean/stability 和 nested-auto 消融组。

## training.py

- `train_models(data, targets, config, families, min_devices, final_reference_scope) -> (bundle,outputs)`：完整比较和最终拟合。scope 可为 `all_reference` 或严格审计用的 `labelled_only`；`bundle` 可 joblib 保存，`outputs` 包含六张报告表。

## tuning.py

- `tune_k_grid(data, objective_scores, subjective, config, k_values, tolerance) -> (metrics,predictions,selected,global_summary)`：内部嵌套 K 搜索，不读取外部标签。

## prediction.py

- `predict_new_devices(data, bundle, n_bootstrap, seed) -> (rankings,pairwise)`：输出新设备 subdir 预测、区间、参考排名和逐参考胜率。

## evaluation.py

- `evaluate_prediction_table(predictions, targets, material_gap, near_tie_gap) -> (metrics,audit)`：输出外部 subdir 指标和逐设备 rank/material crossing 审计。

## filtering.py

- `audit_window_thresholds(windows, cos_threshold, l2_threshold, consensus_fraction) -> DataFrame`：输入真正单窗口表；输出旧规则和建议状态，不删除数据。

## persistence.py

- `save_bundle(bundle, model_path, metadata_path) -> None`：joblib 保存可执行对象，JSON 保存可读元数据。
- `load_bundle(path) -> dict`：加载可信本地 bundle；不要加载来源不明的 pickle/joblib。
