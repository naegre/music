# 设备音频质量排名：主观贡献、严格验证与 K 筛选

这是 2026-07-16 分析工作的独立、可上传项目。它从已经聚合到 `name + subdir + x` 的音频指标出发，为每个 subdir 单独学习设备排名；目标分数由客观分数和已经乘过 overall 权重的主观贡献共同构成。

本项目的首要目标是：高分设备稳定排在前列、低分设备稳定排在后列。`overall` 不参与默认训练，预测的绝对分数只是辅助校准值，`predicted_percentile`、排名及两分以上设备对的顺序才是主要输出。

## 核心决定

- 主特征仅使用 L2 与 cosine；KL/JS 波动大，默认完全排除。
- `l2` 越低越好；`cosim` 越高越好。先按同一 `subdir + x` 跨设备做 robust 标准化。
- 标签先转成排名百分位，避免 `edginess/小米6S Pro=169.803` 一类极值支配损失。
- 候选模型是非负 Ridge 和非负 Huber；以嵌套 Leave-One-Device-Out 选择。
- 同一 subdir 的不同 x 等权；音频更长、窗口更多不会直接获得更高质量权重。
- `n_windows_total`、`n_effective`、coverage、SE 只描述可靠性，不作为“质量越高越好”的输入。
- 默认主观方案为 `no_imaging`；缺失主观评分用 `null`，不会被误当成 15 分低分。
- `fullness x=0` 依照已确认的录音/内容问题排除；不是因为它天然满足某个通用统计阈值。

## 目录

```text
configs/       别名、三套主观贡献、K 和模型网格
data/raw/      本次使用的 data.txt、overall.json、new.json
data/processed 数据准备命令生成的可训练数据和审计表
src/           统计、模型、验证、训练、预测源码
cli/           每个步骤的独立命令入口
docs/          方法原理、函数输入输出、研究依据和过滤审查
models/        训练好的 joblib bundle
results/       训练、K 搜索、预测和外部审计结果
tests/         单元及合成端到端测试
main.py        统一命令入口
```

## 安装

Linux 服务器：

```bash
conda create -n audio_rank python=3.10 -y
conda activate audio_rank
python -m pip install -r requirements.txt
```

也可在项目根目录执行 `python -m pip install -e .`，之后仍可使用下面的 `main.py` 命令。

建议始终通过 `main.py predict` 加载模型。若在自定义 Python 脚本中直接 `joblib.load()`，必须先执行 `pip install -e .` 或把项目的 `src/` 加入 `PYTHONPATH`，否则 pickle 无法找到 `subjective_audio_quality` 类定义。只加载可信来源的 joblib 文件。

## 从头运行

1. 准备数据，并使用当前保守的分 subdir K：

```bash
python main.py prepare --use-recommended-k
```

2. 只用内部嵌套 LOODO 重新筛选 K：

```bash
python main.py tune-k
```

3. 比较 Ridge 与 Huber，但不保存部署模型：

```bash
python main.py evaluate
```

4. 完整训练并保存 `models/model_bundle.joblib`：

```bash
python main.py train
```

Linux 上也可一次运行 `bash run_training.sh`。严格 inductive 的 iPad 审计命令集中在 `run_inductive_audit.sh`。

5. 预测一个新设备表；它的列格式应与 `data/raw/data.txt` 相同：

```bash
python main.py predict --data /path/to/new_device_x_metrics.csv
```

6. 用更新后的标签做外部审计：

```bash
python main.py evaluate-predictions \
  --predictions results/predict/new_device_rankings.csv \
  --scores data/raw/new.json
```

`new.json` 应保留为外部审计，不能看完它的结果后继续调整 K，否则“外部测试”就退化成训练的一部分。

## 主要输出

- `data/processed/x_metrics_merged.csv`：产品级 x 数据，含明确的窗口与录音计数。
- `data/processed/targets.csv`：客观、主观贡献、K、调整后分数和目标百分位。
- `results/train/model_comparison.csv`：嵌套 OOF 模型比较与 exact candidate 搜索。
- `results/train/oof_predictions.csv`：每个设备完全不参与本折训练时的预测。
- `results/train/selected_models.csv`：最终模型及主要验证指标。
- `results/train/coefficients.csv`：特征系数，所有质量方向系数应非负。
- `models/model_bundle.joblib`：normalizer、imputer、scaler、模型和校准器。
- `results/predict/new_device_rankings.csv`：百分位、排名、置信区间和可靠性告警。
- `results/predict/new_vs_reference_probabilities.csv`：新设备优于每台已知设备的 bootstrap 概率。

## 阅读顺序

先看 [今日结论](docs/TODAY_SUMMARY.md)，再看 [数据处理](docs/DATA_PROCESSING.md)、[模型训练](docs/MODEL_TRAINING.md)、[评估指标](docs/MODEL_EVALUATION.md)、[预测评估](docs/PREDICTION.md) 和 [K 筛选](docs/K_TUNING.md)。所有函数的输入输出集中在 [函数参考](docs/FUNCTION_REFERENCE.md)。

## 重要限制

每个 subdir 目前只有约 10 到 12 个有效标签设备。任何单一 Spearman 数值都可能受一两台设备影响，因此必须同时看 material-pair accuracy、Top/Bottom-3、OOF 逐设备残差和未来新增设备的外部验证。这个数据规模不适合神经网络、随机森林或高维 stacking；它们更容易记住现有设备，而不是学到可迁移的质量规律。
