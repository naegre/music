#!/usr/bin/env python3
"""Compact positive-coefficient overall score and PC ranking pipeline.

This single file intentionally keeps only the official model families:

* robust, domain-balanced Ridge for numeric overall score;
* scaled, within-domain soft-pairwise logistic utility for PC ranking.

Every quality coefficient is fitted with a configurable strictly-positive
closed lower bound.  The official model and its frozen evidence are not
overwritten; this file writes only an experimental compact-positive bundle.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import joblib
import numpy as np
import pandas as pd
from scipy.optimize import lsq_linear, minimize
from scipy.special import expit
from scipy.stats import kendalltau, pearsonr, spearmanr


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROBABILITY_PER_POINT = 0.1
PROBABILITY_CLIP = 1e-6
SCORE_TOLERANCE = 0.5
RANK_TOLERANCE = 0.01
EQUIVALENCE_TOLERANCE = 1e-10
OFFICIAL_FROZEN_SPLIT_SHA256 = (
    "fca773df373ac8ac185ee302edb3804ddac1743a5525504a9e684b75af2efb37"
)

RAW_FEATURES = (
    "loudness",
    "dynamics_1_S",
    "dynamics_2",
    "timber_1",
    "timber_2",
    "treble_1",
    "treble_2",
    "edginess",
    "balance",
    "fullness",
    "clarity_1_S",
    "clarity_2",
    "clarity_3_S",
    "spatial_1",
    "spatial_2",
    "spatial_3_S",
    "spatial_4_S",
    "spatial_5_S",
    "spatial_6_S",
    "artefacts_1_S",
    "artefacts_2",
    "artefacts_3_S",
)

REPLACEMENTS = {
    "clarity": ("clarity_1_S", "clarity_2", "clarity_3_S"),
    "lowfreq": ("timber_1", "timber_2"),
    "fullness": ("fullness",),
    "edginess": ("edginess",),
}

FEATURES = (
    "loudness",
    "dynamics_1_S",
    "dynamics_2",
    "treble_1",
    "treble_2",
    "balance",
    "spatial_1",
    "spatial_2",
    "spatial_3_S",
    "spatial_4_S",
    "spatial_5_S",
    "spatial_6_S",
    "artefacts_1_S",
    "artefacts_2",
    "artefacts_3_S",
    "clarity__predicted_percentile",
    "lowfreq__predicted_percentile",
    "fullness__predicted_percentile",
    "edginess__predicted_percentile",
)

# Zero is diagnostic only. Final compact-positive selection excludes it.
DEFAULT_SCORE_ALPHAS = (1.0, 10.0, 100.0)
DEFAULT_SCORE_FLOORS = (0.0, 0.001, 0.005, 0.01)
DEFAULT_RANK_ALPHAS = (10.0, 100.0, 1000.0)
DEFAULT_RANK_FLOORS = (0.0, 0.0005, 0.001, 0.0025)


# ---------------------------------------------------------------------------
# Small IO, validation, and preparation helpers
# ---------------------------------------------------------------------------


def _read_csv(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8-sig")


def _write_csv(frame: pd.DataFrame, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(target, index=False, encoding="utf-8-sig")
    return target


def _write_json(payload: dict[str, Any], path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return target


def _sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _frame_sha256(frame: pd.DataFrame, columns: Iterable[str]) -> str:
    payload = frame[list(columns)].to_csv(
        index=False,
        lineterminator="\n",
        na_rep="<NA>",
        float_format="%.17g",
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _preparation_manifest_path(prepared_path: str | Path) -> Path:
    path = Path(prepared_path)
    return path.with_suffix(".manifest.json")


def _json_number(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_number(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_number(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        value = float(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _parse_grid(text: str, *, allow_zero: bool) -> tuple[float, ...]:
    values = tuple(float(token.strip()) for token in text.split(",") if token.strip())
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError("Parameter grids must contain finite numbers")
    if any(value < 0.0 or (not allow_zero and value == 0.0) for value in values):
        raise ValueError("Parameter grid contains an invalid negative/zero value")
    if len(set(values)) != len(values):
        raise ValueError("Parameter grids cannot contain duplicate values")
    return tuple(sorted(values))


def _validate_floor(value: float) -> float:
    floor = float(value)
    if not math.isfinite(floor) or floor < 0.0:
        raise ValueError("Coefficient floor must be finite and >= 0")
    return floor


def _numeric_frame(frame: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    result = frame.copy()
    for column in columns:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    values = result[list(columns)].to_numpy(dtype=float, na_value=np.nan)
    if np.isinf(values).any():
        raise ValueError("Input features cannot contain infinity")
    if np.isnan(values).all(axis=0).any():
        missing = [
            column
            for column, all_missing in zip(
                columns, np.isnan(values).all(axis=0), strict=True
            )
            if all_missing
        ]
        raise ValueError(f"Feature columns are entirely missing: {missing}")
    return result


def prepare_canonical_inputs(
    overall_path: str | Path,
    domains_path: str | Path,
    submodels_path: str | Path,
    output_path: str | Path,
) -> Path:
    """Collapse canonical 22-feature data to the official 19-feature matrix.

    This compact preparation starts from already canonical English columns.
    Historical Chinese-column mapping and broad source-row exclusion remain in
    the audited official ``prepare-real`` tool and are deliberately not copied.
    """

    overall = _read_csv(overall_path)
    domains = _read_csv(domains_path)
    predictions = _read_csv(submodels_path)

    required_overall = {"name", *RAW_FEATURES}
    missing = sorted(required_overall - set(overall.columns))
    if missing:
        raise ValueError(f"Canonical feature table is missing: {missing}")
    if not {"name", "domain"}.issubset(domains.columns):
        raise ValueError("Domain table must contain name,domain")
    required_predictions = {
        "name",
        "subdir",
        "predicted_percentile",
        "prediction_source",
    }
    missing = sorted(required_predictions - set(predictions.columns))
    if missing:
        raise ValueError(f"Submodel table is missing: {missing}")

    overall = overall.copy()
    domains = domains[["name", "domain"]].copy()
    predictions = predictions.copy()
    for frame in (overall, domains, predictions):
        frame["name"] = frame["name"].astype(str).str.strip()
    domains["domain"] = domains["domain"].astype(str).str.strip().str.lower()
    predictions["subdir"] = predictions["subdir"].astype(str).str.strip()
    predictions["prediction_source"] = (
        predictions["prediction_source"].astype(str).str.strip().str.lower()
    )

    if overall["name"].eq("").any() or overall["name"].duplicated().any():
        raise ValueError("Feature-table names must be non-empty and unique")
    if domains["name"].eq("").any() or domains["name"].duplicated().any():
        raise ValueError("Domain-table names must be non-empty and unique")
    invalid_domains = sorted(set(domains["domain"]) - {"tablet", "pc"})
    if invalid_domains:
        raise ValueError(f"Unsupported domains: {invalid_domains}")
    if set(overall["name"]) != set(domains["name"]):
        raise ValueError("Feature and domain tables must contain identical device names")

    overall = _numeric_frame(overall, RAW_FEATURES)
    if "overall" in overall:
        overall["overall"] = pd.to_numeric(overall["overall"], errors="coerce")
        if not np.isfinite(overall["overall"].to_numpy(dtype=float)).all():
            raise ValueError("overall must be finite when supplied")
        if not overall["overall"].between(0.0, 100.0).all():
            raise ValueError("overall must lie in [0,100]")

    selected = predictions[predictions["subdir"].isin(REPLACEMENTS)].copy()
    selected["predicted_percentile"] = pd.to_numeric(
        selected["predicted_percentile"], errors="coerce"
    )
    if not np.isfinite(selected["predicted_percentile"].to_numpy(dtype=float)).all():
        raise ValueError("predicted_percentile must be finite")
    if not selected["predicted_percentile"].between(0.0, 100.0).all():
        raise ValueError("predicted_percentile must lie in [0,100]")
    if selected[["name", "subdir"]].duplicated().any():
        raise ValueError("Submodel table requires one row per name + subdir")

    expected_pairs = {
        (name, subdir) for name in overall["name"] for subdir in REPLACEMENTS
    }
    actual_pairs = set(selected[["name", "subdir"]].itertuples(index=False, name=None))
    if actual_pairs != expected_pairs:
        missing_pairs = sorted(expected_pairs - actual_pairs)[:10]
        extra_pairs = sorted(actual_pairs - expected_pairs)[:10]
        raise ValueError(
            f"Submodel coverage mismatch; missing={missing_pairs}, extra={extra_pairs}"
        )

    domain_lookup = domains.set_index("name")["domain"].to_dict()
    has_training_target = "overall" in overall.columns
    source_errors: list[str] = []
    for row in selected[["name", "subdir", "prediction_source"]].itertuples(index=False):
        domain = domain_lookup[row.name]
        if domain == "pc":
            allowed = {"inductive"}
        elif has_training_target and row.name != "ipadPro2022-":
            allowed = {"oof"}
        else:
            allowed = {"oof", "inductive"}
        if row.prediction_source not in allowed:
            source_errors.append(
                f"{row.name}/{row.subdir}={row.prediction_source!r}, allowed={sorted(allowed)}"
            )
    if source_errors:
        raise ValueError("Unsafe prediction sources: " + "; ".join(source_errors[:10]))

    wide = selected.pivot(
        index="name", columns="subdir", values="predicted_percentile"
    ).rename(columns={key: f"{key}__predicted_percentile" for key in REPLACEMENTS})
    removed = {column for columns in REPLACEMENTS.values() for column in columns}
    retained = [column for column in RAW_FEATURES if column not in removed]
    prepared = overall[["name", *retained, *( ["overall"] if "overall" in overall else [])]].copy()
    prepared = prepared.merge(wide.reset_index(), on="name", validate="one_to_one")
    prepared = prepared.merge(domains, on="name", validate="one_to_one")
    ordered = ["name", "domain", *FEATURES]
    if "overall" in prepared:
        ordered.append("overall")
    prepared = prepared[ordered]
    written = _write_csv(prepared, output_path)
    source_audit = selected.merge(domains, on="name", validate="many_to_one")
    manifest = {
        "schema_version": 1,
        "kind": "compact_positive_preparation_manifest",
        "source_policy_validated": True,
        "prepared_path": str(written.resolve()),
        "prepared_sha256": _sha256(written),
        "input_hashes": {
            "overall_sha256": _sha256(overall_path),
            "domains_sha256": _sha256(domains_path),
            "submodels_sha256": _sha256(submodels_path),
        },
        "prediction_source_counts": [
            {
                "domain": str(domain),
                "prediction_source": str(source),
                "n_rows": int(len(group)),
            }
            for (domain, source), group in source_audit.groupby(
                ["domain", "prediction_source"], sort=True
            )
        ],
        "n_devices": int(len(prepared)),
        "features": list(FEATURES),
        "treble_policy": "retain canonical treble_1 and treble_2 without replacement",
    }
    _write_json(_json_number(manifest), _preparation_manifest_path(written))
    return written


def load_prepared(path: str | Path, *, require_target: bool) -> pd.DataFrame:
    frame = _read_csv(path)
    required = {"name", "domain", *FEATURES}
    if require_target:
        required.add("overall")
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Prepared table is missing: {missing}")
    frame = frame.copy()
    frame["name"] = frame["name"].astype(str).str.strip()
    frame["domain"] = frame["domain"].astype(str).str.strip().str.lower()
    if frame["name"].eq("").any() or frame["name"].duplicated().any():
        raise ValueError("Prepared names must be non-empty and unique")
    invalid = sorted(set(frame["domain"]) - {"tablet", "pc"})
    if invalid:
        raise ValueError(f"Unsupported domains: {invalid}")
    frame = _numeric_frame(frame, FEATURES)
    if "overall" in frame:
        frame["overall"] = pd.to_numeric(frame["overall"], errors="coerce")
        if not np.isfinite(frame["overall"].to_numpy(dtype=float)).all():
            raise ValueError("overall must be finite")
        if not frame["overall"].between(0.0, 100.0).all():
            raise ValueError("overall must lie in [0,100]")
    return frame


def load_split(path: str | Path, frame: pd.DataFrame) -> dict[str, list[str]]:
    actual_hash = _sha256(path)
    if actual_hash != OFFICIAL_FROZEN_SPLIT_SHA256:
        raise ValueError(
            "The compact real run requires the exact official frozen split; "
            f"expected SHA256={OFFICIAL_FROZEN_SPLIT_SHA256}, got={actual_hash}"
        )
    split = json.loads(Path(path).read_text(encoding="utf-8"))
    required = {"tablet_development", "pc_development", "pc_external"}
    if not required.issubset(split):
        raise ValueError(f"Split must contain {sorted(required)}")
    groups = {key: [str(name) for name in split[key]] for key in required}
    if len(groups["tablet_development"]) != 17:
        raise ValueError("Compact real run requires 17 development tablets")
    if len(groups["pc_development"]) != 5 or len(groups["pc_external"]) != 7:
        raise ValueError("Compact real run requires the frozen 5/7 PC split")
    all_names = sum(groups.values(), [])
    if len(all_names) != len(set(all_names)):
        raise ValueError("Frozen split groups must be disjoint")
    if set(all_names) != set(frame["name"]):
        raise ValueError("Frozen split must cover every prepared device exactly once")
    domain_lookup = frame.set_index("name")["domain"].to_dict()
    if any(domain_lookup[name] != "tablet" for name in groups["tablet_development"]):
        raise ValueError("tablet_development contains a non-tablet")
    pc_names = groups["pc_development"] + groups["pc_external"]
    if any(domain_lookup[name] != "pc" for name in pc_names):
        raise ValueError("PC split contains a non-PC")
    return groups


def subset(frame: pd.DataFrame, names: list[str]) -> pd.DataFrame:
    indexed = frame.set_index("name", drop=False)
    missing = sorted(set(names) - set(indexed.index.astype(str)))
    if missing:
        raise ValueError(f"Unknown devices requested: {missing}")
    return indexed.loc[names].reset_index(drop=True)


# ---------------------------------------------------------------------------
# Fold-local transforms and metrics
# ---------------------------------------------------------------------------


def robust_location_scale(values: np.ndarray, epsilon: float = 1e-9) -> tuple[float, float, str]:
    array = np.asarray(values, dtype=float)
    center = float(np.median(array))
    mad = float(1.4826 * np.median(np.abs(array - center)))
    if mad > epsilon:
        return center, mad, "mad"
    q25, q75 = np.quantile(array, [0.25, 0.75])
    iqr = float((q75 - q25) / 1.349)
    if iqr > epsilon:
        return center, iqr, "iqr"
    std = float(np.std(array, ddof=1)) if len(array) > 1 else 0.0
    if std > epsilon:
        return center, std, "std"
    return center, 1.0, "unit"


def fit_imputer(frame: pd.DataFrame) -> np.ndarray:
    values = frame[list(FEATURES)].to_numpy(dtype=float, na_value=np.nan)
    all_missing = np.isnan(values).all(axis=0)
    if np.any(all_missing):
        columns = [
            column
            for column, missing in zip(FEATURES, all_missing, strict=True)
            if missing
        ]
        raise ValueError(f"Training-fold features are entirely missing: {columns}")
    return np.asarray(
        [np.nanmedian(values[:, index]) for index in range(values.shape[1])],
        dtype=float,
    )


def apply_imputer(frame: pd.DataFrame, impute: np.ndarray) -> np.ndarray:
    values = frame[list(FEATURES)].to_numpy(dtype=float, na_value=np.nan)
    return np.where(np.isnan(values), impute, values)


def domain_weights(domains: pd.Series | np.ndarray) -> np.ndarray:
    values = np.asarray(domains).astype(str)
    unique = sorted(set(values))
    weights = np.zeros(len(values), dtype=float)
    for domain in unique:
        mask = values == domain
        weights[mask] = 1.0 / (len(unique) * int(mask.sum()))
    return weights * len(values)


def preference_probability(difference: np.ndarray | float) -> np.ndarray:
    return np.clip(0.5 + PROBABILITY_PER_POINT * np.asarray(difference), 0.0, 1.0)


def _safe_correlation(function, left: np.ndarray, right: np.ndarray) -> float:
    left = np.asarray(left, dtype=float)
    right = np.asarray(right, dtype=float)
    if len(left) < 2 or np.ptp(left) == 0 or np.ptp(right) == 0:
        return float("nan")
    return float(function(left, right).statistic)


def regression_metrics(actual: np.ndarray, predicted: np.ndarray) -> dict[str, Any]:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    residual = predicted - actual
    return {
        "n": int(len(actual)),
        "mae": float(np.mean(np.abs(residual))),
        "rmse": float(np.sqrt(np.mean(residual**2))),
        "bias": float(np.mean(residual)),
        "max_abs_error": float(np.max(np.abs(residual))),
        "pearson": _safe_correlation(pearsonr, actual, predicted),
        "spearman": _safe_correlation(spearmanr, actual, predicted),
        "kendall_tau": _safe_correlation(kendalltau, actual, predicted),
    }


def soft_pair_metrics(targets: np.ndarray, probabilities: np.ndarray) -> dict[str, Any]:
    targets = np.asarray(targets, dtype=float)
    probabilities = np.clip(
        np.asarray(probabilities, dtype=float),
        PROBABILITY_CLIP,
        1.0 - PROBABILITY_CLIP,
    )
    non_ties = targets != 0.5
    accuracy = (
        float(
            np.mean(
                (probabilities[non_ties] > 0.5) == (targets[non_ties] > 0.5)
            )
        )
        if non_ties.any()
        else float("nan")
    )
    return {
        "n_pairs": int(len(targets)),
        "pairwise_accuracy": accuracy,
        "pairwise_brier": float(np.mean((probabilities - targets) ** 2)),
        "pairwise_log_loss": float(
            np.mean(
                -targets * np.log(probabilities)
                - (1.0 - targets) * np.log(1.0 - probabilities)
            )
        ),
    }


def device_rank_metrics(actual: np.ndarray, signal: np.ndarray) -> dict[str, Any]:
    actual = np.asarray(actual, dtype=float)
    signal = np.asarray(signal, dtype=float)
    correct: list[bool] = []
    for left in range(len(actual) - 1):
        for right in range(left + 1, len(actual)):
            if actual[left] == actual[right]:
                continue
            correct.append(
                (signal[left] > signal[right]) == (actual[left] > actual[right])
            )
    return {
        "n_devices": int(len(actual)),
        "spearman": _safe_correlation(spearmanr, actual, signal),
        "kendall_tau": _safe_correlation(kendalltau, actual, signal),
        "device_pair_accuracy": float(np.mean(correct)) if correct else float("nan"),
    }


# ---------------------------------------------------------------------------
# Compact score model: robust transform + bounded domain-balanced Ridge
# ---------------------------------------------------------------------------


def fit_score_model(
    frame: pd.DataFrame,
    *,
    alpha: float,
    coefficient_floor: float,
) -> dict[str, Any]:
    alpha = float(alpha)
    floor = _validate_floor(coefficient_floor)
    if not math.isfinite(alpha) or alpha < 0.0:
        raise ValueError("Score alpha must be finite and >= 0")

    impute = fit_imputer(frame)
    values = apply_imputer(frame, impute)
    centers: list[float] = []
    scales: list[float] = []
    scale_methods: list[str] = []
    for index in range(values.shape[1]):
        center, scale, method = robust_location_scale(values[:, index])
        centers.append(center)
        scales.append(scale)
        scale_methods.append(method)
    center_array = np.asarray(centers, dtype=float)
    scale_array = np.asarray(scales, dtype=float)
    z = (values - center_array) / scale_array

    domains = frame["domain"].astype(str).to_numpy()
    target = frame["overall"].to_numpy(dtype=float)
    is_pc = (domains == "pc").astype(float)
    design = np.column_stack([z, is_pc, np.ones(len(frame))])
    weights = domain_weights(domains)
    weighted_design = design * np.sqrt(weights)[:, None]
    weighted_target = target * np.sqrt(weights)

    penalty = np.sqrt(alpha) * np.eye(design.shape[1])
    penalty[-1, -1] = 0.0  # Intercept is deliberately not regularized.
    augmented_x = np.vstack([weighted_design, penalty])
    augmented_y = np.concatenate([weighted_target, np.zeros(design.shape[1])])

    lower = np.full(design.shape[1], -np.inf)
    lower[: len(FEATURES)] = floor
    upper = np.full(design.shape[1], np.inf)
    result = lsq_linear(augmented_x, augmented_y, bounds=(lower, upper))
    if not result.success:
        raise RuntimeError(f"Score optimization failed: {result.message}")
    parameters = np.asarray(result.x, dtype=float)
    coefficients = parameters[: len(FEATURES)]
    if np.any(coefficients < floor - 1e-10):
        raise RuntimeError("Score optimizer violated the configured coefficient floor")

    return {
        "kind": "compact_positive_score_v1",
        "features": list(FEATURES),
        "impute": impute,
        "center": center_array,
        "scale": scale_array,
        "scale_methods": scale_methods,
        "coef": coefficients,
        "coefficient_floor": floor,
        "pc_offset": float(parameters[len(FEATURES)]),
        "intercept": float(parameters[len(FEATURES) + 1]),
        "alpha": alpha,
        "optimization_success": True,
        "optimization_message": str(result.message),
    }


def score_transform(model: dict[str, Any], frame: pd.DataFrame) -> np.ndarray:
    values = apply_imputer(frame, np.asarray(model["impute"], dtype=float))
    return (
        values - np.asarray(model["center"], dtype=float)
    ) / np.asarray(model["scale"], dtype=float)


def predict_score(
    model: dict[str, Any], frame: pd.DataFrame, *, clip: bool = True
) -> np.ndarray:
    z = score_transform(model, frame)
    is_pc = frame["domain"].astype(str).eq("pc").to_numpy(dtype=float)
    prediction = (
        z @ np.asarray(model["coef"], dtype=float)
        + float(model["pc_offset"]) * is_pc
        + float(model["intercept"])
    )
    return np.clip(prediction, 0.0, 100.0) if clip else prediction


def score_coefficient_frame(
    model: dict[str, Any], *, stage: str, outer_heldout: str = ""
) -> pd.DataFrame:
    coefficients = np.asarray(model["coef"], dtype=float)
    floor = float(model["coefficient_floor"])
    original = coefficients / np.asarray(model["scale"], dtype=float)
    tolerance = max(1e-10, floor * 1e-6)
    return pd.DataFrame(
        {
            "model": "score",
            "stage": stage,
            "outer_heldout": outer_heldout,
            "feature": FEATURES,
            "coefficient_model_scale": coefficients,
            "coefficient_original_units": original,
            "configured_min_coefficient": floor,
            "distance_from_floor": coefficients - floor,
            "at_lower_bound": np.isclose(coefficients, floor, atol=tolerance, rtol=0.0),
            "alpha": float(model["alpha"]),
            "optimizer_success": bool(model["optimization_success"]),
        }
    )


# ---------------------------------------------------------------------------
# Compact rank model: official scaled transform + bounded soft pairwise loss
# ---------------------------------------------------------------------------


def fit_rank_scaler(frame: pd.DataFrame) -> dict[str, Any]:
    impute = fit_imputer(frame)
    values = apply_imputer(frame, impute)
    _, target_scale, target_method = robust_location_scale(
        frame["overall"].to_numpy(dtype=float)
    )
    centers: list[float] = []
    multipliers: list[float] = []
    methods: list[str] = []
    for index, feature in enumerate(FEATURES):
        center, feature_scale, method = robust_location_scale(values[:, index])
        centers.append(center)
        methods.append(method)
        multipliers.append(
            1.0 if feature.endswith("_S") else target_scale / feature_scale
        )
    return {
        "impute": impute,
        "center": np.asarray(centers, dtype=float),
        "multiplier": np.asarray(multipliers, dtype=float),
        "scale_methods": methods,
        "target_scale": float(target_scale),
        "target_scale_method": target_method,
    }


def rank_transform(model: dict[str, Any], frame: pd.DataFrame) -> np.ndarray:
    values = apply_imputer(frame, np.asarray(model["impute"], dtype=float))
    return (
        values - np.asarray(model["center"], dtype=float)
    ) * np.asarray(model["multiplier"], dtype=float)


def make_pairs(z: np.ndarray, frame: pd.DataFrame) -> dict[str, np.ndarray]:
    z = np.asarray(z, dtype=float)
    target = frame["overall"].to_numpy(dtype=float)
    names = frame["name"].astype(str).to_numpy()
    domains = frame["domain"].astype(str).to_numpy()
    differences: list[np.ndarray] = []
    targets: list[float] = []
    left_names: list[str] = []
    right_names: list[str] = []
    pair_domains: list[str] = []
    for domain in sorted(set(domains)):
        indices = np.flatnonzero(domains == domain)
        for left_position, left in enumerate(indices[:-1]):
            for right in indices[left_position + 1 :]:
                differences.append(z[left] - z[right])
                targets.append(float(preference_probability(target[left] - target[right])))
                left_names.append(names[left])
                right_names.append(names[right])
                pair_domains.append(domain)
    if not differences:
        raise ValueError("Ranking requires at least two devices in one domain")
    domain_array = np.asarray(pair_domains, dtype=str)
    weights = np.zeros(len(domain_array), dtype=float)
    unique_domains = sorted(set(domain_array))
    for domain in unique_domains:
        mask = domain_array == domain
        weights[mask] = 1.0 / (len(unique_domains) * int(mask.sum()))
    weights *= len(weights)
    return {
        "differences": np.vstack(differences),
        "targets": np.asarray(targets, dtype=float),
        "weights": weights,
        "left_names": np.asarray(left_names, dtype=str),
        "right_names": np.asarray(right_names, dtype=str),
        "domains": domain_array,
    }


def fit_rank_model(
    frame: pd.DataFrame,
    *,
    alpha: float,
    coefficient_floor: float,
) -> dict[str, Any]:
    alpha = float(alpha)
    floor = _validate_floor(coefficient_floor)
    if not math.isfinite(alpha) or alpha < 0.0:
        raise ValueError("Rank alpha must be finite and >= 0")

    scaler = fit_rank_scaler(frame)
    z = rank_transform(scaler, frame)
    pairs = make_pairs(z, frame)
    differences = pairs["differences"]
    targets = pairs["targets"]
    weights = pairs["weights"]

    def objective(coefficients: np.ndarray) -> tuple[float, np.ndarray]:
        logits = differences @ coefficients
        probabilities = np.clip(
            expit(logits), PROBABILITY_CLIP, 1.0 - PROBABILITY_CLIP
        )
        cross_entropy = -targets * np.log(probabilities) - (
            1.0 - targets
        ) * np.log(1.0 - probabilities)
        value = float(
            np.dot(weights, cross_entropy)
            + 0.5 * alpha * np.dot(coefficients, coefficients)
        )
        gradient = differences.T @ (weights * (probabilities - targets))
        gradient += alpha * coefficients
        return value, gradient

    initial = np.full(len(FEATURES), max(0.01, floor), dtype=float)
    result = minimize(
        objective,
        initial,
        method="L-BFGS-B",
        jac=True,
        bounds=[(floor, None)] * len(FEATURES),
        options={"maxiter": 5000, "ftol": 1e-12},
    )
    if not result.success:
        raise RuntimeError(f"Rank optimization failed: {result.message}")
    coefficients = np.asarray(result.x, dtype=float)
    if np.any(coefficients < floor - 1e-10):
        raise RuntimeError("Rank optimizer violated the configured coefficient floor")

    return {
        "kind": "compact_positive_rank_v1",
        "features": list(FEATURES),
        **scaler,
        "coef": coefficients,
        "coefficient_floor": floor,
        "alpha": alpha,
        "optimization_success": True,
        "optimization_message": str(result.message),
        "training_pair_counts": {
            domain: int(np.sum(pairs["domains"] == domain))
            for domain in sorted(set(pairs["domains"]))
        },
    }


def rank_utility(model: dict[str, Any], frame: pd.DataFrame) -> np.ndarray:
    return rank_transform(model, frame) @ np.asarray(model["coef"], dtype=float)


def rank_coefficient_frame(
    model: dict[str, Any], *, stage: str, outer_heldout: str = ""
) -> pd.DataFrame:
    coefficients = np.asarray(model["coef"], dtype=float)
    floor = float(model["coefficient_floor"])
    original = coefficients * np.asarray(model["multiplier"], dtype=float)
    tolerance = max(1e-10, floor * 1e-6)
    return pd.DataFrame(
        {
            "model": "rank",
            "stage": stage,
            "outer_heldout": outer_heldout,
            "feature": FEATURES,
            "coefficient_model_scale": coefficients,
            "coefficient_original_units": original,
            "configured_min_coefficient": floor,
            "distance_from_floor": coefficients - floor,
            "at_lower_bound": np.isclose(coefficients, floor, atol=tolerance, rtol=0.0),
            "alpha": float(model["alpha"]),
            "optimizer_success": bool(model["optimization_success"]),
        }
    )


def rank_summary(names: Iterable[str], utilities: np.ndarray) -> pd.DataFrame:
    names_array = np.asarray(list(names)).astype(str)
    utilities = np.asarray(utilities, dtype=float)
    n_devices = len(utilities)
    ranks = pd.Series(-utilities).rank(method="min").to_numpy(dtype=int)
    if n_devices == 1:
        percentiles = np.asarray([50.0])
        win_percent = np.asarray([50.0])
    else:
        percentiles = 100.0 * (n_devices - ranks) / (n_devices - 1)
        probabilities = expit(utilities[:, None] - utilities[None, :])
        win_percent = 100.0 * (
            (probabilities.sum(axis=1) - 0.5) / (n_devices - 1)
        )
    return pd.DataFrame(
        {
            "name": names_array,
            "estimated_rank_1_is_best": ranks,
            "rank_percentile": percentiles,
            "expected_pairwise_win_percent": win_percent,
            "rank_utility": utilities,
        }
    ).sort_values(["estimated_rank_1_is_best", "name"])


# ---------------------------------------------------------------------------
# Candidate comparison and nested 5-PC leave-one-out validation
# ---------------------------------------------------------------------------


def _number_token(value: float) -> str:
    return f"{float(value):g}".replace(".", "p").replace("-", "m")


def candidate_spec(model: str, alpha: float, floor: float) -> dict[str, Any]:
    if model not in {"score", "rank"}:
        raise ValueError(f"Unknown model family: {model}")
    return {
        "model": model,
        "alpha": float(alpha),
        "coefficient_floor": _validate_floor(floor),
        "spec": (
            f"{model}_alpha{_number_token(alpha)}"
            f"_floor{_number_token(floor)}"
        ),
    }


def candidate_grid(
    model: str, alphas: Iterable[float], floors: Iterable[float]
) -> list[dict[str, Any]]:
    return [
        candidate_spec(model, alpha, floor)
        for floor in floors
        for alpha in alphas
    ]


def evaluate_score_spec_loo(
    frame: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    spec: dict[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for heldout in pc_names:
        training_names = tablet_names + [name for name in pc_names if name != heldout]
        training = subset(frame, training_names)
        test = subset(frame, [heldout])
        model = fit_score_model(
            training,
            alpha=float(spec["alpha"]),
            coefficient_floor=float(spec["coefficient_floor"]),
        )
        prediction = float(predict_score(model, test)[0])
        actual = float(test["overall"].iloc[0])
        rows.append(
            {
                "name": heldout,
                "actual_overall": actual,
                "predicted_overall": prediction,
                "residual": prediction - actual,
                "selected_spec": spec["spec"],
            }
        )
    return pd.DataFrame(rows)


def compare_score_candidates(
    frame: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    summaries: list[dict[str, Any]] = []
    predictions: list[pd.DataFrame] = []
    for spec in candidates:
        fold = evaluate_score_spec_loo(frame, tablet_names, pc_names, spec)
        summaries.append(
            {
                **spec,
                **regression_metrics(
                    fold["actual_overall"], fold["predicted_overall"]
                ),
            }
        )
        predictions.append(fold.assign(candidate_spec=spec["spec"]))
    comparison = pd.DataFrame(summaries).sort_values(
        ["mae", "rmse", "coefficient_floor", "alpha"], ignore_index=True
    )
    return comparison, pd.concat(predictions, ignore_index=True)


def _select_positive_candidate(
    comparison: pd.DataFrame, *, metric: str, tolerance: float
) -> dict[str, Any]:
    positive = comparison[comparison["coefficient_floor"].gt(0.0)].copy()
    if positive.empty:
        raise ValueError("At least one strictly positive coefficient floor is required")
    best = float(positive[metric].min())
    positive["selection_eligible"] = positive[metric].le(best + float(tolerance))
    eligible = positive[positive["selection_eligible"]].sort_values(
        ["coefficient_floor", "alpha", metric],
        ascending=[True, False, True],
    )
    selected = eligible.iloc[0]
    return {
        "model": str(selected["model"]),
        "spec": str(selected["spec"]),
        "alpha": float(selected["alpha"]),
        "coefficient_floor": float(selected["coefficient_floor"]),
        "selection_metric": metric,
        "selection_metric_value": float(selected[metric]),
        "best_positive_metric": best,
        "near_best_tolerance": float(tolerance),
        "selection_rule": (
            "positive-only; within best+tolerance; then smallest floor, "
            "strongest alpha, metric"
        ),
    }


def _mark_selection(
    comparison: pd.DataFrame,
    selected: dict[str, Any],
    *,
    metric: str,
    tolerance: float,
) -> pd.DataFrame:
    result = comparison.copy()
    positive_best = float(
        result.loc[result["coefficient_floor"].gt(0.0), metric].min()
    )
    result["diagnostic_zero_floor"] = result["coefficient_floor"].eq(0.0)
    result["selection_eligible"] = result["coefficient_floor"].gt(0.0) & result[
        metric
    ].le(positive_best + float(tolerance))
    result["selected_final"] = result["spec"].eq(selected["spec"])
    return result


def nested_score_validation(
    frame: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
    tolerance: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    outer_rows: list[dict[str, Any]] = []
    selection_rows: list[dict[str, Any]] = []
    coefficient_rows: list[pd.DataFrame] = []
    for outer_heldout in pc_names:
        inner_pcs = [name for name in pc_names if name != outer_heldout]
        comparison, _ = compare_score_candidates(
            frame, tablet_names, inner_pcs, candidates
        )
        selected = _select_positive_candidate(
            comparison, metric="mae", tolerance=tolerance
        )
        training = subset(frame, tablet_names + inner_pcs)
        test = subset(frame, [outer_heldout])
        model = fit_score_model(
            training,
            alpha=selected["alpha"],
            coefficient_floor=selected["coefficient_floor"],
        )
        prediction = float(predict_score(model, test)[0])
        actual = float(test["overall"].iloc[0])
        outer_rows.append(
            {
                "name": outer_heldout,
                "actual_overall": actual,
                "predicted_overall": prediction,
                "residual": prediction - actual,
                "selected_spec": selected["spec"],
            }
        )
        selection_rows.append(
            {
                "outer_heldout": outer_heldout,
                "selected_spec": selected["spec"],
                "selected_alpha": selected["alpha"],
                "selected_coefficient_floor": selected["coefficient_floor"],
                "inner_mae": selected["selection_metric_value"],
                "inner_best_positive_mae": selected["best_positive_metric"],
            }
        )
        coefficient_rows.append(
            score_coefficient_frame(
                model, stage="nested_outer", outer_heldout=outer_heldout
            )
        )
    return (
        pd.DataFrame(outer_rows),
        pd.DataFrame(selection_rows),
        pd.concat(coefficient_rows, ignore_index=True),
    )


def _rank_fold_predictions(
    frame: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    spec: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    pair_rows: list[dict[str, Any]] = []
    device_rows: list[dict[str, Any]] = []
    for heldout_name in pc_names:
        peer_names = [name for name in pc_names if name != heldout_name]
        training = subset(frame, tablet_names + peer_names)
        heldout = subset(frame, [heldout_name])
        peers = subset(frame, peer_names)
        model = fit_rank_model(
            training,
            alpha=float(spec["alpha"]),
            coefficient_floor=float(spec["coefficient_floor"]),
        )
        heldout_utility = float(rank_utility(model, heldout)[0])
        peer_utilities = rank_utility(model, peers)
        probabilities = expit(heldout_utility - peer_utilities)
        heldout_score = float(heldout["overall"].iloc[0])
        targets = preference_probability(
            heldout_score - peers["overall"].to_numpy(dtype=float)
        )
        for index, peer_name in enumerate(peer_names):
            pair_rows.append(
                {
                    "heldout_name": heldout_name,
                    "peer_name": peer_name,
                    "heldout_overall": heldout_score,
                    "peer_overall": float(peers["overall"].iloc[index]),
                    "target_probability_heldout_better": float(targets[index]),
                    "predicted_probability_heldout_better": float(
                        probabilities[index]
                    ),
                    "selected_spec": spec["spec"],
                }
            )
        device_rows.append(
            {
                "name": heldout_name,
                "actual_overall": heldout_score,
                "oof_expected_win_percent": float(100.0 * np.mean(probabilities)),
                "selected_spec": spec["spec"],
            }
        )
    return pd.DataFrame(pair_rows), pd.DataFrame(device_rows)


def compare_rank_candidates(
    frame: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    summaries: list[dict[str, Any]] = []
    pair_outputs: list[pd.DataFrame] = []
    device_outputs: list[pd.DataFrame] = []
    for spec in candidates:
        pairs, devices = _rank_fold_predictions(
            frame, tablet_names, pc_names, spec
        )
        summaries.append(
            {
                **spec,
                **soft_pair_metrics(
                    pairs["target_probability_heldout_better"],
                    pairs["predicted_probability_heldout_better"],
                ),
                **device_rank_metrics(
                    devices["actual_overall"], devices["oof_expected_win_percent"]
                ),
            }
        )
        pair_outputs.append(pairs.assign(candidate_spec=spec["spec"]))
        device_outputs.append(devices.assign(candidate_spec=spec["spec"]))
    comparison = pd.DataFrame(summaries).sort_values(
        ["pairwise_log_loss", "pairwise_brier", "coefficient_floor", "alpha"],
        ignore_index=True,
    )
    return (
        comparison,
        pd.concat(pair_outputs, ignore_index=True),
        pd.concat(device_outputs, ignore_index=True),
    )


def nested_rank_validation(
    frame: pd.DataFrame,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
    tolerance: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    outer_pairs: list[pd.DataFrame] = []
    outer_devices: list[dict[str, Any]] = []
    selections: list[dict[str, Any]] = []
    coefficient_rows: list[pd.DataFrame] = []
    for outer_heldout in pc_names:
        inner_pcs = [name for name in pc_names if name != outer_heldout]
        comparison, _, _ = compare_rank_candidates(
            frame, tablet_names, inner_pcs, candidates
        )
        selected = _select_positive_candidate(
            comparison, metric="pairwise_log_loss", tolerance=tolerance
        )
        spec = candidate_spec(
            "rank", selected["alpha"], selected["coefficient_floor"]
        )
        training = subset(frame, tablet_names + inner_pcs)
        heldout = subset(frame, [outer_heldout])
        peers = subset(frame, inner_pcs)
        model = fit_rank_model(
            training,
            alpha=selected["alpha"],
            coefficient_floor=selected["coefficient_floor"],
        )
        heldout_utility = float(rank_utility(model, heldout)[0])
        peer_utilities = rank_utility(model, peers)
        probabilities = expit(heldout_utility - peer_utilities)
        heldout_score = float(heldout["overall"].iloc[0])
        targets = preference_probability(
            heldout_score - peers["overall"].to_numpy(dtype=float)
        )
        fold_rows: list[dict[str, Any]] = []
        for index, peer_name in enumerate(inner_pcs):
            fold_rows.append(
                {
                    "heldout_name": outer_heldout,
                    "peer_name": peer_name,
                    "heldout_overall": heldout_score,
                    "peer_overall": float(peers["overall"].iloc[index]),
                    "target_probability_heldout_better": float(targets[index]),
                    "predicted_probability_heldout_better": float(
                        probabilities[index]
                    ),
                    "selected_spec": selected["spec"],
                }
            )
        outer_pairs.append(pd.DataFrame(fold_rows))
        outer_devices.append(
            {
                "name": outer_heldout,
                "actual_overall": heldout_score,
                "oof_expected_win_percent": float(100.0 * np.mean(probabilities)),
                "selected_spec": selected["spec"],
            }
        )
        selections.append(
            {
                "outer_heldout": outer_heldout,
                "selected_spec": selected["spec"],
                "selected_alpha": selected["alpha"],
                "selected_coefficient_floor": selected["coefficient_floor"],
                "inner_pairwise_log_loss": selected["selection_metric_value"],
                "inner_best_positive_pairwise_log_loss": selected[
                    "best_positive_metric"
                ],
            }
        )
        coefficient_rows.append(
            rank_coefficient_frame(
                model, stage="nested_outer", outer_heldout=outer_heldout
            )
        )
    return (
        pd.concat(outer_pairs, ignore_index=True),
        pd.DataFrame(outer_devices),
        pd.DataFrame(selections),
        pd.concat(coefficient_rows, ignore_index=True),
    )


# ---------------------------------------------------------------------------
# Lock, baseline-equivalence audit, external description, and prediction
# ---------------------------------------------------------------------------


def _frame_to_state(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "name": frame["name"].astype(str).tolist(),
        "domain": frame["domain"].astype(str).tolist(),
        "features": frame[list(FEATURES)].to_numpy(dtype=float, na_value=np.nan),
    }


def _frame_from_state(state: dict[str, Any]) -> pd.DataFrame:
    result = pd.DataFrame(np.asarray(state["features"], dtype=float), columns=FEATURES)
    result.insert(0, "domain", list(state["domain"]))
    result.insert(0, "name", list(state["name"]))
    return result


def baseline_equivalence_audit(
    development: pd.DataFrame,
    external: pd.DataFrame,
    official_results_dir: str | Path,
) -> dict[str, Any]:
    """Show that floor=0 compact models reproduce the two official families."""

    official = Path(official_results_dir)
    required = {
        "score_coefficients": official / "score_coefficients.csv",
        "rank_coefficients": official / "rank_coefficients.csv",
        "external_predictions": official / "external_pc_predictions.csv",
    }
    if not all(path.exists() for path in required.values()):
        return {
            "status": "skipped",
            "reason": "official comparison files were not all present",
            "required_paths": {key: str(path) for key, path in required.items()},
        }

    score = fit_score_model(development, alpha=10.0, coefficient_floor=0.0)
    rank = fit_rank_model(development, alpha=100.0, coefficient_floor=0.0)
    official_score = _read_csv(required["score_coefficients"]).set_index("feature")
    official_rank = _read_csv(required["rank_coefficients"]).set_index("feature")
    score_frame = score_coefficient_frame(score, stage="equivalence").set_index(
        "feature"
    )
    rank_frame = rank_coefficient_frame(rank, stage="equivalence").set_index(
        "feature"
    )
    official_predictions = _read_csv(required["external_predictions"]).set_index(
        "name"
    )
    score_predictions = pd.Series(
        predict_score(score, external), index=external["name"], dtype=float
    )
    rank_predictions = pd.Series(
        rank_utility(rank, external), index=external["name"], dtype=float
    )
    audit = {
        "status": "passed",
        "definition": (
            "floor=0 compact robust Ridge alpha=10 and scaled soft-rank "
            "alpha=100 versus locked official outputs"
        ),
        "hard_tolerance": EQUIVALENCE_TOLERANCE,
        "score_original_coefficient_max_abs_difference": float(
            np.max(
                np.abs(
                    score_frame.loc[list(FEATURES), "coefficient_original_units"]
                    - official_score.loc[
                        list(FEATURES), "coefficient_original_units"
                    ]
                )
            )
        ),
        "rank_model_scale_coefficient_max_abs_difference": float(
            np.max(
                np.abs(
                    rank_frame.loc[list(FEATURES), "coefficient_model_scale"]
                    - official_rank.loc[
                        list(FEATURES), "coefficient_model_scale"
                    ]
                )
            )
        ),
        "rank_original_coefficient_max_abs_difference": float(
            np.max(
                np.abs(
                    rank_frame.loc[list(FEATURES), "coefficient_original_units"]
                    - official_rank.loc[
                        list(FEATURES), "coefficient_original_units"
                    ]
                )
            )
        ),
        "external_score_prediction_max_abs_difference": float(
            np.max(
                np.abs(
                    score_predictions.loc[official_predictions.index]
                    - official_predictions["predicted_overall"]
                )
            )
        ),
        "external_rank_utility_max_abs_difference": float(
            np.max(
                np.abs(
                    rank_predictions.loc[official_predictions.index]
                    - official_predictions["rank_utility"]
                )
            )
        ),
    }
    differences = [
        value
        for key, value in audit.items()
        if key.endswith("_max_abs_difference")
    ]
    if max(differences) > EQUIVALENCE_TOLERANCE:
        raise RuntimeError(
            "Compact floor=0 implementation no longer matches the official model; "
            f"maximum difference={max(differences):.6g}"
        )
    return audit


def _external_rank_evaluation(
    model: dict[str, Any], external: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any], dict[str, Any]]:
    utilities = rank_utility(model, external)
    rankings = rank_summary(external["name"], utilities)
    indexed = external.set_index("name")
    rankings["overall"] = rankings["name"].map(indexed["overall"])
    pair_rows: list[dict[str, Any]] = []
    for left in range(len(external) - 1):
        for right in range(left + 1, len(external)):
            left_name = str(external["name"].iloc[left])
            right_name = str(external["name"].iloc[right])
            actual_difference = float(
                external["overall"].iloc[left] - external["overall"].iloc[right]
            )
            pair_rows.append(
                {
                    "left_name": left_name,
                    "right_name": right_name,
                    "left_overall": float(external["overall"].iloc[left]),
                    "right_overall": float(external["overall"].iloc[right]),
                    "target_probability_left_better": float(
                        preference_probability(actual_difference)
                    ),
                    "predicted_probability_left_better": float(
                        expit(utilities[left] - utilities[right])
                    ),
                    "actual_direction_left_better": actual_difference > 0.0,
                    "predicted_direction_left_better": (
                        utilities[left] - utilities[right]
                    )
                    > 0.0,
                }
            )
    pairs = pd.DataFrame(pair_rows)
    pair_metrics = soft_pair_metrics(
        pairs["target_probability_left_better"],
        pairs["predicted_probability_left_better"],
    )
    device_metrics = device_rank_metrics(
        external["overall"], utilities
    )
    return rankings, pairs, pair_metrics, device_metrics


def train_compact(
    prepared_path: str | Path,
    split_path: str | Path,
    output_dir: str | Path,
    model_path: str | Path,
    *,
    score_alphas: Iterable[float] = DEFAULT_SCORE_ALPHAS,
    score_floors: Iterable[float] = DEFAULT_SCORE_FLOORS,
    rank_alphas: Iterable[float] = DEFAULT_RANK_ALPHAS,
    rank_floors: Iterable[float] = DEFAULT_RANK_FLOORS,
    score_tolerance: float = SCORE_TOLERANCE,
    rank_tolerance: float = RANK_TOLERANCE,
    official_results_dir: str | Path | None = None,
) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    model_target = Path(model_path)
    model_target.parent.mkdir(parents=True, exist_ok=True)

    for label, value in (
        ("score_tolerance", score_tolerance),
        ("rank_tolerance", rank_tolerance),
    ):
        if not math.isfinite(float(value)) or float(value) < 0.0:
            raise ValueError(f"{label} must be finite and >= 0")
    preparation_manifest_path = _preparation_manifest_path(prepared_path)
    if not preparation_manifest_path.exists():
        raise ValueError(
            "Prepared input lacks its source-audit manifest; run the compact "
            f"prepare command first: {preparation_manifest_path}"
        )
    preparation_manifest = json.loads(
        preparation_manifest_path.read_text(encoding="utf-8")
    )
    if preparation_manifest.get("source_policy_validated") is not True:
        raise ValueError("Preparation manifest did not validate prediction sources")
    if preparation_manifest.get("prepared_sha256") != _sha256(prepared_path):
        raise ValueError("Prepared CSV no longer matches its preparation manifest")

    frame = load_prepared(prepared_path, require_target=True)
    split = load_split(split_path, frame)
    tablet_names = split["tablet_development"]
    pc_development_names = split["pc_development"]
    external_names = split["pc_external"]
    development = subset(frame, tablet_names + pc_development_names)
    external = subset(frame, external_names)

    score_candidates = candidate_grid("score", score_alphas, score_floors)
    rank_candidates = candidate_grid("rank", rank_alphas, rank_floors)
    if not any(item["coefficient_floor"] == 0.0 for item in score_candidates):
        raise ValueError("Score grid must retain floor=0 as a diagnostic baseline")
    if not any(item["coefficient_floor"] == 0.0 for item in rank_candidates):
        raise ValueError("Rank grid must retain floor=0 as a diagnostic baseline")

    score_comparison, score_candidate_oof = compare_score_candidates(
        frame, tablet_names, pc_development_names, score_candidates
    )
    selected_score = _select_positive_candidate(
        score_comparison, metric="mae", tolerance=score_tolerance
    )
    score_comparison = _mark_selection(
        score_comparison,
        selected_score,
        metric="mae",
        tolerance=score_tolerance,
    )
    rank_comparison, rank_candidate_pairs, rank_candidate_devices = (
        compare_rank_candidates(
            frame, tablet_names, pc_development_names, rank_candidates
        )
    )
    selected_rank = _select_positive_candidate(
        rank_comparison, metric="pairwise_log_loss", tolerance=rank_tolerance
    )
    rank_comparison = _mark_selection(
        rank_comparison,
        selected_rank,
        metric="pairwise_log_loss",
        tolerance=rank_tolerance,
    )

    score_nested, score_selections, score_nested_coefficients = (
        nested_score_validation(
            frame,
            tablet_names,
            pc_development_names,
            score_candidates,
            score_tolerance,
        )
    )
    (
        rank_nested_pairs,
        rank_nested_devices,
        rank_selections,
        rank_nested_coefficients,
    ) = nested_rank_validation(
        frame,
        tablet_names,
        pc_development_names,
        rank_candidates,
        rank_tolerance,
    )

    score_model = fit_score_model(
        development,
        alpha=selected_score["alpha"],
        coefficient_floor=selected_score["coefficient_floor"],
    )
    rank_model = fit_rank_model(
        development,
        alpha=selected_rank["alpha"],
        coefficient_floor=selected_rank["coefficient_floor"],
    )
    final_coefficients = pd.concat(
        [
            score_coefficient_frame(score_model, stage="final_locked"),
            rank_coefficient_frame(rank_model, stage="final_locked"),
        ],
        ignore_index=True,
    )
    if not final_coefficients["coefficient_model_scale"].gt(0.0).all():
        raise RuntimeError("Final compact-positive model contains a non-positive coefficient")

    created_utc = datetime.now(timezone.utc).isoformat()
    bundle = {
        "schema_version": 1,
        "kind": "compact_positive_overall_bundle",
        "features": list(FEATURES),
        "score_model": score_model,
        "rank_model": rank_model,
        "selected_score": selected_score,
        "selected_rank": selected_rank,
        "pc_reference": _frame_to_state(subset(frame, pc_development_names)),
        "training_scope": {
            "tablet_development": tablet_names,
            "pc_development": pc_development_names,
            "pc_external_excluded_from_fit_and_selection": external_names,
        },
        "input_hashes": {
            "development_training_table_sha256": _frame_sha256(
                development, ["name", "domain", *FEATURES, "overall"]
            ),
            "all_device_feature_matrix_sha256": _frame_sha256(
                frame, ["name", "domain", *FEATURES]
            ),
            "frozen_split_sha256": _sha256(split_path),
        },
        "coefficient_floor_semantics": (
            "closed positive lower bound on fold-local model-scale quality "
            "coefficients; PC score offset and intercept are unconstrained"
        ),
    }
    joblib.dump(bundle, model_target)
    model_sha256 = _sha256(model_target)
    lock_manifest = {
        "model_serialized_before_external_metrics_computed": True,
        "model_path": str(model_target.resolve()),
        "model_sha256": model_sha256,
        "created_utc": created_utc,
        "selected_score": selected_score,
        "selected_rank": selected_rank,
        "external_devices_excluded_from_selection": external_names,
    }
    _write_json(_json_number(lock_manifest), output / "lock_manifest.json")

    # Everything below this line is descriptive external evaluation only.
    external_score_prediction = predict_score(score_model, external)
    external_score_metrics = regression_metrics(
        external["overall"], external_score_prediction
    )
    external_rankings, external_pairs, external_pair_metrics, external_device_metrics = (
        _external_rank_evaluation(rank_model, external)
    )
    external_predictions = external_rankings.merge(
        pd.DataFrame(
            {
                "name": external["name"],
                "predicted_overall": external_score_prediction,
                "actual_overall": external["overall"],
                "score_residual": external_score_prediction
                - external["overall"].to_numpy(dtype=float),
            }
        ),
        on="name",
        how="left",
        validate="one_to_one",
    )
    external_predictions["score_abs_error"] = external_predictions[
        "score_residual"
    ].abs()

    official_dir = (
        Path(official_results_dir)
        if official_results_dir is not None
        else PROJECT_ROOT / "results" / "real" / "train"
    )
    equivalence = baseline_equivalence_audit(
        development, external, official_dir
    )
    official_metrics_path = official_dir / "metrics.json"
    official_metrics = (
        json.loads(official_metrics_path.read_text(encoding="utf-8"))
        if official_metrics_path.exists()
        else {}
    )
    score_nested_metrics = regression_metrics(
        score_nested["actual_overall"], score_nested["predicted_overall"]
    )
    rank_nested_pair_metrics = soft_pair_metrics(
        rank_nested_pairs["target_probability_heldout_better"],
        rank_nested_pairs["predicted_probability_heldout_better"],
    )
    rank_nested_device_metrics = device_rank_metrics(
        rank_nested_devices["actual_overall"],
        rank_nested_devices["oof_expected_win_percent"],
    )
    validation_summary = {
        "status": "completed",
        "model_sha256": model_sha256,
        "selected_score": selected_score,
        "selected_rank": selected_rank,
        "score_nested_pc_loo": score_nested_metrics,
        "rank_nested_pc_loo_pairs": rank_nested_pair_metrics,
        "rank_nested_pc_loo_devices": rank_nested_device_metrics,
        "external_pc_score_posthoc_only": external_score_metrics,
        "external_pc_rank_pairs_posthoc_only": external_pair_metrics,
        "external_pc_rank_devices_posthoc_only": external_device_metrics,
        "final_coefficient_audit": {
            model_name: {
                "n_features": int(len(group)),
                "minimum_model_scale_coefficient": float(
                    group["coefficient_model_scale"].min()
                ),
                "configured_floor": float(
                    group["configured_min_coefficient"].iloc[0]
                ),
                "n_at_lower_bound": int(group["at_lower_bound"].sum()),
            }
            for model_name, group in final_coefficients.groupby("model")
        },
        "floor_zero_equivalence_to_official": equivalence,
        "official_metric_deltas": {
            "nested_score_mae": (
                score_nested_metrics["mae"]
                - official_metrics.get("score_nested_pc_loo", {}).get("mae", 0.0)
                if official_metrics
                else None
            ),
            "nested_rank_log_loss": (
                rank_nested_pair_metrics["pairwise_log_loss"]
                - official_metrics.get("rank_nested_pc_loo_pairs", {}).get(
                    "pairwise_log_loss", 0.0
                )
                if official_metrics
                else None
            ),
            "external_score_mae_posthoc": (
                external_score_metrics["mae"]
                - official_metrics.get("external_pc_score", {}).get("mae", 0.0)
                if official_metrics
                else None
            ),
            "external_rank_log_loss_posthoc": (
                external_pair_metrics["pairwise_log_loss"]
                - official_metrics.get("external_pc_rank_pairs", {}).get(
                    "pairwise_log_loss", 0.0
                )
                if official_metrics
                else None
            ),
        },
        "external_use_policy": (
            "These seven PC labels had already been viewed in the historical official "
            "run, so this is posthoc description rather than a fresh frozen test. "
            "They were excluded from fit and selection; this candidate's external "
            "metrics were computed only after model serialization and lock-manifest "
            "creation, and no hyperparameter or floor was then changed."
        ),
    }

    _write_csv(score_comparison, output / "score_candidate_comparison.csv")
    _write_csv(score_candidate_oof, output / "score_candidate_oof.csv")
    _write_csv(score_nested, output / "score_nested_oof.csv")
    _write_csv(score_selections, output / "score_nested_selections.csv")
    _write_csv(rank_comparison, output / "rank_candidate_comparison.csv")
    _write_csv(rank_candidate_pairs, output / "rank_candidate_oof_pairs.csv")
    _write_csv(rank_candidate_devices, output / "rank_candidate_oof_devices.csv")
    _write_csv(rank_nested_pairs, output / "rank_nested_oof_pairs.csv")
    _write_csv(rank_nested_devices, output / "rank_nested_oof_devices.csv")
    _write_csv(rank_selections, output / "rank_nested_selections.csv")
    _write_csv(final_coefficients, output / "final_coefficients.csv")
    _write_csv(
        pd.concat(
            [score_nested_coefficients, rank_nested_coefficients],
            ignore_index=True,
        ),
        output / "nested_coefficients.csv",
    )
    _write_csv(external_predictions, output / "external_posthoc_predictions.csv")
    _write_csv(external_pairs, output / "external_posthoc_pairs.csv")
    _write_json(_json_number(equivalence), output / "baseline_equivalence.json")
    _write_json(_json_number(validation_summary), output / "validation_summary.json")
    metadata = {
        "schema_version": 1,
        "created_utc": created_utc,
        "model_path": str(model_target.resolve()),
        "model_sha256": model_sha256,
        "prepared_path": str(Path(prepared_path).resolve()),
        "prepared_sha256": _sha256(prepared_path),
        "preparation_manifest_path": str(preparation_manifest_path.resolve()),
        "preparation_manifest_sha256": _sha256(preparation_manifest_path),
        "split_path": str(Path(split_path).resolve()),
        "selected_score": selected_score,
        "selected_rank": selected_rank,
        "implementation": str(Path(__file__).resolve()),
        "implementation_sha256": _sha256(__file__),
        "limitations": [
            "compact mode omits uncertainty intervals and OOD diagnostics",
            "compact prepare expects canonical English columns",
            "coefficients at the lower bound indicate forced participation, not evidence",
            "formal frozen claims remain attached to the unchanged official pipeline",
        ],
    }
    _write_json(_json_number(metadata), output / "metadata.json")
    return _json_number(validation_summary)


def predict_compact(
    model_path: str | Path,
    prepared_path: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    bundle = joblib.load(model_path)
    if bundle.get("kind") != "compact_positive_overall_bundle":
        raise ValueError("Not a compact-positive model bundle")
    if list(bundle.get("features", [])) != list(FEATURES):
        raise ValueError("Model feature schema does not match this implementation")
    new = load_prepared(prepared_path, require_target=False)
    if not new["domain"].eq("pc").all():
        raise ValueError("Compact rank prediction currently accepts PC devices only")
    reference = _frame_from_state(bundle["pc_reference"])
    overlap = sorted(set(new["name"]) & set(reference["name"]))
    if overlap:
        raise ValueError(f"New-device names overlap the 5 reference PCs: {overlap}")
    combined = pd.concat([new, reference], ignore_index=True, sort=False)
    score_prediction = predict_score(bundle["score_model"], new)
    combined_utilities = rank_utility(bundle["rank_model"], combined)
    combined_ranks = rank_summary(combined["name"], combined_utilities)
    new_output = combined_ranks[combined_ranks["name"].isin(new["name"])].merge(
        pd.DataFrame(
            {"name": new["name"], "predicted_overall": score_prediction}
        ),
        on="name",
        how="left",
        validate="one_to_one",
    )
    reference_utility = dict(zip(combined["name"], combined_utilities, strict=True))
    pair_rows: list[dict[str, Any]] = []
    for new_name in new["name"].astype(str):
        for reference_name in reference["name"].astype(str):
            probability = float(
                expit(reference_utility[new_name] - reference_utility[reference_name])
            )
            pair_rows.append(
                {
                    "new_name": new_name,
                    "reference_name": reference_name,
                    "predicted_probability_new_better": probability,
                    "predicted_probability_reference_better": 1.0 - probability,
                }
            )
    output = Path(output_dir)
    _write_csv(new_output, output / "new_device_predictions.csv")
    _write_csv(combined_ranks, output / "combined_reference_rankings.csv")
    _write_csv(
        pd.DataFrame(pair_rows), output / "new_vs_reference_probabilities.csv"
    )
    summary: dict[str, Any] = {
        "status": "completed",
        "model_sha256": _sha256(model_path),
        "n_new_devices": int(len(new)),
        "reference_pc_names": reference["name"].astype(str).tolist(),
        "outputs": {
            "new_device_predictions": str(
                (output / "new_device_predictions.csv").resolve()
            ),
            "combined_reference_rankings": str(
                (output / "combined_reference_rankings.csv").resolve()
            ),
            "new_vs_reference_probabilities": str(
                (output / "new_vs_reference_probabilities.csv").resolve()
            ),
        },
    }
    if "overall" in new.columns:
        summary["optional_labeled_score_evaluation"] = regression_metrics(
            new["overall"], score_prediction
        )
        summary["optional_labeled_rank_evaluation"] = device_rank_metrics(
            new["overall"],
            np.asarray([reference_utility[name] for name in new["name"]]),
        )
    _write_json(_json_number(summary), output / "prediction_summary.json")
    return _json_number(summary)


def inspect_bundle(model_path: str | Path) -> dict[str, Any]:
    bundle = joblib.load(model_path)
    score = bundle["score_model"]
    rank = bundle["rank_model"]
    return _json_number(
        {
            "kind": bundle.get("kind"),
            "schema_version": bundle.get("schema_version"),
            "model_sha256": _sha256(model_path),
            "selected_score": bundle.get("selected_score"),
            "selected_rank": bundle.get("selected_rank"),
            "score_minimum_coefficient": float(np.min(score["coef"])),
            "rank_minimum_coefficient": float(np.min(rank["coef"])),
            "reference_pc_names": bundle["pc_reference"]["name"],
        }
    )


# ---------------------------------------------------------------------------
# Four small commands replace the former multi-file runtime surface
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Compact positive-coefficient score/rank pipeline"
    )
    commands = parser.add_subparsers(dest="command", required=True)

    prepare = commands.add_parser(
        "prepare", help="Create the canonical official 19-feature table"
    )
    prepare.add_argument(
        "--overall",
        default=PROJECT_ROOT / "data" / "real" / "overall_features.csv",
        type=Path,
    )
    prepare.add_argument(
        "--domains",
        default=PROJECT_ROOT / "data" / "real" / "device_domains.csv",
        type=Path,
    )
    prepare.add_argument(
        "--submodels",
        default=PROJECT_ROOT / "data" / "real" / "submodel_predictions.csv",
        type=Path,
    )
    prepare.add_argument(
        "--output",
        default=(
            PROJECT_ROOT
            / "results"
            / "experiments"
            / "compact_positive"
            / "prepared_features.csv"
        ),
        type=Path,
    )

    train = commands.add_parser(
        "train", help="Nested-validate, lock, then describe the frozen external PCs"
    )
    train.add_argument(
        "--prepared",
        default=(
            PROJECT_ROOT
            / "results"
            / "experiments"
            / "compact_positive"
            / "prepared_features.csv"
        ),
        type=Path,
    )
    train.add_argument(
        "--split",
        default=PROJECT_ROOT / "data" / "real" / "frozen_pc_split.json",
        type=Path,
    )
    train.add_argument(
        "--output-dir",
        default=PROJECT_ROOT / "results" / "experiments" / "compact_positive",
        type=Path,
    )
    train.add_argument(
        "--model",
        default=(
            PROJECT_ROOT
            / "models"
            / "experiments"
            / "compact_positive"
            / "overall_compact_positive_bundle.joblib"
        ),
        type=Path,
    )
    train.add_argument(
        "--score-alphas",
        default=",".join(f"{value:g}" for value in DEFAULT_SCORE_ALPHAS),
    )
    train.add_argument(
        "--score-floors",
        default=",".join(f"{value:g}" for value in DEFAULT_SCORE_FLOORS),
    )
    train.add_argument(
        "--rank-alphas",
        default=",".join(f"{value:g}" for value in DEFAULT_RANK_ALPHAS),
    )
    train.add_argument(
        "--rank-floors",
        default=",".join(f"{value:g}" for value in DEFAULT_RANK_FLOORS),
    )
    train.add_argument("--score-tolerance", type=float, default=SCORE_TOLERANCE)
    train.add_argument("--rank-tolerance", type=float, default=RANK_TOLERANCE)

    predict = commands.add_parser(
        "predict", help="Predict already-prepared new PC devices"
    )
    predict.add_argument("--prepared", required=True, type=Path)
    predict.add_argument(
        "--model",
        default=(
            PROJECT_ROOT
            / "models"
            / "experiments"
            / "compact_positive"
            / "overall_compact_positive_bundle.joblib"
        ),
        type=Path,
    )
    predict.add_argument("--output-dir", required=True, type=Path)

    inspect = commands.add_parser("inspect", help="Print locked bundle metadata")
    inspect.add_argument(
        "--model",
        default=(
            PROJECT_ROOT
            / "models"
            / "experiments"
            / "compact_positive"
            / "overall_compact_positive_bundle.joblib"
        ),
        type=Path,
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "prepare":
        path = prepare_canonical_inputs(
            args.overall, args.domains, args.submodels, args.output
        )
        payload = {"status": "completed", "prepared_path": str(path.resolve())}
    elif args.command == "train":
        payload = train_compact(
            args.prepared,
            args.split,
            args.output_dir,
            args.model,
            score_alphas=_parse_grid(args.score_alphas, allow_zero=False),
            score_floors=_parse_grid(args.score_floors, allow_zero=True),
            rank_alphas=_parse_grid(args.rank_alphas, allow_zero=False),
            rank_floors=_parse_grid(args.rank_floors, allow_zero=True),
            score_tolerance=args.score_tolerance,
            rank_tolerance=args.rank_tolerance,
        )
    elif args.command == "predict":
        payload = predict_compact(args.model, args.prepared, args.output_dir)
    elif args.command == "inspect":
        payload = inspect_bundle(args.model)
    else:  # pragma: no cover - argparse enforces the command choices.
        raise AssertionError(args.command)
    print(json.dumps(_json_number(payload), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
