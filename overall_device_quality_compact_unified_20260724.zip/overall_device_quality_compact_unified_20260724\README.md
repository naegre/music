# 总体音质模型：精简正系数统一包

## 先看结论

这个包把以下内容合并到了一起：

1. 之前的“单文件精简、所有质量特征系数严格大于 0”版本；
2. 原 5 台 PC 使用预测 treble 的敏感性实验；
3. 重新选择 5 台 PC 后，分别使用原始 treble 和预测 treble 的实验；
4. 所有逐折预测、设备对、系数、选参、泄漏审计和设备重选证据。

原正式冻结模型、原冻结切分和历史结果没有被覆盖。本包中的主模型应准确称为：

> 精简严格正系数候选，也是本包当前推荐、可以直接调用 `predict` 的版本。

四个版本定义如下：

| 简称 | PC 开发 5 台 | treble 定义 | 特征数 | 是否可直接部署 |
|---|---|---|---:|---|
| A：原 5 + 原始 treble | CG-、MG-、pro14-、pro16-、xx14- | 保留 `treble_1`、`treble_2` | 19 | 是，本包主模型 |
| B：原 5 + 预测 treble | 同 A | 两列替换成一个预测百分位 | 18 | 否，仅审计快照 |
| C：新 5 + 原始 treble | air13-、enzoh-、magic-、pro14-、xx14- | 保留 `treble_1`、`treble_2` | 19 | 否，仅审计快照 |
| D：新 5 + 预测 treble | 同 C | 两列替换成一个预测百分位 | 18 | 否，仅审计快照 |

必须先澄清两个容易混淆的说法：

- “原始 treble”不是“没有 treble”，而是保留两列原始的 `treble_1/treble_2`。
- “预测 treble”不是只给四台空缺设备补值，而是所有 29 台设备都改用一个 `treble__predicted_percentile`，所以模型由 19 特征变成 18 特征。

开发阶段的主要 nested 结果为：

| 版本 | Score MAE，越低越好 | Rank 方向 | Rank Brier，越低越好 | Rank log loss，越低越好 |
|---|---:|---:|---:|---:|
| A：原 5 + 原始 treble | **2.8145** | **20/20** | **0.0090** | **0.2051** |
| B：原 5 + 预测 treble | 3.2350 | 20/20 | 0.0111 | 0.2208 |
| C：新 5 + 原始 treble | **2.4982** | 18/20 | 0.0266 | 0.2359 |
| D：新 5 + 预测 treble | 2.7631 | 19/20 | 0.0293 | 0.2497 |

最终建议：

- 继续使用 A“原 5 + 原始 treble”作为当前精简正系数主候选。
- B 和 D 都没有得到启用预测 treble 的证据：在相同设备切分内，Score MAE 和 Rank log loss 都变差。
- C 的新 5 台是“按无标签 X/SE 覆盖目标更有代表性”，不是“预测准确率最优 5 台”。它可作为未来全新 PC 的预注册候选，但目前不替换 A。

## 1. 为什么代码仍然是精简版

本包只有两个核心 Python 文件：

```text
compact_positive/overall_quality_compact.py
analysis/run_compact_posthoc_extensions.py
```

第一个文件负责日常主流程：

```text
规范数据准备
→ 正系数 Score/Rank 训练
→ 嵌套验证
→ 锁定模型
→ 新设备预测
→ 模型信息检查
```

第二个文件只负责三个扩展实验：

```text
原 5 + 预测 treble
新 5 + 原始 treble
新 5 + 预测 treble
```

它同时完成全局 5 台选择、折内 treble bridge、三组训练、结果比较和防泄漏审计。没有再拆成多个数据处理、训练、评估和画表脚本。

根目录只保留一个 `README.md` 和一个 `requirements.txt`。结果目录中的旧版重复说明已经移除，避免出现互相矛盾的多个 README。

## 2. 包目录

```text
README.md
requirements.txt
ENVIRONMENT.txt
SHA256SUMS.txt

compact_positive/
  overall_quality_compact.py

analysis/
  run_compact_posthoc_extensions.py

data/
  real/                              原始规范输入与冻结切分
  experiments/
    posthoc_treble_sensitivity/      treble 来源和 bridge 审计
    compact_posthoc_extensions/      792 组合、重选名单和选择锁

models/
  experiments/
    compact_positive/                可调用的 A 模型
    compact_posthoc_extensions/      B/C/D 分析快照

results/
  real/train/                        未改正式实现的等价性参考
  experiments/
    compact_positive/                A 的完整结果
    compact_posthoc_extensions/      B/C/D 的完整结果

verification/
  compact_positive_independent_verification.json
  unified_package_verification.json
```

## 3. 数据定义

### 3.1 设备范围

权威白名单共 29 台：

- 17 台 tablet；
- 12 台 PC。

原切分为：

- 17 台 tablet 全部用于开发训练；
- 5 台 PC 用于选参和 nested leave-one-PC-out；
- 7 台 PC 在模型锁定后计算描述性结果。

需要特别注意：这 7 台 PC 的标签在历史项目中已经被查看过，所以现在只能称为 `posthoc_only`，不能重新包装成一次新的冻结外测。

### 3.2 原始 22 个总体特征

`data/real/overall_features.csv` 一行一台设备，包含 `name` 和 22 个规范英文特征：

```text
loudness
dynamics_1_S, dynamics_2
timber_1, timber_2
treble_1, treble_2
edginess
balance
fullness
clarity_1_S, clarity_2, clarity_3_S
spatial_1, spatial_2, spatial_3_S, spatial_4_S, spatial_5_S, spatial_6_S
artefacts_1_S, artefacts_2, artefacts_3_S
```

训练时还需要 0–100 的 `overall`。新设备预测时可以不提供 `overall`。

列名以 `_S` 结尾表示主观特征，但模型不会因为 `_S` 自动改变其方向；所有输入都必须已经满足“数值越高表示质量越好”。

### 3.3 四组 subdir 替换

基础 19 特征版本会进行以下替换：

| 子模型 | 被替换的原始列 | 替换后列 |
|---|---|---|
| clarity | clarity_1_S、clarity_2、clarity_3_S | clarity__predicted_percentile |
| lowfreq | timber_1、timber_2 | lowfreq__predicted_percentile |
| fullness | fullness | fullness__predicted_percentile |
| edginess | edginess | edginess__predicted_percentile |

其余 loudness、dynamics、treble、balance、spatial 和 artefacts 保留，最终得到 19 个模型特征。

`data/real/submodel_predictions.csv` 对每台设备必须各有一行：

```text
clarity、lowfreq、fullness、edginess
```

关键字段为：

```text
name,subdir,predicted_percentile,prediction_source
```

来源规则：

- 训练 tablet 通常必须使用 OOF；
- `ipadPro2022-` 是已确认的 inductive 例外；
- PC 必须使用 inductive；
- 新 PC 同样必须使用 inductive。

`prepared_features.manifest.json` 会记录输入哈希、来源计数、19 特征 schema 和准备表哈希。训练命令会再次核对这些内容，不能用手工拼接的 CSV 绕过来源检查。

### 3.4 缺失值

仍然存在的数值缺失不会使用外层验证设备来填充。每个训练折只用自己的训练数据拟合列中位数，然后把该中位数应用于该折验证设备。

这表示：

- 缺失值处理发生在折内；
- 验证设备不会影响自己的填充值；
- 中位数补值只是稳健折中，不能恢复原本缺失的信息。

## 4. 两层模型结构

“两层”在这里指两个先后阶段：

```text
第一层：clarity / lowfreq / fullness / edginess 子模型预测百分位
第二层：总体 Score 模型和总体 Rank 模型
```

第二层并不是一个模型同时输出两种结果，而是两个独立模型。

### 4.1 Score：绝对分数模型

处理顺序：

```text
折内列中位数补缺
→ 折内稳健中心和尺度
→ tablet/PC 域平衡样本权重
→ 带严格正系数下界的 Ridge 回归
→ 加上截距和 PC 域偏置
→ 输出 0–100 predicted_overall
```

Score 优化的是绝对分数误差。一个模型即使排名正确，如果所有分数都低估 5 分，Score 仍然是不好的。

### 4.2 Rank：两两排名模型

处理顺序：

```text
折内列中位数补缺
→ 折内公共差值尺度
→ 只在相同 domain 内生成设备对
→ 将 overall 分差转成软目标概率
→ 带严格正系数下界和 L2 正则的逻辑排序
→ 输出 utility、名次和两两胜率
```

不会构造 tablet–PC 跨域设备对。Rank 优化的是“设备 A 优于设备 B 的概率”，不是绝对 overall 分数。

### 4.3 Rank 的软目标

真实设备对的软目标为：

```text
q = clip(0.5 + 0.1 × (overall_left - overall_right), 0, 1)
```

例如：

- 同分：`q=0.5`；
- 左设备高 1 分：`q=0.6`；
- 左设备高 3 分：`q=0.8`；
- 分差达到 5 分：截成 0 或 1。

模型概率为：

```text
p = sigmoid(utility_left - utility_right)
```

因此 Rank 不只要判断方向，还要给出合理的概率强度。

## 5. 严格非零系数如何实现

本版不是在训练结束后把零系数手工改成小数，而是在优化器内部施加：

```text
每个质量特征系数 >= coefficient_floor > 0
```

这样截距、域偏置和其余系数会在约束存在的条件下共同重新优化。

约束施加在折内标准化模型尺度。不同原始列的量纲不一样，如果统一约束原始单位系数，可能会不合理地放大某些列。

Score 候选：

```text
alpha = 1, 10, 100
floor = 0, 0.001, 0.005, 0.01
```

Rank 候选：

```text
alpha = 10, 100, 1000
floor = 0, 0.0005, 0.001, 0.0025
```

`floor=0` 只用于检查精简代码能否复现未加约束的正式模型，它没有最终入选资格。

选择规则：

- Score 先找正下界候选中最低的 LOO MAE；在最佳值 `+0.5` 范围内，偏好更小正下界、更强 alpha、再比较 MAE。
- Rank 使用 pairwise log loss；容差为最佳值 `+0.01`，之后采用同样的稳定性偏好。

这是一种“性能接近时优先选择收缩更强、最低正下界更小的简单模型”的规则。

最终配置：

| 版本 | Score alpha/floor | Rank alpha/floor | Score 贴下界 | Rank 贴下界 |
|---|---|---|---:|---:|
| A | 10 / 0.001 | 1000 / 0.0005 | 4/19 | 2/19 |
| B | 10 / 0.001 | 1000 / 0.0005 | 4/18 | 2/18 |
| C | 10 / 0.001 | 100 / 0.0005 | 5/19 | 4/19 |
| D | 10 / 0.001 | 100 / 0.0005 | 5/18 | 5/18 |

`at_lower_bound=true` 的正确解释是：

> 该特征主要因为“必须非零”的业务先验被保留。

它不能解释为“数据证明该特征重要”。系数大小还受尺度、共线性和正则化影响，不能直接当成严格的特征重要性排名。

## 6. 验证和防泄漏结构

### 6.1 固定候选 LOO

对每一个固定的 `alpha + floor` 候选，在 5 台开发 PC 上做 LOO，得到：

```text
score_candidate_comparison.csv
rank_candidate_comparison.csv
```

这些结果用于选候选，所以选中行的指标是“调参指标”，不是完全独立的最终性能。

### 6.2 Nested leave-one-PC-out

外层每次留出 1 台开发 PC：

```text
外层留出 1 PC
→ 剩余 4 PC + 17 tablet 做内层候选选择
→ 用选中的参数重新训练
→ 预测外层 PC
```

这评价的是“包含选参在内的完整流程”，因此是开发阶段的主要结果。

Rank 每个外层 held-out PC 会与其余 4 台 PC 比较，共：

```text
5 × 4 = 20 行有向外折比较
```

同一个无序设备对会在两个不同外层模型下各出现一次，因此 20 行不是 20 个相互独立的设备对。

设备级 OOF expected-win 则将 5 台设备汇总后比较 `C(5,2)=10` 个无序对，所以设备级准确率可能与 20 行有向 pair accuracy 不同。

### 6.3 历史剩余 7 台

模型、参数和名单锁定并写入 `lock_manifest.json` 后，才计算剩余 7 台指标。这能证明它们没有进入本次拟合和选参，但不能消除“这些标签在历史中已经看过”的事实。

所以：

- 可以诚实报告；
- 不可用于重新选择 alpha、floor、treble 策略或 5 台名单；
- 不可称为本轮新的冻结外测。

## 7. 原始 treble 与预测 treble

### 7.1 两种特征定义

原始 treble 版本：

```text
treble_1 + treble_2
```

预测 treble 版本：

```text
treble__predicted_percentile
```

预测版本会对全部设备替换 treble 表示，不是只处理四台缺失 PC。

### 7.2 treble 来源与四台缺失

29 台设备中，25 台有直接 treble 子模型预测百分位：

- 16 条 OOF；
- 9 条 inductive。

缺失的四台为：

```text
air13-、air15-、pro14-、pro16-
```

bridge 输入为：

```text
原始 treble_1、treble_2
clarity、lowfreq、fullness、edginess 四个预测百分位
```

候选方法：

```text
开发集中位数
Ridge：只用其他四个子模型
Ridge：使用全部六个输入
KNN：使用全部六个输入
```

每个 overall 外折内部都会只用该折训练设备重新做辅助 LOO、选择 bridge、拟合并填值。若全六输入 Ridge 的 LOO MAE 距最佳值不超过 `0.5`，优先使用 Ridge；否则选择 MAE、RMSE 最好的候选。输出裁剪到 `[0,100]`。

`overall` 从未进入 bridge。被留出的 PC 同时不会进入：

- overall 模型拟合；
- treble bridge 的目标拟合。

### 7.3 最终填充值

原 5 台开发集最终 bridge：

| 设备 | treble percentile |
|---|---:|
| air13- | 71.5419 |
| air15- | 72.5153 |
| pro14- | 92.7969 |
| pro16- | 98.7129 |

辅助 LOO MAE 约 `11.61`、RMSE 约 `14.15`。五个外折中四折选择 Ridge，留出 `xx14-` 时选择 KNN。

新 5 台开发集最终 bridge：

| 设备 | treble percentile |
|---|---:|
| air13- | 72.4179 |
| air15- | 74.1209 |
| pro14- | 95.1299 |
| pro16- | 100.0000 |

辅助 LOO MAE 约 `11.39`、RMSE 约 `14.30`；五个外折均选择 Ridge。

两组填充值不同是正确现象，因为 bridge 只能使用各自开发集合内可见的 treble 目标。

原始预测文件中：

```text
prediction_se = prediction_sd / sqrt(1000)
```

SE 没有作为 A/B/C/D 总体模型的额外质量特征，也没有进入 treble bridge。它只在“新 5 台覆盖选择器”中作为不确定度组使用。

## 8. treble 对照结果

### 8.1 原 5 台：A 对 B

这是同一设备切分、同一候选网格下的直接 treble 敏感性对照：

| Nested 指标 | A 原始 treble | B 预测 treble | B-A |
|---|---:|---:|---:|
| Score MAE | 2.8145 | 3.2350 | +0.4205，恶化 |
| Score RMSE | 3.5555 | 4.0966 | +0.5410，恶化 |
| Rank 方向 | 20/20 | 20/20 | 不变 |
| Rank Brier | 0.0090 | 0.0111 | 恶化 |
| Rank log loss | 0.2051 | 0.2208 | +0.0157，恶化 |

因此原 5 台不支持启用预测 treble。

历史 7 台事后结果中，B 的 Score MAE 从 `2.2366` 降到 `2.1465`，但 Rank log loss 从 `0.2633` 恶化到 `0.2802`。这些标签已被查看，不能利用 MAE 的这点事后改善回头调参。

### 8.2 新 5 台：C 对 D

| Nested 指标 | C 原始 treble | D 预测 treble | D-C |
|---|---:|---:|---:|
| Score MAE | 2.4982 | 2.7631 | +0.2649，恶化 |
| Score RMSE | 3.2182 | 3.4556 | +0.2374，恶化 |
| Rank 方向 | 18/20 | 19/20 | 多对 1 行 |
| Rank Brier | 0.0266 | 0.0293 | 恶化 |
| Rank log loss | 0.2359 | 0.2497 | +0.0139，恶化 |

虽然硬方向多对了一行，但 Score 误差和两个排名概率损失都变差，所以新 5 台也不支持启用预测 treble。

## 9. 新 5 台如何选择

### 9.1 为什么不能用 12 台真实结果遍历

如果枚举 792 个组合后，选择“剩余 7 台预测最准”的 5 台，就等于使用全部 12 台标签挑测试集，产生严重选择泄漏。

因此本次选择在模型训练和结果比较前锁定，完全不加载：

- `overall`；
- 旧 7 台预测；
- 旧 7 台误差；
- 任何 A/B/C/D 的训练结果。

### 9.2 选择器输入

对 12 台 PC 使用：

- 19 个可见质量特征；
- clarity、lowfreq、fullness、edginess 的四个 `prediction_se`。

每列做稳健缩放：

```text
z = (x - median) / robust_scale
```

`robust_scale` 优先为 `1.4826×MAD`；退化时依次使用 `IQR/1.349`、样本标准差和 1。

23 列被分成八个等权组：

```text
loudness
dynamics
treble
balance
spatial
artefacts
四个 submodel value
四个 uncertainty
```

先在组内对列平方差取平均，再让八个组等权，因此 spatial 不会因为列数多而自动压过 loudness。

设备距离：

```text
d(i,j) =
sqrt(
  (1/8) ×
  Σ 每个组内标准化列平方差的平均值
)
```

对五台集合 `S`：

```text
r_i = i 到 S 中最近设备的距离

mean_nearest_distance = mean(r_i)
max_nearest_distance  = max(r_i)
rms_nearest_distance  = sqrt(mean(r_i²))
```

`centroid_gap` 是入选五台中心与全部 12 台中心之间的分组等权 RMS 距离。

枚举全部：

```text
C(12,5) = 792
```

先最小化平均最近距离，再依次用最坏距离、RMS、中心偏差和设备名打破并列。

### 9.3 选择结果

原 5 台：

```text
CG-、MG-、pro14-、pro16-、xx14-
```

新 5 台：

```text
air13-、enzoh-、magic-、pro14-、xx14-
```

| 覆盖指标 | 原 5 台 | 新 5 台 | 相对变化 |
|---|---:|---:|---:|
| 覆盖排名 | 514/792 | 1/792 | — |
| 平均最近距离 | 0.7598 | 0.5848 | 改善 23.03% |
| 最坏最近距离 | 2.1645 | 1.1904 | 改善 45.01% |
| RMS 最近距离 | 1.0588 | 0.7784 | 改善 26.48% |
| 中心偏差 | 0.3504 | 0.5802 | 恶化 65.60% |

解释：

- 新名单对特征空间边缘和局部区域覆盖更好；
- 但五台的整体中心离 12 台总体中心更远；
- 它没有保持历史 overall 五层“一层一台”，因此不能声称目标分数范围更均衡；
- 把 12 台 PC 的 `overall` 改成另一组极端序列后，名单和距离逐位不变，标签负对照通过。

所以准确表述是：

> 新 5 台在预先声明的 X/SE 最近点覆盖目标下更有代表性。

不能表述为：

> 新 5 台已经被证明预测更准。

### 9.4 重选后的模型结果

C 相比 A：

- Nested Score MAE 从 `2.8145` 改善到 `2.4982`；
- Rank 方向从 `20/20` 变为 `18/20`；
- Rank log loss 从 `0.2051` 恶化到 `0.2359`。

但 A 和 C 的 nested 指标对应不同的五台设备，不是同一测试对象上的受控准确率竞赛。

两套训练都未使用的共同 PC 只有：

```text
air15-、harden-、hookeg-、vg-
```

共同四台的事后对照：

| treble | 指标 | 原 5 模型 | 新 5 模型 |
|---|---|---:|---:|
| 原始 | Score MAE | 1.9676 | 2.0180 |
| 原始 | Rank 方向 | 6/6 | 6/6 |
| 原始 | Rank log loss | 0.3212 | 0.3267 |
| 预测 | Score MAE | 2.2044 | 2.4337 |
| 预测 | Rank 方向 | 6/6 | 6/6 |
| 预测 | Rank log loss | 0.3446 | 0.3456 |

共同设备对照没有显示新 5 模型更准，而且它仍然是标签已查看、只有 4 台设备的 posthoc 描述。

真正验证重选是否有效，需要未来完全未查看标签的新 PC。

## 10. 所有主要指标如何计算

### 10.1 Score 指标

残差定义：

```text
residual = predicted_overall - actual_overall
```

| 指标 | 公式 | 反映内容 |
|---|---|---|
| MAE | `mean(abs(residual))` | 平均每台错多少分，越低越好 |
| RMSE | `sqrt(mean(residual²))` | 对大误差惩罚更重，越低越好 |
| bias | `mean(residual)` | 正数整体高估，负数整体低估 |
| max_abs_error | `max(abs(residual))` | 最差一台错多少分 |
| Pearson | 真实分与预测分的线性相关 | 线性变化是否一致，越接近 1 越好 |
| Spearman | 两组分数的秩相关 | 排序是否单调一致 |
| Kendall tau | 一致设备对与逆序设备对的关系 | 成对排序一致程度 |

误读警告：

- Pearson 高不等于 MAE 小；
- 所有设备都低估 5 分，Pearson 仍可能很高；
- Spearman/Kendall 高只说明顺序好，不说明绝对分数准；
- `bias=-2.2` 表示平均低估 2.2 分，不是“绝对误差为负数”。

### 10.2 Rank 指标

| 指标 | 计算 | 反映内容 |
|---|---|---|
| pairwise_accuracy | `p` 与 `q` 是否在 0.5 同侧；真实平局不计 | 只看方向 |
| pairwise_brier | `mean((p-q)²)` | 概率与软目标的平方距离 |
| pairwise_log_loss | `mean(-q log p -(1-q)log(1-p))` | 概率校准；错误且自信会被重罚 |
| device_pair_accuracy | 用设备级信号比较所有无序设备对 | 汇总排名方向 |
| Spearman/Kendall | overall 与设备级排名信号的秩相关 | 总体排序一致性 |

方向准确率只看阈值：

```text
p=0.51 和 p=0.99
```

只要方向相同都会算正确。但如果真实软目标只有 `0.6`，`0.99` 可能过度自信，Brier 和 log loss 会更差。因此 Rank 方向不能代替概率损失。

软目标本身不是 0/1 时，即使 `p=q`，交叉熵也不一定等于 0，所以 log loss 不能理解为“错误比例”。

### 10.3 排名输出字段

| 字段 | 含义 |
|---|---|
| rank_utility | 无固定 0–100 单位的潜在相对实力，越高越好 |
| estimated_rank_1_is_best | 当前比较集合内按 utility 降序，1 为最好 |
| rank_percentile | `100×(N-rank)/(N-1)`；最好 100，最差 0 |
| expected_pairwise_win_percent | 相对当前集合其他设备的平均预测胜率 |
| oof_expected_win_percent | held-out PC 相对另外 4 台开发 PC 的平均 OOF 胜率 |

名次、百分位和平均胜率都会随比较集合变化。跨批次追踪时应使用同一个锁定模型，并优先比较 `rank_utility` 或相对固定参考设备的胜率。

## 11. 四个版本的详细结果

### 11.1 Nested Score

| 版本 | MAE | RMSE | bias | 最大绝对误差 | Pearson | Spearman | Kendall |
|---|---:|---:|---:|---:|---:|---:|---:|
| A | 2.8145 | 3.5555 | +0.0852 | 6.2620 | 0.8840 | 1.0000 | 1.0000 |
| B | 3.2350 | 4.0966 | +0.2074 | 7.3736 | 0.8377 | 1.0000 | 1.0000 |
| C | 2.4982 | 3.2182 | -1.2582 | 5.7136 | 0.8837 | 0.9000 | 0.8000 |
| D | 2.7631 | 3.4556 | -1.2920 | 6.0715 | 0.8613 | 0.9000 | 0.8000 |

### 11.2 Nested Rank

| 版本 | 有向折预测正确 | Pair accuracy | Brier | Log loss | 设备级 Spearman | 设备级 Kendall | 设备级 pair accuracy |
|---|---:|---:|---:|---:|---:|---:|---:|
| A | 20/20 | 1.0000 | 0.0090 | 0.2051 | 1.0000 | 1.0000 | 1.0000 |
| B | 20/20 | 1.0000 | 0.0111 | 0.2208 | 1.0000 | 1.0000 | 1.0000 |
| C | 18/20 | 0.9000 | 0.0266 | 0.2359 | 0.9000 | 0.8000 | 0.9000 |
| D | 19/20 | 0.9500 | 0.0293 | 0.2497 | 0.9000 | 0.8000 | 0.9000 |

### 11.3 剩余 7 台 Score，全部为 posthoc

| 版本 | MAE | RMSE | bias | 最大绝对误差 | Pearson | Spearman | Kendall |
|---|---:|---:|---:|---:|---:|---:|---:|
| A | 2.2366 | 2.6570 | -2.2366 | 5.3717 | 0.9610 | 0.8929 | 0.8095 |
| B | 2.1465 | 2.6293 | -2.1465 | 4.8029 | 0.9563 | 0.8929 | 0.8095 |
| C | 1.9106 | 2.1156 | -1.9106 | 3.2997 | 0.9798 | 1.0000 | 1.0000 |
| D | 2.2276 | 2.4852 | -2.2276 | 3.8140 | 0.9741 | 1.0000 | 1.0000 |

四个版本在各自 7 台上全部是低估，所以 `bias=-MAE`。但 A/B 的 7 台与 C/D 的 7 台名单不同，不能把 A 的 `2.2366` 和 C 的 `1.9106` 当作同一测试集上的提升。

### 11.4 剩余 7 台 Rank，全部为 posthoc

| 版本 | 正确方向 | Pair accuracy | Brier | Log loss | 设备级 Spearman | 设备级 Kendall |
|---|---:|---:|---:|---:|---:|---:|
| A | 20/21 | 0.9524 | 0.0086 | 0.2633 | 0.9643 | 0.9048 |
| B | 20/21 | 0.9524 | 0.0130 | 0.2802 | 0.9643 | 0.9048 |
| C | 20/21 | 0.9524 | 0.0137 | 0.3276 | 0.9643 | 0.9048 |
| D | 20/21 | 0.9524 | 0.0162 | 0.3377 | 0.9643 | 0.9048 |

## 12. 输出文件逐类说明

### 12.1 A 主模型结果

目录：

```text
results/experiments/compact_positive/
```

#### 数据准备

`prepared_features.csv`

- 29 台设备的 19 特征准备表；
- 含全部设备和 `overall`，但真正训练范围由冻结 split 控制；
- clarity、lowfreq、fullness、edginess 已替换；
- 保留原始 `treble_1/treble_2`。

`prepared_features.manifest.json`

- 原始输入哈希；
- OOF/inductive 来源检查；
- 19 特征 schema；
- prepared 表哈希；
- `prediction_source_counts` 是子模型行数，不是设备数。

#### 候选比较

`score_candidate_comparison.csv`

- 每个 Score alpha/floor 候选的完整 5-PC LOO 汇总；
- `diagnostic_zero_floor` 标记不可选的 floor=0 诊断行；
- `selection_eligible` 表示是否进入最佳值容差；
- `selected_final` 是最终配置。

`score_candidate_oof.csv`

- 每个候选、每台开发 PC 的具体 LOO 预测；
- 共 `12 候选 × 5 台 = 60` 行；
- `residual=predicted-actual`。

`rank_candidate_comparison.csv`

- 每个 Rank 候选的方向、Brier、log loss 和设备级秩指标；
- 固定候选 LOO 用于调参，不是 nested 主结论。

`rank_candidate_oof_pairs.csv`

- 每个候选的 20 行 heldout–peer 概率；
- 共 `12×20=240` 行。

`rank_candidate_oof_devices.csv`

- 每个候选对 5 台 held-out PC 的设备级 expected-win；
- 共 `12×5=60` 行。

#### Nested 主验证

`score_nested_oof.csv`

- 每个外层 held-out PC 的真实分、预测分和残差；
- 是计算 `score_nested_pc_loo` 的直接证据。

`score_nested_selections.csv`

- 每个 outer 折内部选出的 alpha、floor；
- `inner_mae` 是该外折内部调参指标。

`rank_nested_oof_pairs.csv`

- 20 行真正外层留出的有向概率；
- 是 nested pair accuracy、Brier 和 log loss 的直接来源。

`rank_nested_oof_devices.csv`

- 五台设备的 OOF expected-win；
- 用于设备级 Spearman、Kendall 和 10 个无序对准确率。

`rank_nested_selections.csv`

- 每个 outer 折内部选出的 Rank 配置。

#### 系数

`final_coefficients.csv`

- 最终全开发集 Score/Rank 的质量特征系数；
- `coefficient_model_scale` 是下界实际施加的尺度；
- `coefficient_original_units` 是换回原列单位后的边际系数；
- `distance_from_floor` 表示离下界多远；
- `at_lower_bound` 表示是否贴下界；
- `optimizer_success` 必须为真。

`nested_coefficients.csv`

- 每个 outer 折模型的系数；
- 用于观察小样本下的选参和系数稳定性；
- 不是最终部署模型系数。

#### 历史 7 台事后明细

`external_posthoc_predictions.csv`

- 每台设备的 overall 真实/预测、残差、绝对误差；
- 集合内名次、百分位、utility 和平均胜率。

`external_posthoc_pairs.csv`

- 7 台内部 `C(7,2)=21` 个无序设备对；
- 含真实软目标、预测概率和方向。

#### 总结与锁

`validation_summary.json`

- 最重要的聚合结果入口；
- 最终候选；
- nested Score/Rank；
- 7 台 posthoc；
- 正系数审计；
- floor=0 等价审计；
- 相对未改正式模型的指标差。

`selected_score.selection_metric_value` 是完整 5-PC 固定候选 LOO 调参 MAE，不等于 `score_nested_pc_loo.mae`。Rank 同理。

`lock_manifest.json`

- 模型在计算 7 台事后指标前已经序列化；
- 模型哈希、锁定参数和未参与训练/选参的 7 台名单；
- 它是执行顺序证据，不是性能指标。

`baseline_equivalence.json`

- 检查 floor=0 精简实现是否与未改正式实现数值等价；
- 硬容差为 `1e-10`；
- 证明代码精简没有偷偷改变基线定义；
- 不证明正系数约束一定更好。

`metadata.json`

- 模型、准备表、manifest 和源码哈希；
- 绝对路径是生成机器路径，换机后以相对目录和哈希为准。

### 12.2 B/C/D 扩展目录

三个目录：

```text
results/experiments/compact_posthoc_extensions/current_five_predicted_treble/
results/experiments/compact_posthoc_extensions/representative_five_raw_treble/
results/experiments/compact_posthoc_extensions/representative_five_predicted_treble/
```

候选、nested、系数文件与 A 同名文件采用相同定义。

额外文件：

`final_prepared_features.csv`

- 该变体最终使用的完整 18/19 特征表；
- raw 版本保留两列 treble；
- predicted 版本使用一列预测 treble；
- 表中含所有设备，不表示所有标签进入训练。

`outer_fold_leakage_audit.csv`

- 每个 held-out PC 是否从 overall 拟合排除；
- 是否从 treble bridge 目标拟合排除；
- 每折训练设备数；
- 每折 bridge 入选方法。

两项 `heldout_absent_*` 必须全部为 `True`。

raw 版本没有 bridge，所以对应布尔值是平凡成立，不代表额外做了一次填充验证。

`remaining_pc_posthoc_predictions.csv`、`remaining_pc_posthoc_pairs.csv`

- 与 A 的 `external_posthoc_*` 同义；
- 由于新 5 台切分改变，所以名称改为 remaining PC。

`validation_summary.json`

- 变体名称、特征数；
- 最终参数；
- nested 和 remaining 7 台指标；
- 正系数审计；
- 最终开发集 treble bridge 方法和填充值；
- posthoc 使用警告。

`lock_manifest.json`

- 变体模型在 remaining 7 台指标计算前锁定；
- 三个扩展模型都明确标记为 analysis-only。

### 12.3 5 台选择文件

目录：

```text
data/experiments/compact_posthoc_extensions/
```

`representative_five_coverage_candidates.csv`

- 792 个组合的完整覆盖排序；
- 5 台名单；
- 平均、最大、RMS 最近距离和中心偏差。

`representative_five_selection_audit.json`

- 新旧名单和指标；
- 八个特征组；
- 相对改善百分比；
- 是否读取 overall/旧误差；
- 标签变异负对照。

相对改善计算：

```text
100 × (旧值 - 新值) / 旧值
```

所以中心偏差的 `-65.60%` 表示恶化。

`representative_pc_split_posthoc.json`

- 新 5/7 名单；
- 历史 strata 只作说明，不是选择约束；
- 明确标注不是新冻结测试。

`selection_lock.json`

- 在 B/C/D 结果产生前锁定新名单；
- 含输入、候选表和脚本哈希；
- `contains_model_or_remaining_pc_performance=false`。

### 12.4 treble 来源文件

目录：

```text
data/experiments/posthoc_treble_sensitivity/
```

`treble_values_and_provenance.csv`

- 29 台一行一设备；
- 直接 treble 百分位或历史 bridge 填充值；
- `prediction_se`、`prediction_sd`、来源和填值方法；
- 严格扩展运行会从中识别 25 台 observed 与 4 台 missing，再在每个折内重新 bridge。

`treble_imputation_candidate_cv.csv`

- 四个历史 bridge 候选的 LOO MAE、RMSE、bias、Spearman；
- 这些指标单位是 treble 百分位点，不是 overall 分数。

`treble_imputation_audit.json`

- bridge 输入、选择规则、训练设备、填充值；
- 是否使用 overall；
- 来源文件哈希和不确定度公式。

`submodel_predictions_with_treble.csv`

- 29 台 × 5 个 subdir；
- 保留 treble、置信区间、rank、coverage 等完整历史诊断。

`prediction_pc_submodels_with_treble.csv`

- 历史剩余 7 台 PC 的五个 subdir 子集。

### 12.5 新旧五台共同设备比较

目录：

```text
results/experiments/compact_posthoc_extensions/comparisons/
```

`*_common_device_metrics.json`

- 两套五台训练都未使用的共同四台；
- 分别计算 Score、Rank pair 和 Rank device 指标；
- 仍然是 posthoc。

`*_common_device_predictions.csv`

- 两个模型对同四台设备的真实/预测 overall、utility、集合内名次。

`*_common_device_pairs.csv`

- 四台设备的 6 个无序对；
- 两个模型概率并排比较。

`comparison_summary.json`

- A/B/C/D 集中比较；
- 新 5 台覆盖变化；
- 共同四台结果；
- 方法学警告。

其中：

```text
predicted_minus_raw = predicted 指标 - raw 指标
```

对 MAE、RMSE、Brier 和 log loss，正数表示恶化；对 accuracy，正数才表示改善。

### 12.6 日常新设备预测输出

`predict` 命令会生成：

`new_device_predictions.csv`

- 新设备的 `predicted_overall`；
- 与固定 5 台参考 PC 合并后的名次、百分位、utility 和平均胜率。

`combined_reference_rankings.csv`

- 新设备 + 固定 5 台参考 PC 的完整合并排名。

`new_vs_reference_probabilities.csv`

- 每台新设备相对每台参考 PC 的预测胜率；
- M 台新设备时共有 `M×5` 行。

`prediction_summary.json`

- 模型哈希、设备数、参考名单和输出路径；
- 若输入带 `overall`，还会给出可选评价，但不会自动获得冻结测试身份。

## 13. 如何复现

在解压后的包根目录运行。

### 13.1 安装依赖

```powershell
python -m pip install -r requirements.txt
```

### 13.2 重建 A 的 19 特征准备表

```powershell
python compact_positive\overall_quality_compact.py prepare
```

### 13.3 重训精简正系数主模型

```powershell
python compact_positive\overall_quality_compact.py train
```

该命令会完成候选比较、nested 验证、正系数模型锁定、floor=0 正式等价审计以及历史 7 台 posthoc 描述。

### 13.4 重跑 B/C/D

```powershell
python analysis\run_compact_posthoc_extensions.py
```

扩展默认读取 A 的：

```text
prepared_features.csv
validation_summary.json
overall_compact_positive_bundle.joblib
```

因此完整重建时应先运行 A 的 `prepare` 和 `train`，再运行扩展。包中已包含锁定结果，所以只想复核扩展时也可直接运行扩展命令。

### 13.5 查看 A 模型

```powershell
python compact_positive\overall_quality_compact.py inspect
```

## 14. 新 PC 如何预测

当前可直接部署的只有：

```text
models/experiments/compact_positive/overall_compact_positive_bundle.joblib
```

先准备三张规范表：

1. overall 特征表：`name + 22 个规范英文特征`，预测时可无 `overall`；
2. domain 表：`name,domain`，新设备为 `pc`；
3. submodel 表：每台四行 clarity/lowfreq/fullness/edginess，来源为 inductive。

准备：

```powershell
python compact_positive\overall_quality_compact.py prepare `
  --overall <新设备总体特征.csv> `
  --domains <新设备domain.csv> `
  --submodels <新设备subdir预测.csv> `
  --output <新设备prepared.csv>
```

预测：

```powershell
python compact_positive\overall_quality_compact.py predict `
  --prepared <新设备prepared.csv> `
  --model models\experiments\compact_positive\overall_compact_positive_bundle.joblib `
  --output-dir <预测输出目录>
```

新设备名称不能与模型保存的五台参考 PC 重名。

## 15. 为什么三个扩展模型不能直接部署

三个扩展 `.joblib` 都明确标记：

```text
analysis_only_not_deployment_ready = true
direct_compact_predict_command_supported = false
```

原因：

- 正式 `predict` 只接受 A 的 bundle 类型；
- B/D 是 18 特征，A 的入口固定为 19 特征；
- predicted-treble bridge 尚未序列化；
- 扩展脚本锁定的是历史 treble 来源文件哈希，只用于复现实验；
- 即使 C 有 19 特征，它仍是事后重选实验快照，没有获准的部署入口。

不要通过手工修改 bundle 类型或列名绕过这些限制。

如果未来确实要部署预测 treble，需要另行完成：

```text
bridge 模型序列化
+ 新数据 treble 来源校验
+ 18 特征专用 prepare
+ 18 特征专用 predict
+ 全新 PC 验证
```

## 16. 最终校验

本包在一个独立临时目录中按以下顺序完整运行：

```text
inspect
→ prepare
→ train
→ 三组扩展实验
→ 新 PC predict 命令冒烟测试
```

结果：

- 两个核心 Python 文件均通过编译；
- A 的模型、`validation_summary.json` 与包内锁定结果逐字节一致；
- B/C/D 三个模型和扩展 `comparison_summary.json` 逐字节一致；
- floor=0 与未改正式实现的数值等价审计通过；
- 新设备 prepare/predict 命令路径通过；
- 完整项目测试为 `18 passed`；
- 包内没有 `__pycache__`、`.pyc` 或重复 README。

详细记录见：

```text
verification/unified_package_verification.json
```

文件级完整性使用根目录 `SHA256SUMS.txt` 校验。

## 17. 最终方法学边界

1. A 是精简严格正系数主候选，不等于覆盖未改正式冻结模型本体。
2. 所有 12 台 PC 标签都已经在历史流程中被接触，任何重新划分的 7 台都不能恢复成新冻结外测。
3. A 对 B、C 对 D 是相同设备切分下的 treble pipeline 敏感性对照。
4. A 对 C、B 对 D 的 nested 设备集合不同，不能当成严格受控准确率竞赛。
5. 新 5 台只保证 X/SE 覆盖目标更好，不保证 overall 分数范围、Score 或 Rank 更好。
6. 共同四台比较对象相同，但只有 4 台且标签已查看，仍然是 posthoc。
7. 所有质量系数严格为正，不代表所有特征都得到数据强支持。
8. 当前样本很小，相关系数和单个错序对都可能明显改变汇总结果。
9. 真正决定新 5 台或预测 treble 是否值得升级，必须依靠未来完全未查看标签的新 PC。

## 18. 当前推荐

现有证据的优先级为：

```text
继续使用 A：原 5 + 原始 treble
↓
把 C：新 5 + 原始 treble 登记为未来新 PC 的预注册候选
↓
暂不启用 B/D 的预测 treble
↓
未来条件允许时，用全部 12 台 PC 训练最终部署候选，
并等待真正全新的 PC 做冻结验证
```

所有数字均来自包内真实模型运行结果，不是手工编造。
