#!/usr/bin/env python3
"""Run two isolated compact-positive post-hoc extensions.

The experiments are deliberately separated from the official frozen model:

1. replace raw treble_1/treble_2 with a fold-local predicted treble percentile;
2. select five PCs globally by label-free X/SE coverage, then run both
   raw-treble and predicted-treble variants.

No remaining-seven-PC metric is allowed to choose a split, coefficient floor,
regularization strength, or treble bridge.  Those metrics are descriptive
because all twelve PC labels have already been viewed historically.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterable

import joblib
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.base import clone
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from compact_positive import overall_quality_compact as compact  # noqa: E402


BASE_FEATURES = tuple(compact.FEATURES)
TREBLE_FEATURES = (
    "loudness",
    "dynamics_1_S",
    "dynamics_2",
    "treble__predicted_percentile",
    "balance",
    "spatial_1",
    "spatial_2",
    "spatial_3_S",
    "spatial_4_S",
    "spatial_5_S",
    "spatial_6_S",
    "artefacts_1_S",
    "artefacts_2",
    "artefacts_3_S",
    "clarity__predicted_percentile",
    "lowfreq__predicted_percentile",
    "fullness__predicted_percentile",
    "edginess__predicted_percentile",
)
TREBLE_BRIDGE_INPUTS = (
    "treble_1",
    "treble_2",
    "clarity__predicted_percentile",
    "lowfreq__predicted_percentile",
    "fullness__predicted_percentile",
    "edginess__predicted_percentile",
)
BASE_SUBDIRS = ("clarity", "lowfreq", "fullness", "edginess")

QUALITY_GROUPS = {
    "loudness": ("loudness",),
    "dynamics": ("dynamics_1_S", "dynamics_2"),
    "treble": ("treble_1", "treble_2"),
    "balance": ("balance",),
    "spatial": (
        "spatial_1",
        "spatial_2",
        "spatial_3_S",
        "spatial_4_S",
        "spatial_5_S",
        "spatial_6_S",
    ),
    "artefacts": ("artefacts_1_S", "artefacts_2", "artefacts_3_S"),
    "submodel_values": (
        "clarity__predicted_percentile",
        "lowfreq__predicted_percentile",
        "fullness__predicted_percentile",
        "edginess__predicted_percentile",
    ),
}

DEFAULT_BASE_PREPARED = (
    PROJECT_ROOT
    / "results"
    / "experiments"
    / "compact_positive"
    / "prepared_features.csv"
)
DEFAULT_SPLIT = PROJECT_ROOT / "data" / "real" / "frozen_pc_split.json"
DEFAULT_SUBMODELS = PROJECT_ROOT / "data" / "real" / "submodel_predictions.csv"
DEFAULT_TREBLE_VALUES = (
    PROJECT_ROOT
    / "data"
    / "experiments"
    / "posthoc_treble_sensitivity"
    / "treble_values_and_provenance.csv"
)
DEFAULT_TREBLE_AUDIT = (
    PROJECT_ROOT
    / "data"
    / "experiments"
    / "posthoc_treble_sensitivity"
    / "treble_imputation_audit.json"
)
DEFAULT_OUTPUT = (
    PROJECT_ROOT / "results" / "experiments" / "compact_posthoc_extensions"
)
DEFAULT_MODELS = (
    PROJECT_ROOT / "models" / "experiments" / "compact_posthoc_extensions"
)
DEFAULT_DATA_OUTPUT = (
    PROJECT_ROOT / "data" / "experiments" / "compact_posthoc_extensions"
)
EXPECTED_TREBLE_VALUES_SHA256 = (
    "ab6929013bf9c85cd7c21b7374be3f4909ef8e4bcf82093c603b6b458dd6af6a"
)
EXPECTED_TREBLE_AUDIT_SHA256 = (
    "c1eefc00b2f9b02229fe3419ba2b27b28ce339bc7c4a002e3627848557b0c81b"
)


Provider = Callable[[list[str]], pd.DataFrame]


def sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def frame_sha256(frame: pd.DataFrame, columns: Iterable[str]) -> str:
    payload = frame[list(columns)].to_csv(
        index=False,
        lineterminator="\n",
        na_rep="<NA>",
        float_format="%.17g",
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def write_csv(frame: pd.DataFrame, path: str | Path) -> Path:
    return compact._write_csv(frame, path)


def write_json(payload: dict[str, Any], path: str | Path) -> Path:
    return compact._write_json(compact._json_number(payload), path)


@contextmanager
def feature_schema(features: tuple[str, ...]):
    previous = compact.FEATURES
    compact.FEATURES = tuple(features)
    try:
        yield
    finally:
        compact.FEATURES = previous


class ConstantProvider:
    def __init__(self, frame: pd.DataFrame):
        self.frame = frame.copy()

    def __call__(self, training_names: list[str]) -> pd.DataFrame:
        del training_names
        return self.frame

    def audit(self, training_names: list[str]) -> dict[str, Any]:
        return {
            "kind": "raw_treble_no_bridge",
            "training_names": list(training_names),
        }


class FoldLocalTrebleProvider:
    """Build one 18-feature table using only current-fold bridge targets."""

    def __init__(self, base: pd.DataFrame, treble_values_path: str | Path):
        if sha256(treble_values_path) != EXPECTED_TREBLE_VALUES_SHA256:
            raise ValueError("Treble provenance does not match the audited file")
        values = pd.read_csv(treble_values_path, encoding="utf-8-sig")
        required = {
            "name",
            "predicted_percentile",
            "treble_value_origin",
            "prediction_source",
        }
        missing = sorted(required - set(values.columns))
        if missing:
            raise ValueError(f"Treble provenance is missing columns: {missing}")
        values = values.copy()
        values["name"] = values["name"].astype(str)
        values["predicted_percentile"] = pd.to_numeric(
            values["predicted_percentile"], errors="raise"
        )
        if values["name"].duplicated().any():
            raise ValueError("Treble provenance names must be unique")
        if set(values["name"]) != set(base["name"]):
            raise ValueError("Treble provenance must cover all 29 devices")
        if (
            ~values["predicted_percentile"].between(0.0, 100.0)
            | ~np.isfinite(values["predicted_percentile"])
        ).any():
            raise ValueError("Treble percentiles must be finite and in [0,100]")
        domain_lookup = base.set_index("name")["domain"].astype(str).to_dict()
        unsafe_sources: list[str] = []
        for row in values.itertuples(index=False):
            domain = domain_lookup[str(row.name)]
            allowed = (
                {"inductive"}
                if domain == "pc" or str(row.name) == "ipadPro2022-"
                else {"oof"}
            )
            if str(row.prediction_source) not in allowed:
                unsafe_sources.append(
                    f"{row.name}={row.prediction_source}, allowed={sorted(allowed)}"
                )
        if unsafe_sources:
            raise ValueError("Unsafe treble prediction sources: " + "; ".join(unsafe_sources))
        observed = values[values["treble_value_origin"].eq("observed_submodel")]
        imputed = values[values["treble_value_origin"].ne("observed_submodel")]
        expected_missing = {"air13-", "air15-", "pro14-", "pro16-"}
        if set(imputed["name"]) != expected_missing:
            raise ValueError(
                "Unexpected missing treble devices: "
                f"{sorted(set(imputed['name']))}"
            )
        self.base = base.copy()
        self.observed = observed.set_index("name")["predicted_percentile"].astype(float)
        self.missing_names = [
            name for name in self.base["name"].astype(str) if name in expected_missing
        ]
        self.cache: dict[tuple[str, ...], pd.DataFrame] = {}
        self.audits: dict[tuple[str, ...], dict[str, Any]] = {}

    @staticmethod
    def _candidate_study(
        x: pd.DataFrame, y: np.ndarray
    ) -> tuple[str, pd.DataFrame]:
        median_prediction = np.asarray(
            [np.median(np.delete(y, index)) for index in range(len(y))],
            dtype=float,
        )
        candidate_models = {
            "ridge_other4_alpha10": (
                make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
                list(TREBLE_BRIDGE_INPUTS[2:]),
            ),
            "ridge_all6_alpha10": (
                make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
                list(TREBLE_BRIDGE_INPUTS),
            ),
            "knn_all6_k5": (
                make_pipeline(
                    StandardScaler(),
                    KNeighborsRegressor(n_neighbors=5, weights="uniform"),
                ),
                list(TREBLE_BRIDGE_INPUTS),
            ),
        }
        rows: list[dict[str, Any]] = []

        def add_metrics(method: str, prediction: np.ndarray) -> None:
            residual = np.asarray(prediction, dtype=float) - y
            rows.append(
                {
                    "method": method,
                    "mae": float(np.mean(np.abs(residual))),
                    "rmse": float(np.sqrt(np.mean(residual**2))),
                    "bias": float(np.mean(residual)),
                }
            )

        add_metrics("development_median", median_prediction)
        for method, (model, columns) in candidate_models.items():
            prediction = np.clip(
                cross_val_predict(
                    clone(model),
                    x[columns],
                    y,
                    cv=LeaveOneOut(),
                ),
                0.0,
                100.0,
            )
            add_metrics(method, prediction)
        comparison = pd.DataFrame(rows).sort_values(
            ["mae", "rmse", "method"], ignore_index=True
        )
        best_mae = float(comparison["mae"].min())
        ridge_row = comparison[
            comparison["method"].eq("ridge_all6_alpha10")
        ].iloc[0]
        selected = (
            "ridge_all6_alpha10"
            if float(ridge_row["mae"]) <= best_mae + 0.5
            else str(comparison.iloc[0]["method"])
        )
        comparison["selected"] = comparison["method"].eq(selected)
        return selected, comparison

    @staticmethod
    def _predict_missing(
        method: str,
        x_train: pd.DataFrame,
        y_train: np.ndarray,
        x_missing: pd.DataFrame,
    ) -> np.ndarray:
        if method == "development_median":
            return np.full(len(x_missing), np.median(y_train), dtype=float)
        if method == "ridge_other4_alpha10":
            columns = list(TREBLE_BRIDGE_INPUTS[2:])
            model = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
        elif method == "ridge_all6_alpha10":
            columns = list(TREBLE_BRIDGE_INPUTS)
            model = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
        elif method == "knn_all6_k5":
            columns = list(TREBLE_BRIDGE_INPUTS)
            model = make_pipeline(
                StandardScaler(),
                KNeighborsRegressor(n_neighbors=5, weights="uniform"),
            )
        else:
            raise ValueError(f"Unknown treble bridge method: {method}")
        return model.fit(x_train[columns], y_train).predict(x_missing[columns])

    def __call__(self, training_names: list[str]) -> pd.DataFrame:
        key = tuple(training_names)
        if key in self.cache:
            return self.cache[key]
        indexed = self.base.set_index("name", drop=False)
        unknown = sorted(set(training_names) - set(indexed.index))
        if unknown:
            raise ValueError(f"Unknown bridge-training devices: {unknown}")
        fit_names = [name for name in training_names if name in self.observed.index]
        if len(fit_names) < 10:
            raise ValueError("Treble bridge has too few observed training devices")
        x_train = indexed.loc[fit_names, list(TREBLE_BRIDGE_INPUTS)]
        y_train = self.observed.loc[fit_names].to_numpy(dtype=float)
        if not np.isfinite(x_train.to_numpy(dtype=float)).all():
            raise ValueError("Treble bridge inputs must be finite")
        selected_method, candidate_comparison = self._candidate_study(
            x_train, y_train
        )
        predicted_missing = np.clip(
            self._predict_missing(
                selected_method,
                x_train,
                y_train,
                indexed.loc[
                    self.missing_names, list(TREBLE_BRIDGE_INPUTS)
                ],
            ),
            0.0,
            100.0,
        )
        treble = self.observed.copy()
        for name, value in zip(
            self.missing_names, predicted_missing, strict=True
        ):
            treble.loc[name] = float(value)
        result = self.base[
            ["name", "domain", *[f for f in BASE_FEATURES if f not in {"treble_1", "treble_2"}], "overall"]
        ].copy()
        insert_at = result.columns.get_loc("balance")
        result.insert(
            insert_at,
            "treble__predicted_percentile",
            result["name"].map(treble).to_numpy(dtype=float),
        )
        result = result[["name", "domain", *TREBLE_FEATURES, "overall"]]
        self.cache[key] = result
        self.audits[key] = {
            "kind": "fold_local_selected_treble_bridge",
            "selection_rule": (
                "prefer ridge_all6_alpha10 when its training-only LOO MAE is "
                "within 0.5 of best; otherwise choose best MAE/RMSE/method"
            ),
            "selected_method": selected_method,
            "candidate_comparison": candidate_comparison.to_dict(
                orient="records"
            ),
            "training_names": list(training_names),
            "observed_treble_fit_names": fit_names,
            "n_observed_treble_fit_devices": int(len(fit_names)),
            "missing_treble_predictions": {
                name: float(value)
                for name, value in zip(
                    self.missing_names, predicted_missing, strict=True
                )
            },
            "overall_used": False,
        }
        return result

    def audit(self, training_names: list[str]) -> dict[str, Any]:
        self(training_names)
        return self.audits[tuple(training_names)]


def _robust_standardize(frame: pd.DataFrame) -> pd.DataFrame:
    result = pd.DataFrame(index=frame.index)
    for column in frame.columns:
        values = frame[column].to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise ValueError(
                f"Representative selection does not permit missing {column}"
            )
        center, scale, _ = compact.robust_location_scale(values)
        result[column] = (values - center) / scale
    return result


def select_representative_five(
    base_frame: pd.DataFrame,
    split_payload: dict[str, Any],
    submodels_path: str | Path,
) -> tuple[list[str], pd.DataFrame, dict[str, Any]]:
    """Choose five of twelve PCs globally using X/SE only."""

    pc_names = (
        base_frame.loc[base_frame["domain"].eq("pc"), "name"]
        .astype(str)
        .tolist()
    )
    if len(pc_names) != 12 or len(set(pc_names)) != 12:
        raise ValueError("Expected exactly twelve unique PCs")
    features = (
        base_frame.set_index("name")
        .loc[pc_names, list(BASE_FEATURES)]
        .astype(float)
    )
    submodels = pd.read_csv(
        submodels_path,
        encoding="utf-8-sig",
        usecols=["name", "subdir", "prediction_se"],
    )
    selected_uncertainty = submodels[
        submodels["name"].astype(str).isin(pc_names)
        & submodels["subdir"].astype(str).isin(BASE_SUBDIRS)
    ].copy()
    selected_uncertainty["prediction_se"] = pd.to_numeric(
        selected_uncertainty["prediction_se"], errors="raise"
    )
    if selected_uncertainty[["name", "subdir"]].duplicated().any():
        raise ValueError("Uncertainty source contains duplicate name + subdir")
    uncertainty = (
        selected_uncertainty.pivot(
            index="name", columns="subdir", values="prediction_se"
        )
        .loc[pc_names, list(BASE_SUBDIRS)]
        .astype(float)
    )
    if features.isna().any().any() or uncertainty.isna().any().any():
        raise ValueError("This locked selector requires complete 12-PC X and SE")

    z_features = _robust_standardize(features)
    z_uncertainty = _robust_standardize(uncertainty)
    blocks = [
        z_features[list(columns)].to_numpy(dtype=float)
        for columns in QUALITY_GROUPS.values()
    ]
    blocks.append(z_uncertainty.to_numpy(dtype=float))
    n_devices = len(pc_names)
    distances_squared = np.zeros((n_devices, n_devices), dtype=float)
    for block in blocks:
        difference = block[:, None, :] - block[None, :, :]
        distances_squared += np.mean(difference**2, axis=2) / len(blocks)
    distances = np.sqrt(distances_squared)
    name_to_index = {name: index for index, name in enumerate(pc_names)}

    rows: list[dict[str, Any]] = []
    for combination in itertools.combinations(pc_names, 5):
        selected_indices = [name_to_index[name] for name in combination]
        nearest = distances[:, selected_indices].min(axis=1)
        group_centroid_squared = []
        for block in blocks:
            difference = (
                block[selected_indices].mean(axis=0) - block.mean(axis=0)
            )
            group_centroid_squared.append(float(np.mean(difference**2)))
        rows.append(
            {
                "selected_devices": "|".join(combination),
                **{
                    f"selected_{index + 1}": name
                    for index, name in enumerate(combination)
                },
                "mean_nearest_distance": float(np.mean(nearest)),
                "max_nearest_distance": float(np.max(nearest)),
                "rms_nearest_distance": float(np.sqrt(np.mean(nearest**2))),
                "centroid_gap": float(
                    np.sqrt(np.mean(group_centroid_squared))
                ),
            }
        )
    candidates = pd.DataFrame(rows)
    candidates["sort_mean"] = candidates["mean_nearest_distance"].round(12)
    candidates["sort_max"] = candidates["max_nearest_distance"].round(12)
    candidates["sort_rms"] = candidates["rms_nearest_distance"].round(12)
    candidates["sort_centroid"] = candidates["centroid_gap"].round(12)
    sort_columns = [
        "sort_mean",
        "sort_max",
        "sort_rms",
        "sort_centroid",
        *[f"selected_{index}" for index in range(1, 6)],
    ]
    candidates = candidates.sort_values(sort_columns, ignore_index=True)
    candidates.insert(0, "coverage_rank", np.arange(1, len(candidates) + 1))
    candidates = candidates.drop(
        columns=["sort_mean", "sort_max", "sort_rms", "sort_centroid"]
    )
    selected = [
        str(candidates.iloc[0][f"selected_{index}"])
        for index in range(1, 6)
    ]
    current = [str(name) for name in split_payload["pc_development"]]
    selected_row = candidates.iloc[0]
    current_mask = candidates["selected_devices"].map(
        lambda text: set(str(text).split("|")) == set(current)
    )
    if int(current_mask.sum()) != 1:
        raise RuntimeError("Could not locate the current five-PC selection")
    current_row = candidates[current_mask].iloc[0]
    summary = {
        "status": "locked_before_model_results",
        "selector": (
            "global choose(12,5); robust column scaling; eight equal X/SE "
            "groups; minimum mean nearest distance"
        ),
        "overall_column_loaded_or_used": False,
        "old_external_prediction_or_error_used": False,
        "historical_overall_strata_used_as_constraint": False,
        "n_candidates": int(len(candidates)),
        "selected_devices": selected,
        "current_devices": current,
        "selected_metrics": {
            key: float(selected_row[key])
            for key in (
                "mean_nearest_distance",
                "max_nearest_distance",
                "rms_nearest_distance",
                "centroid_gap",
            )
        },
        "current_metrics": {
            "coverage_rank": int(current_row["coverage_rank"]),
            **{
                key: float(current_row[key])
                for key in (
                    "mean_nearest_distance",
                    "max_nearest_distance",
                    "rms_nearest_distance",
                    "centroid_gap",
                )
            },
        },
        "relative_improvement_percent": {
            key: float(
                100.0
                * (float(current_row[key]) - float(selected_row[key]))
                / float(current_row[key])
            )
            for key in (
                "mean_nearest_distance",
                "max_nearest_distance",
                "rms_nearest_distance",
                "centroid_gap",
            )
        },
        "quality_groups": {
            name: list(columns) for name, columns in QUALITY_GROUPS.items()
        },
        "uncertainty_group": [
            f"{subdir}__prediction_se" for subdir in BASE_SUBDIRS
        ],
        "tie_break_round_decimals": 12,
    }
    return selected, candidates, summary


def evaluate_score_spec(
    provider: Provider,
    tablet_names: list[str],
    pc_names: list[str],
    spec: dict[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for heldout in pc_names:
        training_names = tablet_names + [
            name for name in pc_names if name != heldout
        ]
        frame = provider(training_names)
        training = compact.subset(frame, training_names)
        test = compact.subset(frame, [heldout])
        model = compact.fit_score_model(
            training,
            alpha=float(spec["alpha"]),
            coefficient_floor=float(spec["coefficient_floor"]),
        )
        prediction = float(compact.predict_score(model, test)[0])
        actual = float(test["overall"].iloc[0])
        rows.append(
            {
                "name": heldout,
                "actual_overall": actual,
                "predicted_overall": prediction,
                "residual": prediction - actual,
                "selected_spec": spec["spec"],
            }
        )
    return pd.DataFrame(rows)


def compare_score_candidates(
    provider: Provider,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    summaries: list[dict[str, Any]] = []
    outputs: list[pd.DataFrame] = []
    for spec in candidates:
        fold = evaluate_score_spec(provider, tablet_names, pc_names, spec)
        summaries.append(
            {
                **spec,
                **compact.regression_metrics(
                    fold["actual_overall"], fold["predicted_overall"]
                ),
            }
        )
        outputs.append(fold.assign(candidate_spec=spec["spec"]))
    return (
        pd.DataFrame(summaries).sort_values(
            ["mae", "rmse", "coefficient_floor", "alpha"],
            ignore_index=True,
        ),
        pd.concat(outputs, ignore_index=True),
    )


def nested_score_validation(
    provider: Provider,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    predictions: list[dict[str, Any]] = []
    selections: list[dict[str, Any]] = []
    coefficient_rows: list[pd.DataFrame] = []
    for outer_heldout in pc_names:
        inner_pcs = [name for name in pc_names if name != outer_heldout]
        comparison, _ = compare_score_candidates(
            provider, tablet_names, inner_pcs, candidates
        )
        selected = compact._select_positive_candidate(
            comparison, metric="mae", tolerance=compact.SCORE_TOLERANCE
        )
        training_names = tablet_names + inner_pcs
        frame = provider(training_names)
        training = compact.subset(frame, training_names)
        test = compact.subset(frame, [outer_heldout])
        model = compact.fit_score_model(
            training,
            alpha=selected["alpha"],
            coefficient_floor=selected["coefficient_floor"],
        )
        prediction = float(compact.predict_score(model, test)[0])
        actual = float(test["overall"].iloc[0])
        predictions.append(
            {
                "name": outer_heldout,
                "actual_overall": actual,
                "predicted_overall": prediction,
                "residual": prediction - actual,
                "selected_spec": selected["spec"],
            }
        )
        selections.append(
            {
                "outer_heldout": outer_heldout,
                "selected_spec": selected["spec"],
                "selected_alpha": selected["alpha"],
                "selected_coefficient_floor": selected["coefficient_floor"],
                "inner_mae": selected["selection_metric_value"],
                "inner_best_positive_mae": selected["best_positive_metric"],
            }
        )
        coefficient_rows.append(
            compact.score_coefficient_frame(
                model, stage="nested_outer", outer_heldout=outer_heldout
            )
        )
    return (
        pd.DataFrame(predictions),
        pd.DataFrame(selections),
        pd.concat(coefficient_rows, ignore_index=True),
    )


def rank_fold_predictions(
    provider: Provider,
    tablet_names: list[str],
    pc_names: list[str],
    spec: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    pair_rows: list[dict[str, Any]] = []
    device_rows: list[dict[str, Any]] = []
    for heldout_name in pc_names:
        peer_names = [name for name in pc_names if name != heldout_name]
        training_names = tablet_names + peer_names
        frame = provider(training_names)
        training = compact.subset(frame, training_names)
        heldout = compact.subset(frame, [heldout_name])
        peers = compact.subset(frame, peer_names)
        model = compact.fit_rank_model(
            training,
            alpha=float(spec["alpha"]),
            coefficient_floor=float(spec["coefficient_floor"]),
        )
        heldout_utility = float(compact.rank_utility(model, heldout)[0])
        peer_utilities = compact.rank_utility(model, peers)
        probabilities = expit(heldout_utility - peer_utilities)
        heldout_score = float(heldout["overall"].iloc[0])
        targets = compact.preference_probability(
            heldout_score - peers["overall"].to_numpy(dtype=float)
        )
        for index, peer_name in enumerate(peer_names):
            pair_rows.append(
                {
                    "heldout_name": heldout_name,
                    "peer_name": peer_name,
                    "heldout_overall": heldout_score,
                    "peer_overall": float(peers["overall"].iloc[index]),
                    "target_probability_heldout_better": float(targets[index]),
                    "predicted_probability_heldout_better": float(
                        probabilities[index]
                    ),
                    "selected_spec": spec["spec"],
                }
            )
        device_rows.append(
            {
                "name": heldout_name,
                "actual_overall": heldout_score,
                "oof_expected_win_percent": float(100.0 * np.mean(probabilities)),
                "selected_spec": spec["spec"],
            }
        )
    return pd.DataFrame(pair_rows), pd.DataFrame(device_rows)


def compare_rank_candidates(
    provider: Provider,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    summaries: list[dict[str, Any]] = []
    pair_outputs: list[pd.DataFrame] = []
    device_outputs: list[pd.DataFrame] = []
    for spec in candidates:
        pairs, devices = rank_fold_predictions(
            provider, tablet_names, pc_names, spec
        )
        summaries.append(
            {
                **spec,
                **compact.soft_pair_metrics(
                    pairs["target_probability_heldout_better"],
                    pairs["predicted_probability_heldout_better"],
                ),
                **compact.device_rank_metrics(
                    devices["actual_overall"],
                    devices["oof_expected_win_percent"],
                ),
            }
        )
        pair_outputs.append(pairs.assign(candidate_spec=spec["spec"]))
        device_outputs.append(devices.assign(candidate_spec=spec["spec"]))
    return (
        pd.DataFrame(summaries).sort_values(
            [
                "pairwise_log_loss",
                "pairwise_brier",
                "coefficient_floor",
                "alpha",
            ],
            ignore_index=True,
        ),
        pd.concat(pair_outputs, ignore_index=True),
        pd.concat(device_outputs, ignore_index=True),
    )


def nested_rank_validation(
    provider: Provider,
    tablet_names: list[str],
    pc_names: list[str],
    candidates: list[dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    outer_pairs: list[pd.DataFrame] = []
    outer_devices: list[dict[str, Any]] = []
    selections: list[dict[str, Any]] = []
    coefficient_rows: list[pd.DataFrame] = []
    for outer_heldout in pc_names:
        inner_pcs = [name for name in pc_names if name != outer_heldout]
        comparison, _, _ = compare_rank_candidates(
            provider, tablet_names, inner_pcs, candidates
        )
        selected = compact._select_positive_candidate(
            comparison,
            metric="pairwise_log_loss",
            tolerance=compact.RANK_TOLERANCE,
        )
        training_names = tablet_names + inner_pcs
        frame = provider(training_names)
        training = compact.subset(frame, training_names)
        heldout = compact.subset(frame, [outer_heldout])
        peers = compact.subset(frame, inner_pcs)
        model = compact.fit_rank_model(
            training,
            alpha=selected["alpha"],
            coefficient_floor=selected["coefficient_floor"],
        )
        heldout_utility = float(compact.rank_utility(model, heldout)[0])
        peer_utilities = compact.rank_utility(model, peers)
        probabilities = expit(heldout_utility - peer_utilities)
        heldout_score = float(heldout["overall"].iloc[0])
        targets = compact.preference_probability(
            heldout_score - peers["overall"].to_numpy(dtype=float)
        )
        rows: list[dict[str, Any]] = []
        for index, peer_name in enumerate(inner_pcs):
            rows.append(
                {
                    "heldout_name": outer_heldout,
                    "peer_name": peer_name,
                    "heldout_overall": heldout_score,
                    "peer_overall": float(peers["overall"].iloc[index]),
                    "target_probability_heldout_better": float(targets[index]),
                    "predicted_probability_heldout_better": float(
                        probabilities[index]
                    ),
                    "selected_spec": selected["spec"],
                }
            )
        outer_pairs.append(pd.DataFrame(rows))
        outer_devices.append(
            {
                "name": outer_heldout,
                "actual_overall": heldout_score,
                "oof_expected_win_percent": float(100.0 * np.mean(probabilities)),
                "selected_spec": selected["spec"],
            }
        )
        selections.append(
            {
                "outer_heldout": outer_heldout,
                "selected_spec": selected["spec"],
                "selected_alpha": selected["alpha"],
                "selected_coefficient_floor": selected["coefficient_floor"],
                "inner_pairwise_log_loss": selected["selection_metric_value"],
                "inner_best_positive_pairwise_log_loss": selected[
                    "best_positive_metric"
                ],
            }
        )
        coefficient_rows.append(
            compact.rank_coefficient_frame(
                model, stage="nested_outer", outer_heldout=outer_heldout
            )
        )
    return (
        pd.concat(outer_pairs, ignore_index=True),
        pd.DataFrame(outer_devices),
        pd.DataFrame(selections),
        pd.concat(coefficient_rows, ignore_index=True),
    )


def _provider_outer_audit(
    provider: ConstantProvider | FoldLocalTrebleProvider,
    tablet_names: list[str],
    pc_names: list[str],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for heldout in pc_names:
        training_names = tablet_names + [
            name for name in pc_names if name != heldout
        ]
        audit = provider.audit(training_names)
        fit_names = audit.get("observed_treble_fit_names", [])
        rows.append(
            {
                "outer_heldout": heldout,
                "heldout_absent_from_overall_training": heldout
                not in training_names,
                "heldout_absent_from_treble_bridge_fit": heldout
                not in fit_names,
                "n_overall_training_devices": len(training_names),
                "n_observed_treble_bridge_fit_devices": len(fit_names),
                "treble_bridge_kind": audit["kind"],
                "treble_bridge_selected_method": audit.get(
                    "selected_method", ""
                ),
            }
        )
    return pd.DataFrame(rows)


def run_variant(
    *,
    name: str,
    features: tuple[str, ...],
    provider: ConstantProvider | FoldLocalTrebleProvider,
    tablet_names: list[str],
    pc_development: list[str],
    pc_posthoc: list[str],
    output_dir: str | Path,
    model_path: str | Path,
    provenance: dict[str, Any],
) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    model_target = Path(model_path)
    model_target.parent.mkdir(parents=True, exist_ok=True)

    with feature_schema(features):
        score_candidates = compact.candidate_grid(
            "score", compact.DEFAULT_SCORE_ALPHAS, compact.DEFAULT_SCORE_FLOORS
        )
        rank_candidates = compact.candidate_grid(
            "rank", compact.DEFAULT_RANK_ALPHAS, compact.DEFAULT_RANK_FLOORS
        )
        score_comparison, score_candidate_oof = compare_score_candidates(
            provider, tablet_names, pc_development, score_candidates
        )
        selected_score = compact._select_positive_candidate(
            score_comparison,
            metric="mae",
            tolerance=compact.SCORE_TOLERANCE,
        )
        score_comparison = compact._mark_selection(
            score_comparison,
            selected_score,
            metric="mae",
            tolerance=compact.SCORE_TOLERANCE,
        )
        (
            rank_comparison,
            rank_candidate_pairs,
            rank_candidate_devices,
        ) = compare_rank_candidates(
            provider, tablet_names, pc_development, rank_candidates
        )
        selected_rank = compact._select_positive_candidate(
            rank_comparison,
            metric="pairwise_log_loss",
            tolerance=compact.RANK_TOLERANCE,
        )
        rank_comparison = compact._mark_selection(
            rank_comparison,
            selected_rank,
            metric="pairwise_log_loss",
            tolerance=compact.RANK_TOLERANCE,
        )
        (
            score_nested,
            score_nested_selections,
            score_nested_coefficients,
        ) = nested_score_validation(
            provider, tablet_names, pc_development, score_candidates
        )
        (
            rank_nested_pairs,
            rank_nested_devices,
            rank_nested_selections,
            rank_nested_coefficients,
        ) = nested_rank_validation(
            provider, tablet_names, pc_development, rank_candidates
        )

        development_names = tablet_names + pc_development
        final_frame = provider(development_names)
        development = compact.subset(final_frame, development_names)
        posthoc = compact.subset(final_frame, pc_posthoc)
        score_model = compact.fit_score_model(
            development,
            alpha=selected_score["alpha"],
            coefficient_floor=selected_score["coefficient_floor"],
        )
        rank_model = compact.fit_rank_model(
            development,
            alpha=selected_rank["alpha"],
            coefficient_floor=selected_rank["coefficient_floor"],
        )
        coefficients = pd.concat(
            [
                compact.score_coefficient_frame(
                    score_model, stage="final_locked"
                ),
                compact.rank_coefficient_frame(
                    rank_model, stage="final_locked"
                ),
            ],
            ignore_index=True,
        )
        if not coefficients["coefficient_model_scale"].gt(0.0).all():
            raise RuntimeError(f"{name} contains a non-positive coefficient")

        bundle = {
            "schema_version": 1,
            "kind": "compact_positive_posthoc_extension_bundle",
            "experiment": name,
            "analysis_only_not_deployment_ready": True,
            "direct_compact_predict_command_supported": False,
            "treble_bridge_serialized": False,
            "features": list(features),
            "score_model": score_model,
            "rank_model": rank_model,
            "selected_score": selected_score,
            "selected_rank": selected_rank,
            "pc_reference": compact._frame_to_state(
                compact.subset(final_frame, pc_development)
            ),
            "training_scope": {
                "tablet_development": tablet_names,
                "pc_development": pc_development,
                "pc_posthoc_only": pc_posthoc,
            },
            "data_hashes": {
                "development_training_table_sha256": frame_sha256(
                    development, ["name", "domain", *features, "overall"]
                ),
                "all_device_feature_only_sha256": frame_sha256(
                    final_frame, ["name", "domain", *features]
                ),
            },
            "provenance": provenance,
        }
        joblib.dump(bundle, model_target)
        model_sha = sha256(model_target)
        lock_manifest = {
            "status": "locked_before_posthoc_metrics",
            "experiment": name,
            "model_path": str(model_target.resolve()),
            "model_sha256": model_sha,
            "selected_score": selected_score,
            "selected_rank": selected_rank,
            "pc_posthoc_labels_excluded_from_fit_and_selection": pc_posthoc,
            "warning": (
                "All twelve PC labels were already seen historically; remaining-PC "
                "metrics are posthoc descriptions, not a fresh frozen test."
            ),
        }
        write_json(lock_manifest, output / "lock_manifest.json")

        # Post-lock description only.
        score_posthoc_prediction = compact.predict_score(score_model, posthoc)
        score_posthoc_metrics = compact.regression_metrics(
            posthoc["overall"], score_posthoc_prediction
        )
        (
            posthoc_rankings,
            posthoc_pairs,
            posthoc_pair_metrics,
            posthoc_device_metrics,
        ) = compact._external_rank_evaluation(rank_model, posthoc)
        posthoc_predictions = posthoc_rankings.merge(
            pd.DataFrame(
                {
                    "name": posthoc["name"],
                    "predicted_overall": score_posthoc_prediction,
                    "actual_overall": posthoc["overall"],
                    "score_residual": score_posthoc_prediction
                    - posthoc["overall"].to_numpy(dtype=float),
                }
            ),
            on="name",
            how="left",
            validate="one_to_one",
        )
        posthoc_predictions["score_abs_error"] = posthoc_predictions[
            "score_residual"
        ].abs()

        score_nested_metrics = compact.regression_metrics(
            score_nested["actual_overall"], score_nested["predicted_overall"]
        )
        rank_nested_pair_metrics = compact.soft_pair_metrics(
            rank_nested_pairs["target_probability_heldout_better"],
            rank_nested_pairs["predicted_probability_heldout_better"],
        )
        rank_nested_device_metrics = compact.device_rank_metrics(
            rank_nested_devices["actual_overall"],
            rank_nested_devices["oof_expected_win_percent"],
        )
        outer_audit = _provider_outer_audit(
            provider, tablet_names, pc_development
        )
        if not outer_audit[
            [
                "heldout_absent_from_overall_training",
                "heldout_absent_from_treble_bridge_fit",
            ]
        ].all().all():
            raise RuntimeError(f"{name} failed its outer-fold leakage audit")
        final_bridge_audit = provider.audit(development_names)

        summary = {
            "status": "posthoc_experiment_completed",
            "experiment": name,
            "model_sha256": model_sha,
            "n_features": len(features),
            "selected_score": selected_score,
            "selected_rank": selected_rank,
            "score_nested_pc_loo": score_nested_metrics,
            "rank_nested_pc_loo_pairs": rank_nested_pair_metrics,
            "rank_nested_pc_loo_devices": rank_nested_device_metrics,
            "remaining_pc_score_posthoc_only": score_posthoc_metrics,
            "remaining_pc_rank_pairs_posthoc_only": posthoc_pair_metrics,
            "remaining_pc_rank_devices_posthoc_only": posthoc_device_metrics,
            "final_coefficient_audit": {
                model_name: {
                    "n_features": int(len(group)),
                    "minimum_model_scale_coefficient": float(
                        group["coefficient_model_scale"].min()
                    ),
                    "configured_floor": float(
                        group["configured_min_coefficient"].iloc[0]
                    ),
                    "n_at_lower_bound": int(group["at_lower_bound"].sum()),
                }
                for model_name, group in coefficients.groupby("model")
            },
            "fold_local_treble_bridge": final_bridge_audit,
            "external_use_policy": lock_manifest["warning"],
        }

        write_csv(score_comparison, output / "score_candidate_comparison.csv")
        write_csv(score_candidate_oof, output / "score_candidate_oof.csv")
        write_csv(score_nested, output / "score_nested_oof.csv")
        write_csv(
            score_nested_selections, output / "score_nested_selections.csv"
        )
        write_csv(rank_comparison, output / "rank_candidate_comparison.csv")
        write_csv(
            rank_candidate_pairs, output / "rank_candidate_oof_pairs.csv"
        )
        write_csv(
            rank_candidate_devices, output / "rank_candidate_oof_devices.csv"
        )
        write_csv(rank_nested_pairs, output / "rank_nested_oof_pairs.csv")
        write_csv(
            rank_nested_devices, output / "rank_nested_oof_devices.csv"
        )
        write_csv(
            rank_nested_selections, output / "rank_nested_selections.csv"
        )
        write_csv(
            pd.concat(
                [score_nested_coefficients, rank_nested_coefficients],
                ignore_index=True,
            ),
            output / "nested_coefficients.csv",
        )
        write_csv(coefficients, output / "final_coefficients.csv")
        write_csv(final_frame, output / "final_prepared_features.csv")
        write_csv(
            outer_audit, output / "outer_fold_leakage_audit.csv"
        )
        write_csv(
            posthoc_predictions, output / "remaining_pc_posthoc_predictions.csv"
        )
        write_csv(
            posthoc_pairs, output / "remaining_pc_posthoc_pairs.csv"
        )
        write_json(summary, output / "validation_summary.json")
        return {
            "summary": compact._json_number(summary),
            "bundle": bundle,
            "model_path": model_target,
            "score_model": score_model,
            "rank_model": rank_model,
            "final_frame": final_frame,
            "posthoc_predictions": posthoc_predictions,
            "posthoc_pairs": posthoc_pairs,
        }


def evaluate_on_common_devices(
    *,
    name: str,
    features: tuple[str, ...],
    left_label: str,
    left_score: dict[str, Any],
    left_rank: dict[str, Any],
    left_frame: pd.DataFrame,
    right_label: str,
    right_score: dict[str, Any],
    right_rank: dict[str, Any],
    right_frame: pd.DataFrame,
    common_names: list[str],
    output_dir: str | Path,
) -> dict[str, Any]:
    rows: list[pd.DataFrame] = []
    metrics: dict[str, Any] = {
        "status": "posthoc_common_device_comparison",
        "comparison": name,
        "common_device_names": common_names,
        "warning": (
            "These labels were already viewed. Common-device metrics are descriptive "
            "and did not select either five-PC set."
        ),
    }
    with feature_schema(features):
        for label, score_model, rank_model, frame in (
            (left_label, left_score, left_rank, left_frame),
            (right_label, right_score, right_rank, right_frame),
        ):
            common = compact.subset(frame, common_names)
            score_prediction = compact.predict_score(score_model, common)
            rankings, pairs, pair_metrics, device_metrics = (
                compact._external_rank_evaluation(rank_model, common)
            )
            metrics[label] = {
                "score": compact.regression_metrics(
                    common["overall"], score_prediction
                ),
                "rank_pairs": pair_metrics,
                "rank_devices": device_metrics,
            }
            rows.append(
                rankings.merge(
                    pd.DataFrame(
                        {
                            "name": common["name"],
                            f"{label}__predicted_overall": score_prediction,
                        }
                    ),
                    on="name",
                    validate="one_to_one",
                ).rename(
                    columns={
                        column: f"{label}__{column}"
                        for column in rankings.columns
                        if column != "name"
                    }
                )
            )
            pair_output = pairs.add_prefix(f"{label}__").rename(
                columns={f"{label}__left_name": "left_name", f"{label}__right_name": "right_name"}
            )
            if label == left_label:
                merged_pairs = pair_output
            else:
                merged_pairs = merged_pairs.merge(
                    pair_output,
                    on=["left_name", "right_name"],
                    how="outer",
                    validate="one_to_one",
                )
        device_output = rows[0].merge(
            rows[1], on="name", how="outer", validate="one_to_one"
        )
    output = Path(output_dir)
    write_csv(device_output, output / f"{name}_common_device_predictions.csv")
    write_csv(merged_pairs, output / f"{name}_common_device_pairs.csv")
    write_json(metrics, output / f"{name}_common_device_metrics.json")
    return compact._json_number(metrics)


def _metric_delta(
    after: dict[str, Any],
    before: dict[str, Any],
    path: tuple[str, ...],
) -> float:
    after_value: Any = after
    before_value: Any = before
    for key in path:
        after_value = after_value[key]
        before_value = before_value[key]
    return float(after_value) - float(before_value)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-prepared", type=Path, default=DEFAULT_BASE_PREPARED)
    parser.add_argument("--split", type=Path, default=DEFAULT_SPLIT)
    parser.add_argument("--submodels", type=Path, default=DEFAULT_SUBMODELS)
    parser.add_argument(
        "--treble-values", type=Path, default=DEFAULT_TREBLE_VALUES
    )
    parser.add_argument("--treble-audit", type=Path, default=DEFAULT_TREBLE_AUDIT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--models-dir", type=Path, default=DEFAULT_MODELS)
    parser.add_argument("--data-output-dir", type=Path, default=DEFAULT_DATA_OUTPUT)
    args = parser.parse_args(argv)

    base = compact.load_prepared(args.base_prepared, require_target=True)
    split = compact.load_split(args.split, base)
    split_payload = json.loads(args.split.read_text(encoding="utf-8"))
    if sha256(args.treble_audit) != EXPECTED_TREBLE_AUDIT_SHA256:
        raise ValueError("Historical treble audit does not match the audited file")
    treble_audit = json.loads(args.treble_audit.read_text(encoding="utf-8"))
    if treble_audit.get("overall_used_for_imputation") is not False:
        raise ValueError("Historical treble bridge audit unexpectedly used overall")
    if treble_audit.get("external_overall_used_for_imputation") is not False:
        raise ValueError("Historical treble bridge audit used external overall")

    selected_five, selection_candidates, selection_summary = (
        select_representative_five(base, split_payload, args.submodels)
    )
    # Label-mutation negative control: the X/SE selector must be unchanged.
    mutated = base.copy()
    mutated.loc[mutated["domain"].eq("pc"), "overall"] = np.linspace(
        5.0, 95.0, int(mutated["domain"].eq("pc").sum())
    )
    selected_mutated, candidates_mutated, _ = select_representative_five(
        mutated, split_payload, args.submodels
    )
    if selected_mutated != selected_five:
        raise RuntimeError("Representative selector changed after label mutation")
    numeric_columns = [
        "mean_nearest_distance",
        "max_nearest_distance",
        "rms_nearest_distance",
        "centroid_gap",
    ]
    if not np.array_equal(
        selection_candidates[numeric_columns].to_numpy(dtype=float),
        candidates_mutated[numeric_columns].to_numpy(dtype=float),
    ):
        raise RuntimeError("X/SE-only selector metrics changed after label mutation")
    selection_summary["label_mutation_negative_control_passed"] = True

    current_five = list(split["pc_development"])
    all_pc_names = base.loc[base["domain"].eq("pc"), "name"].astype(str).tolist()
    representative_remaining = [
        name for name in all_pc_names if name not in selected_five
    ]
    if len(representative_remaining) != 7:
        raise RuntimeError("Representative split must leave seven PCs")

    data_output = args.data_output_dir
    data_output.mkdir(parents=True, exist_ok=True)
    write_csv(
        selection_candidates,
        data_output / "representative_five_coverage_candidates.csv",
    )
    write_json(
        selection_summary,
        data_output / "representative_five_selection_audit.json",
    )
    representative_split = {
        "schema_version": 1,
        "status": "posthoc_feature_representative_split",
        "warning": (
            "All twelve PC labels were already viewed. This split is not a new "
            "frozen external test."
        ),
        "selection_uses_current_overall_values_or_old_external_errors": False,
        "historical_strata_used_as_selection_constraint": False,
        "tablet_development": split["tablet_development"],
        "pc_development": selected_five,
        "pc_posthoc_only": representative_remaining,
        "pc_strata": [
            {
                **item,
                "globally_selected_devices_in_this_historical_stratum": [
                    name
                    for name in selected_five
                    if name in item["candidate_devices"]
                ],
            }
            for item in split_payload["pc_strata"]
        ],
        "selection_audit_sha256": sha256(
            data_output / "representative_five_selection_audit.json"
        ),
    }
    write_json(
        representative_split,
        data_output / "representative_pc_split_posthoc.json",
    )
    selection_lock = {
        "status": "five_pc_selection_locked_before_variant_training",
        "selected_devices": selected_five,
        "remaining_devices": representative_remaining,
        "selector_audit_sha256": sha256(
            data_output / "representative_five_selection_audit.json"
        ),
        "candidate_table_sha256": sha256(
            data_output / "representative_five_coverage_candidates.csv"
        ),
        "base_feature_table_sha256": sha256(args.base_prepared),
        "submodel_uncertainty_table_sha256": sha256(args.submodels),
        "official_split_sha256": sha256(args.split),
        "script_sha256": sha256(__file__),
        "contains_model_or_remaining_pc_performance": False,
    }
    write_json(selection_lock, data_output / "selection_lock.json")

    output = args.output_dir
    models = args.models_dir
    treble_provider = FoldLocalTrebleProvider(base, args.treble_values)
    current_treble = run_variant(
        name="current_five_predicted_treble",
        features=TREBLE_FEATURES,
        provider=treble_provider,
        tablet_names=split["tablet_development"],
        pc_development=current_five,
        pc_posthoc=split["pc_external"],
        output_dir=output / "current_five_predicted_treble",
        model_path=models / "current_five_predicted_treble.joblib",
        provenance={
            "five_pc_selection": "unchanged official historical split",
            "treble_policy": (
                "replace treble_1/treble_2 with one predicted percentile; "
                "bridge family selected by training-only auxiliary LOO and "
                "refitted inside every outer fold; prefer Ridge-all6 when its "
                "LOO MAE is within 0.5 of the best candidate"
            ),
            "treble_values_sha256": sha256(args.treble_values),
            "historical_treble_audit_sha256": sha256(args.treble_audit),
        },
    )
    representative_raw = run_variant(
        name="representative_five_raw_treble",
        features=BASE_FEATURES,
        provider=ConstantProvider(base),
        tablet_names=split["tablet_development"],
        pc_development=selected_five,
        pc_posthoc=representative_remaining,
        output_dir=output / "representative_five_raw_treble",
        model_path=models / "representative_five_raw_treble.joblib",
        provenance={
            "five_pc_selection": selection_summary,
            "treble_policy": "retain raw treble_1 and treble_2",
            "selection_lock_sha256": sha256(data_output / "selection_lock.json"),
        },
    )
    representative_treble = run_variant(
        name="representative_five_predicted_treble",
        features=TREBLE_FEATURES,
        provider=treble_provider,
        tablet_names=split["tablet_development"],
        pc_development=selected_five,
        pc_posthoc=representative_remaining,
        output_dir=output / "representative_five_predicted_treble",
        model_path=models / "representative_five_predicted_treble.joblib",
        provenance={
            "five_pc_selection": selection_summary,
            "treble_policy": (
                "replace treble_1/treble_2 with one predicted percentile; "
                "bridge family selected by training-only auxiliary LOO and "
                "refitted inside every outer fold; prefer Ridge-all6 when its "
                "LOO MAE is within 0.5 of the best candidate"
            ),
            "selection_lock_sha256": sha256(data_output / "selection_lock.json"),
            "treble_values_sha256": sha256(args.treble_values),
            "historical_treble_audit_sha256": sha256(args.treble_audit),
        },
    )

    baseline_summary = json.loads(
        (
            PROJECT_ROOT
            / "results"
            / "experiments"
            / "compact_positive"
            / "validation_summary.json"
        ).read_text(encoding="utf-8")
    )
    baseline_bundle = joblib.load(
        PROJECT_ROOT
        / "models"
        / "experiments"
        / "compact_positive"
        / "overall_compact_positive_bundle.joblib"
    )
    common_names = [
        name
        for name in all_pc_names
        if name not in set(current_five) | set(selected_five)
    ]
    common_raw = evaluate_on_common_devices(
        name="raw_treble_old_vs_representative_five",
        features=BASE_FEATURES,
        left_label="current_five",
        left_score=baseline_bundle["score_model"],
        left_rank=baseline_bundle["rank_model"],
        left_frame=base,
        right_label="representative_five",
        right_score=representative_raw["score_model"],
        right_rank=representative_raw["rank_model"],
        right_frame=representative_raw["final_frame"],
        common_names=common_names,
        output_dir=output / "comparisons",
    )
    common_treble = evaluate_on_common_devices(
        name="predicted_treble_old_vs_representative_five",
        features=TREBLE_FEATURES,
        left_label="current_five",
        left_score=current_treble["score_model"],
        left_rank=current_treble["rank_model"],
        left_frame=current_treble["final_frame"],
        right_label="representative_five",
        right_score=representative_treble["score_model"],
        right_rank=representative_treble["rank_model"],
        right_frame=representative_treble["final_frame"],
        common_names=common_names,
        output_dir=output / "comparisons",
    )

    current_treble_summary = current_treble["summary"]
    representative_raw_summary = representative_raw["summary"]
    representative_treble_summary = representative_treble["summary"]
    comparison_summary = {
        "status": "posthoc_extensions_completed",
        "official_model_or_split_overwritten": False,
        "representative_selection": selection_summary,
        "current_split_raw_vs_predicted_treble": {
            "same_devices": True,
            "raw_treble": {
                "score_nested_mae": baseline_summary["score_nested_pc_loo"][
                    "mae"
                ],
                "rank_nested_log_loss": baseline_summary[
                    "rank_nested_pc_loo_pairs"
                ]["pairwise_log_loss"],
                "rank_nested_accuracy": baseline_summary[
                    "rank_nested_pc_loo_pairs"
                ]["pairwise_accuracy"],
                "posthoc_score_mae": baseline_summary[
                    "external_pc_score_posthoc_only"
                ]["mae"],
                "posthoc_rank_log_loss": baseline_summary[
                    "external_pc_rank_pairs_posthoc_only"
                ]["pairwise_log_loss"],
                "posthoc_rank_accuracy": baseline_summary[
                    "external_pc_rank_pairs_posthoc_only"
                ]["pairwise_accuracy"],
            },
            "predicted_treble": {
                "score_nested_mae": current_treble_summary[
                    "score_nested_pc_loo"
                ]["mae"],
                "rank_nested_log_loss": current_treble_summary[
                    "rank_nested_pc_loo_pairs"
                ]["pairwise_log_loss"],
                "rank_nested_accuracy": current_treble_summary[
                    "rank_nested_pc_loo_pairs"
                ]["pairwise_accuracy"],
                "posthoc_score_mae": current_treble_summary[
                    "remaining_pc_score_posthoc_only"
                ]["mae"],
                "posthoc_rank_log_loss": current_treble_summary[
                    "remaining_pc_rank_pairs_posthoc_only"
                ]["pairwise_log_loss"],
                "posthoc_rank_accuracy": current_treble_summary[
                    "remaining_pc_rank_pairs_posthoc_only"
                ]["pairwise_accuracy"],
            },
            "predicted_minus_raw": {
                "score_nested_mae": _metric_delta(
                    current_treble_summary,
                    baseline_summary,
                    ("score_nested_pc_loo", "mae"),
                ),
                "rank_nested_log_loss": _metric_delta(
                    current_treble_summary,
                    baseline_summary,
                    ("rank_nested_pc_loo_pairs", "pairwise_log_loss"),
                ),
                "posthoc_score_mae": float(
                    current_treble_summary[
                        "remaining_pc_score_posthoc_only"
                    ]["mae"]
                    - baseline_summary["external_pc_score_posthoc_only"]["mae"]
                ),
                "posthoc_rank_log_loss": float(
                    current_treble_summary[
                        "remaining_pc_rank_pairs_posthoc_only"
                    ]["pairwise_log_loss"]
                    - baseline_summary[
                        "external_pc_rank_pairs_posthoc_only"
                    ]["pairwise_log_loss"]
                ),
            },
        },
        "representative_split_raw_vs_predicted_treble": {
            "same_devices": True,
            "raw_treble": representative_raw_summary,
            "predicted_treble": representative_treble_summary,
            "predicted_minus_raw": {
                "score_nested_mae": _metric_delta(
                    representative_treble_summary,
                    representative_raw_summary,
                    ("score_nested_pc_loo", "mae"),
                ),
                "rank_nested_log_loss": _metric_delta(
                    representative_treble_summary,
                    representative_raw_summary,
                    ("rank_nested_pc_loo_pairs", "pairwise_log_loss"),
                ),
                "posthoc_score_mae": _metric_delta(
                    representative_treble_summary,
                    representative_raw_summary,
                    ("remaining_pc_score_posthoc_only", "mae"),
                ),
                "posthoc_rank_log_loss": _metric_delta(
                    representative_treble_summary,
                    representative_raw_summary,
                    (
                        "remaining_pc_rank_pairs_posthoc_only",
                        "pairwise_log_loss",
                    ),
                ),
            },
        },
        "old_vs_representative_five": {
            "development_sets_differ": True,
            "remaining_seven_sets_differ": True,
            "direct_remaining_seven_metric_comparison_is_not_controlled": True,
            "common_raw_treble_posthoc": common_raw,
            "common_predicted_treble_posthoc": common_treble,
        },
        "interpretation_guard": (
            "The selector was locked from X/SE coverage before variant results and "
            "is label-mutation invariant. It may be called more representative, "
            "not accuracy-optimal. All remaining-PC metrics are posthoc."
        ),
    }
    write_json(comparison_summary, output / "comparison_summary.json")
    print(
        json.dumps(
            {
                "status": "completed",
                "representative_five": selected_five,
                "representative_remaining": representative_remaining,
                "comparison_summary": str(
                    (output / "comparison_summary.json").resolve()
                ),
                "model_paths": {
                    "current_five_predicted_treble": str(
                        current_treble["model_path"].resolve()
                    ),
                    "representative_five_raw_treble": str(
                        representative_raw["model_path"].resolve()
                    ),
                    "representative_five_predicted_treble": str(
                        representative_treble["model_path"].resolve()
                    ),
                },
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
