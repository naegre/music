# 联合分数、排名与分差模型

## 目标

旧模型只回归排名百分位，能够学习顺序，但会丢失原始设备分差，并可能把全部预测压缩在 50 附近。联合模型改为学习一个潜在质量值，同时约束：

1. 单台设备的预测位置接近真实调整后分数；
2. 两台设备的预测顺序正确；
3. 预测设备差距接近归一化后的真实差距。

旧的百分位 Ridge/Huber 代码和模型保留不变。联合模型使用独立命令、结果目录和 bundle。

## 训练标签

每个 subdir 仍先计算：

```text
s = objective_score + K * subjective_contribution
```

每个训练折只用该折训练设备拟合：

```text
m = median(s)
r = 1.4826 * MAD(s)
```

MAD 为零时依次回退到 `IQR/1.349`、样本标准差和 1。最终潜在目标为：

```text
t = asinh((s - m) / r)
```

小跨度 subdir 会被放大到可学习尺度；正常跨度被统一到相似尺度；极端尾部被 `asinh` 软压缩，但顺序和差距不会像百分位转换那样全部丢失。目标中心和尺度不能在全数据上预先拟合，也不能读取留出设备或冻结外测。

## 输入特征

L2 和 cosine 仍先在同一 `subdir+x` 内做折内 paired robust 标准化，并统一成越大越好的方向。联合模型将高度共线的 mean/median 合并为：

```text
l2_quality_center  = (l2_quality_mean + l2_quality_median) / 2
cos_quality_center = (cos_quality_mean + cos_quality_median) / 2
```

候选 `center_stability` 另外使用 L2/cosine 的跨 x 与 x 内稳定性语义中心。所有模型系数下界为标准化空间中的 `0.01`，因此每个实际进入模型的语义特征均严格为正。KL/JS、SE、coverage 和窗口数不作为质量特征。

## 联合损失

同一个线性单调模型输出潜在质量 `u`：

```text
L = score_weight * L_score
  + rank_weight  * L_rank
  + gap_weight   * L_gap
  + 0.5 * alpha * ||beta||^2
```

- `L_score`：`Huber(u-t)`，保留设备自身的分数位置，并降低异常标签影响。
- `L_rank`：将真实差距和预测差距分别除以 temperature 后转为 sigmoid 软胜率，再计算 soft binary cross entropy。接近并列的设备目标接近 0.5，明显分差的设备目标更接近 0 或 1。
- `L_gap`：`Huber((u_i-u_j)-(t_i-t_j))`，直接惩罚预测差距被压缩或夸大。
- L2 正则：抑制小样本下的系数波动。

设备对权重从 `0.25` 起，随归一化真实差距增大，在差距达到 1 后封顶。近似并列仍参与训练，但不会支配损失；极端设备对也不会无限增权。

当前开发配置固定 `score_weight=1`、`rank_weight=0.5`、`gap_weight=0.5`、`temperature=1` 和 `Huber delta=1`，只在嵌套 LOODO 中选择 `alpha` 与 `center/center_stability`。这是为了限制约 10–12 台标签设备下的搜索自由度。

## 验证与选型

每个 subdir 使用嵌套 Leave-One-Device-Out：

1. 外层完全留出一台设备；
2. 内层仅在外层训练设备上选择候选；
3. 每个内外折重新拟合音频 robust 标准化、缺失值填充、特征 StandardScaler 和目标变换；
4. 外层留出预测合并后才计算主要泛化指标。

候选选择同时考虑：原分数量级 MAE、归一化 MAE、soft pair log loss、归一化 pair-gap MAE、Spearman、明显分差设备对准确率，以及 `spread_ratio` 的偏离。

```text
spread_ratio = std(OOF predicted score) / std(actual score)
```

`spread_ratio` 远小于 1 表示预测被压缩，远大于 1 表示分差被夸大。

## 命令

```bash
python main.py train-joint

python main.py predict-joint \
  --data /path/to/new_device_x_metrics.csv \
  --model models/joint_model_bundle.joblib
```

严格 inductive 的最终 robust 参考基准可使用：

```bash
python main.py train-joint \
  --reference-scope labelled_only \
  --output-dir results/train_joint_inductive \
  --model models/joint_model_bundle_inductive.joblib
```

## 输出语义

- `predicted_latent_quality`：模型直接输出的潜在质量值。
- `predicted_normalized_quality`：`50 + 20 * latent` 的便于显示版本；不是概率或百分位。
- `predicted_adjusted_score_raw`：通过折内目标逆变换得到的原始预测分数。
- `predicted_adjusted_score`：使用固定 spec 的 OOF 预测拟合非负 Theil–Sen 后的显示分数。
- `cohort_rank_percentile`：相对固定有标签参考设备计算的真实 mid-rank percentile。
- `predicted_percentile`：为了兼容 overall 层而保留，数值与 `cohort_rank_percentile` 相同。
- `estimated_rank`：新设备在“固定有标签参考设备 + 本设备”中的名次。

第一名的 `cohort_rank_percentile` 会接近 95–96，而不再把模型回归值 60 误称为严格百分位。

## 当前内部嵌套 OOF 结果

以下结果只来自开发标签的嵌套 LOODO，不是冻结外测：

| subdir | score MAE | Spearman | 明显分差 pair accuracy | spread ratio |
|---|---:|---:|---:|---:|
| clarity | 4.956 | 0.624 | 0.775 | 1.218 |
| clarity_voice | 5.217 | 0.538 | 0.741 | 0.846 |
| edginess | 12.083 | 0.441 | 0.689 | 1.415 |
| fullness | 2.843 | 0.832 | 0.868 | 1.004 |
| lowfreq | 5.225 | 0.650 | 0.815 | 0.747 |
| treble | 5.389 | 0.727 | 0.759 | 1.255 |

`fullness` 的分差压缩得到明显改善；`edginess` 仍是当前最弱且偏扩张的子类别，不能把这组结果描述成所有维度均优于旧模型。冻结外测没有用于调整上述配置。
