"""Predict new products, ranks, nearest references, and x-bootstrap intervals."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .features import aggregate_name_subdir, aggregate_transformed_group, reliability_warnings
from .joint_model import add_joint_features, percentile_against_references


def _bootstrap_feature_rows(
    transformed_group: pd.DataFrame,
    expected_x_count: int,
    n_bootstrap: int,
    rng: np.random.Generator,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    n_x = len(transformed_group)
    for _ in range(n_bootstrap):
        if n_x > 1:
            positions = rng.integers(0, n_x, size=n_x)
            sample = transformed_group.iloc[positions].copy()
        else:
            sample = transformed_group.copy()
            for metric in ("l2", "cos"):
                sample[f"{metric}_quality"] = rng.normal(
                    float(sample[f"{metric}_quality"].iloc[0]),
                    float(sample[f"{metric}_quality_se"].iloc[0]),
                )
        rows.append(aggregate_transformed_group(sample, expected_x_count))
    return pd.DataFrame(rows)


def predict_new_devices(
    merged_x_data: pd.DataFrame,
    bundle: dict,
    n_bootstrap: int = 1000,
    random_seed: int = 20260716,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Predict each available ``name + subdir`` and compare with labelled references."""

    rng = np.random.default_rng(random_seed)
    names = sorted(merged_x_data["name"].astype(str).unique())
    prediction_rows: list[dict[str, object]] = []
    pairwise_rows: list[dict[str, object]] = []
    for subdir, payload in sorted(bundle["models"].items()):
        task = merged_x_data[merged_x_data["subdir"].astype(str).eq(str(subdir))]
        if task.empty:
            for name in names:
                prediction_rows.append(
                    {"subdir": subdir, "name": name, "status": "missing_subdir"}
                )
            continue
        transformed = payload["normalizer"].transform(task)
        aggregated = aggregate_name_subdir(transformed, payload["normalizer"].expected_x_)
        indexed = aggregated.set_index("name")
        available_names = sorted(indexed.index.astype(str).unique())
        columns = payload["feature_columns"]
        percentiles = np.clip(
            payload["model"].predict(indexed.loc[available_names, columns]), 0.0, 100.0
        )
        references = payload["reference_predictions"]
        references = references[references["is_labelled"]].copy()
        expected_x_count = len(payload["normalizer"].expected_x_.get(subdir, ()))
        for name, percentile in zip(available_names, percentiles, strict=True):
            row = indexed.loc[name]
            comparison = references[references["name"].astype(str).ne(name)].copy()
            adjusted_score = float(payload["calibrator"].predict([percentile])[0])
            boot_features = _bootstrap_feature_rows(
                transformed[transformed["name"].astype(str).eq(name)],
                expected_x_count,
                n_bootstrap,
                rng,
            )
            boot_percentiles = np.clip(
                payload["model"].predict(boot_features[columns]), 0.0, 100.0
            )
            boot_scores = payload["calibrator"].predict(boot_percentiles)
            rank_samples = 1 + np.asarray(
                [np.sum(comparison["predicted_percentile"].to_numpy() > value) for value in boot_percentiles]
            )
            better = comparison[
                comparison["predicted_adjusted_score"] >= adjusted_score + 2.0
            ].sort_values("predicted_adjusted_score")
            worse = comparison[
                comparison["predicted_adjusted_score"] <= adjusted_score - 2.0
            ].sort_values("predicted_adjusted_score", ascending=False)
            same = comparison[
                np.abs(comparison["predicted_adjusted_score"] - adjusted_score) <= 1.0
            ].sort_values("predicted_adjusted_score", ascending=False)
            prediction_rows.append(
                {
                    "subdir": subdir,
                    "name": name,
                    "status": "ok",
                    "predicted_percentile": float(percentile),
                    "predicted_adjusted_score": adjusted_score,
                    "estimated_rank": int(1 + np.sum(comparison["predicted_percentile"] > percentile)),
                    "rank_denominator": int(len(comparison) + 1),
                    "percentile_ci_low": float(np.quantile(boot_percentiles, 0.025)),
                    "percentile_ci_high": float(np.quantile(boot_percentiles, 0.975)),
                    "score_ci_low": float(np.quantile(boot_scores, 0.025)),
                    "score_ci_high": float(np.quantile(boot_scores, 0.975)),
                    "rank_ci_low": int(np.quantile(rank_samples, 0.025, method="lower")),
                    "rank_ci_high": int(np.quantile(rank_samples, 0.975, method="higher")),
                    "nearest_clearly_better": str(better.iloc[0]["name"]) if not better.empty else "",
                    "nearest_clearly_worse": str(worse.iloc[0]["name"]) if not worse.empty else "",
                    "approximately_same": "|".join(same["name"].astype(str).tolist()),
                    "n_x": int(row["n_x"]),
                    "coverage_ratio": float(row["coverage_ratio"]),
                    "n_windows_total": int(row["n_windows_total"]),
                    "n_effective_total": float(row["n_effective_total"]),
                    "ci_source": "x_bootstrap" if int(row["n_x"]) > 1 else "within_only_parametric",
                    "warnings": reliability_warnings(row),
                }
            )
            for _, reference in comparison.iterrows():
                pairwise_rows.append(
                    {
                        "subdir": subdir,
                        "new_name": name,
                        "reference_name": str(reference["name"]),
                        "p_new_better": float(
                            np.mean(boot_percentiles > float(reference["predicted_percentile"]))
                        ),
                        "new_predicted_percentile": float(percentile),
                        "reference_predicted_percentile": float(reference["predicted_percentile"]),
                    }
                )
    return pd.DataFrame(prediction_rows), pd.DataFrame(pairwise_rows)


def predict_joint_devices(
    merged_x_data: pd.DataFrame,
    bundle: dict,
    n_bootstrap: int = 1000,
    random_seed: int = 20260716,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Predict score, rank, gap-aware quality, and fixed-cohort percentile."""

    if bundle.get("metadata", {}).get("bundle_type") != "joint_score_rank_gap":
        raise ValueError("predict_joint_devices requires a joint_score_rank_gap bundle")
    if n_bootstrap < 1:
        raise ValueError("n_bootstrap must be at least 1")
    rng = np.random.default_rng(random_seed)
    names = sorted(merged_x_data["name"].astype(str).unique())
    prediction_rows: list[dict[str, object]] = []
    pairwise_rows: list[dict[str, object]] = []
    for subdir, payload in sorted(bundle["models"].items()):
        task = merged_x_data[
            merged_x_data["subdir"].astype(str).eq(str(subdir))
        ]
        if task.empty:
            for name in names:
                prediction_rows.append(
                    {"subdir": subdir, "name": name, "status": "missing_subdir"}
                )
            continue
        transformed = payload["normalizer"].transform(task)
        aggregated = add_joint_features(
            aggregate_name_subdir(
                transformed, payload["normalizer"].expected_x_
            )
        )
        indexed = aggregated.set_index("name")
        available_names = sorted(indexed.index.astype(str).unique())
        columns = payload["feature_columns"]
        model = payload["model"]
        latent_values = model.predict_latent(indexed.loc[available_names, columns])
        raw_scores = model.predict_score(indexed.loc[available_names, columns])
        adjusted_scores = payload["calibrator"].predict(raw_scores)
        references = payload["reference_predictions"]
        references = references[references["is_labelled"]].copy()
        expected_x_count = len(payload["normalizer"].expected_x_.get(subdir, ()))

        for name, latent, raw_score, adjusted_score in zip(
            available_names,
            latent_values,
            raw_scores,
            adjusted_scores,
            strict=True,
        ):
            row = indexed.loc[name]
            comparison = references[
                references["name"].astype(str).ne(name)
            ].copy()
            comparison_scores = comparison["predicted_adjusted_score"].to_numpy(
                dtype=float
            )
            percentile = percentile_against_references(
                float(adjusted_score), comparison_scores
            )
            rank = int(1 + np.sum(comparison_scores > float(adjusted_score)))

            boot_features = add_joint_features(
                _bootstrap_feature_rows(
                    transformed[transformed["name"].astype(str).eq(name)],
                    expected_x_count,
                    n_bootstrap,
                    rng,
                )
            )
            boot_latent = model.predict_latent(boot_features[columns])
            boot_raw_scores = model.predict_score(boot_features[columns])
            boot_scores = payload["calibrator"].predict(boot_raw_scores)
            boot_percentiles = np.asarray(
                [
                    percentile_against_references(value, comparison_scores)
                    for value in boot_scores
                ],
                dtype=float,
            )
            rank_samples = 1 + np.asarray(
                [np.sum(comparison_scores > value) for value in boot_scores]
            )
            better = comparison[
                comparison["predicted_adjusted_score"] >= adjusted_score + 2.0
            ].sort_values("predicted_adjusted_score")
            worse = comparison[
                comparison["predicted_adjusted_score"] <= adjusted_score - 2.0
            ].sort_values("predicted_adjusted_score", ascending=False)
            same = comparison[
                np.abs(comparison["predicted_adjusted_score"] - adjusted_score) <= 1.0
            ].sort_values("predicted_adjusted_score", ascending=False)
            prediction_rows.append(
                {
                    "subdir": subdir,
                    "name": name,
                    "status": "ok",
                    "predicted_latent_quality": float(latent),
                    "predicted_normalized_quality": float(50.0 + 20.0 * latent),
                    "predicted_adjusted_score_raw": float(raw_score),
                    "predicted_adjusted_score": float(adjusted_score),
                    "cohort_rank_percentile": percentile,
                    "predicted_percentile": percentile,
                    "estimated_rank": rank,
                    "rank_denominator": int(len(comparison) + 1),
                    "normalized_quality_ci_low": float(
                        np.quantile(50.0 + 20.0 * boot_latent, 0.025)
                    ),
                    "normalized_quality_ci_high": float(
                        np.quantile(50.0 + 20.0 * boot_latent, 0.975)
                    ),
                    "percentile_ci_low": float(np.quantile(boot_percentiles, 0.025)),
                    "percentile_ci_high": float(np.quantile(boot_percentiles, 0.975)),
                    "score_ci_low": float(np.quantile(boot_scores, 0.025)),
                    "score_ci_high": float(np.quantile(boot_scores, 0.975)),
                    "rank_ci_low": int(
                        np.quantile(rank_samples, 0.025, method="lower")
                    ),
                    "rank_ci_high": int(
                        np.quantile(rank_samples, 0.975, method="higher")
                    ),
                    "nearest_clearly_better": (
                        str(better.iloc[0]["name"]) if not better.empty else ""
                    ),
                    "nearest_clearly_worse": (
                        str(worse.iloc[0]["name"]) if not worse.empty else ""
                    ),
                    "approximately_same": "|".join(
                        same["name"].astype(str).tolist()
                    ),
                    "n_x": int(row["n_x"]),
                    "coverage_ratio": float(row["coverage_ratio"]),
                    "n_windows_total": int(row["n_windows_total"]),
                    "n_effective_total": float(row["n_effective_total"]),
                    "ci_source": (
                        "x_bootstrap"
                        if int(row["n_x"]) > 1
                        else "within_only_parametric"
                    ),
                    "warnings": reliability_warnings(row),
                }
            )
            for _, reference in comparison.iterrows():
                reference_latent = float(reference["predicted_latent_quality"])
                model_probability = float(
                    1.0
                    / (
                        1.0
                        + np.exp(
                            -(
                                float(latent) - reference_latent
                            )
                            / max(float(payload["spec"].temperature), 1e-6)
                        )
                    )
                )
                reference_score = float(reference["predicted_adjusted_score"])
                pairwise_rows.append(
                    {
                        "subdir": subdir,
                        "new_name": name,
                        "reference_name": str(reference["name"]),
                        "model_probability_new_better": model_probability,
                        "bootstrap_probability_new_better": float(
                            np.mean(boot_scores > reference_score)
                        ),
                        "new_predicted_adjusted_score": float(adjusted_score),
                        "reference_predicted_adjusted_score": reference_score,
                        "predicted_score_gap": float(adjusted_score - reference_score),
                        "new_cohort_rank_percentile": percentile,
                        "reference_cohort_rank_percentile": float(
                            reference["cohort_rank_percentile"]
                        ),
                    }
                )
    return pd.DataFrame(prediction_rows), pd.DataFrame(pairwise_rows)
