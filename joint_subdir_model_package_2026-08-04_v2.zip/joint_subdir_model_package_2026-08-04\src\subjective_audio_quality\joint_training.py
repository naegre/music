"""Leakage-safe nested LOODO training for the joint score/rank/gap model."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence

import numpy as np
import pandas as pd

from .config import ExperimentConfig
from .features import aggregate_name_subdir
from .joint_model import (
    JOINT_FEATURES,
    JointModelSpec,
    JointQualityModel,
    add_joint_features,
    candidate_grid,
    cohort_percentiles,
    joint_metrics,
    joint_feature_columns,
    percentile_against_references,
)
from .models import PositiveAffineCalibrator
from .normalization import PairedRobustNormalizer
from .training import _score_map, _subdir_k
from .validation import FoldFeatureCache, eligible_devices


def _fit_predict_one(
    features: pd.DataFrame,
    train_devices: Sequence[str],
    heldout: str,
    score_map: Mapping[str, float],
    spec: JointModelSpec,
) -> tuple[float, float, JointQualityModel]:
    prepared = add_joint_features(features)
    columns = joint_feature_columns(spec.feature_mode)
    model = JointQualityModel(spec).fit(
        prepared.loc[list(train_devices), columns],
        [score_map[name] for name in train_devices],
    )
    heldout_x = prepared.loc[[heldout], columns]
    latent = float(model.predict_latent(heldout_x)[0])
    score = float(model.predict_score(heldout_x)[0])
    return latent, score, model


class JointValidationRunner:
    """Evaluate fixed candidates and perform nested candidate selection."""

    def __init__(
        self,
        merged_x_data: pd.DataFrame,
        simplicity_tolerance: float = 0.01,
        material_score_gap: float = 2.0,
    ):
        self.features = FoldFeatureCache(merged_x_data)
        self.simplicity_tolerance = float(simplicity_tolerance)
        self.material_score_gap = float(material_score_gap)
        self._oof_cache: dict[tuple[object, ...], pd.DataFrame] = {}

    @staticmethod
    def _target_key(
        devices: Sequence[str], score_map: Mapping[str, float]
    ) -> tuple[float, ...]:
        return tuple(round(float(score_map[name]), 12) for name in devices)

    def exact_spec_oof(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        spec: JointModelSpec,
    ) -> pd.DataFrame:
        devices = tuple(sorted(map(str, devices)))
        cache_key = (
            str(subdir),
            devices,
            self._target_key(devices, score_map),
            spec,
        )
        if cache_key in self._oof_cache:
            return self._oof_cache[cache_key].copy()
        target_percentiles = dict(
            zip(
                devices,
                cohort_percentiles([score_map[name] for name in devices]),
                strict=True,
            )
        )
        rows: list[dict[str, object]] = []
        for heldout in devices:
            train_devices = [name for name in devices if name != heldout]
            fold_features = self.features.get(subdir, train_devices)
            latent, predicted_score, _ = _fit_predict_one(
                fold_features,
                train_devices,
                heldout,
                score_map,
                spec,
            )
            rows.append(
                {
                    "subdir": str(subdir),
                    "name": heldout,
                    "adjusted_score": float(score_map[heldout]),
                    "target_percentile": float(target_percentiles[heldout]),
                    "oof_predicted_latent": latent,
                    "oof_predicted_normalized_quality": 50.0 + 20.0 * latent,
                    "oof_predicted_score": predicted_score,
                    "spec": spec.label,
                    "spec_json": json.dumps(spec.to_dict(), sort_keys=True),
                }
            )
        result = pd.DataFrame(rows)
        self._oof_cache[cache_key] = result.copy()
        return result

    def evaluate_exact_specs(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        candidates: Sequence[JointModelSpec],
    ) -> pd.DataFrame:
        rows: list[dict[str, object]] = []
        for spec in candidates:
            predictions = self.exact_spec_oof(subdir, devices, score_map, spec)
            metrics = joint_metrics(
                predictions["adjusted_score"],
                predictions["oof_predicted_score"],
                self.material_score_gap,
            )
            rows.append(
                {
                    "subdir": str(subdir),
                    "spec": spec.label,
                    "spec_json": json.dumps(spec.to_dict(), sort_keys=True),
                    **spec.to_dict(),
                    **metrics,
                }
            )
        return pd.DataFrame(rows)

    def select_spec(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        candidates: Sequence[JointModelSpec],
    ) -> tuple[JointModelSpec, pd.DataFrame]:
        comparison = self.evaluate_exact_specs(
            subdir, devices, score_map, candidates
        )
        lookup = {candidate.label: candidate for candidate in candidates}
        best_loss = float(comparison["selection_loss"].min())
        near_best = comparison[
            comparison["selection_loss"] <= best_loss + self.simplicity_tolerance
        ]
        ordered = near_best.sort_values(
            [
                "selection_loss",
                "alpha",
                "score_mae",
                "pair_gap_mae_normalized",
                "spearman",
            ],
            ascending=[True, False, True, True, False],
            na_position="last",
        )
        selected = lookup[str(ordered.iloc[0]["spec"])]
        return selected, comparison

    def nested_oof(
        self,
        subdir: str,
        devices: Sequence[str],
        score_map: Mapping[str, float],
        candidates: Sequence[JointModelSpec],
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Outer LOODO where every outer fold performs its own inner selection."""

        devices = tuple(sorted(map(str, devices)))
        target_percentiles = dict(
            zip(
                devices,
                cohort_percentiles([score_map[name] for name in devices]),
                strict=True,
            )
        )
        prediction_rows: list[dict[str, object]] = []
        selection_rows: list[dict[str, object]] = []
        for heldout in devices:
            outer_train = [name for name in devices if name != heldout]
            selected, comparison = self.select_spec(
                subdir, outer_train, score_map, candidates
            )
            fold_features = self.features.get(subdir, outer_train)
            latent, predicted_score, _ = _fit_predict_one(
                fold_features,
                outer_train,
                heldout,
                score_map,
                selected,
            )
            selected_row = comparison.loc[
                comparison["spec"].eq(selected.label)
            ].iloc[0]
            prediction_rows.append(
                {
                    "subdir": str(subdir),
                    "name": heldout,
                    "adjusted_score": float(score_map[heldout]),
                    "target_percentile": float(target_percentiles[heldout]),
                    "oof_predicted_latent": latent,
                    "oof_predicted_normalized_quality": 50.0 + 20.0 * latent,
                    "oof_predicted_score": predicted_score,
                    "selected_spec": selected.label,
                    "selected_spec_json": json.dumps(
                        selected.to_dict(), sort_keys=True
                    ),
                }
            )
            selection_rows.append(
                {
                    "subdir": str(subdir),
                    "heldout_name": heldout,
                    "selected_spec": selected.label,
                    "inner_selection_loss": float(selected_row["selection_loss"]),
                    "inner_score_mae": float(selected_row["score_mae"]),
                    "inner_spearman": float(selected_row["spearman"]),
                    "inner_spread_ratio": float(selected_row["spread_ratio"]),
                }
            )
        return pd.DataFrame(prediction_rows), pd.DataFrame(selection_rows)


def train_joint_models(
    merged_x_data: pd.DataFrame,
    targets: pd.DataFrame,
    config: ExperimentConfig,
    min_devices: int = 6,
    final_reference_scope: str = "all_reference",
) -> tuple[dict, dict[str, pd.DataFrame]]:
    """Select, fit, and package one joint-loss model for each subdir."""

    candidates = candidate_grid(
        config.joint_alphas,
        config.joint_rank_weights,
        config.joint_gap_weights,
        config.joint_temperatures,
        config.joint_score_weight,
        config.joint_huber_delta,
        config.joint_min_coefficient,
        config.joint_pair_weight_floor,
        config.joint_material_gap_normalized,
        config.joint_feature_modes,
    )
    runner = JointValidationRunner(
        merged_x_data,
        config.model_simplicity_tolerance,
        config.material_score_gap,
    )
    model_bundles: dict[str, dict] = {}
    nested_frames: list[pd.DataFrame] = []
    nested_selection_frames: list[pd.DataFrame] = []
    comparison_frames: list[pd.DataFrame] = []
    selected_rows: list[dict[str, object]] = []
    coefficient_frames: list[pd.DataFrame] = []
    feature_frames: list[pd.DataFrame] = []
    reference_frames: list[pd.DataFrame] = []

    subdirs = sorted(
        set(targets["subdir"].astype(str))
        & set(merged_x_data["subdir"].astype(str))
    )
    for subdir in subdirs:
        score_map = _score_map(targets, subdir)
        devices = eligible_devices(merged_x_data, subdir, score_map)
        if len(devices) < min_devices:
            selected_rows.append(
                {
                    "subdir": subdir,
                    "status": "skipped_too_few_devices",
                    "n_devices": len(devices),
                }
            )
            continue

        nested_oof, nested_selections = runner.nested_oof(
            subdir, devices, score_map, candidates
        )
        nested_metrics = joint_metrics(
            nested_oof["adjusted_score"],
            nested_oof["oof_predicted_score"],
            config.material_score_gap,
        )
        nested_frames.append(nested_oof)
        nested_selection_frames.append(nested_selections)

        selected_spec, comparison = runner.select_spec(
            subdir, devices, score_map, candidates
        )
        comparison_frames.append(comparison)
        selected_oof = runner.exact_spec_oof(
            subdir, devices, score_map, selected_spec
        )

        task = merged_x_data[
            merged_x_data["subdir"].astype(str).eq(subdir)
        ].copy()
        if final_reference_scope == "all_reference":
            normalizer_fit_rows = task
        elif final_reference_scope == "labelled_only":
            normalizer_fit_rows = task[
                task["name"].astype(str).isin(devices)
            ]
        else:
            raise ValueError(
                "final_reference_scope must be 'all_reference' or 'labelled_only'"
            )
        normalizer = PairedRobustNormalizer().fit(normalizer_fit_rows)
        aggregated = add_joint_features(
            aggregate_name_subdir(
                normalizer.transform(task), normalizer.expected_x_
            )
        )
        feature_frames.append(aggregated)
        indexed = aggregated.set_index("name")
        final_columns = joint_feature_columns(selected_spec.feature_mode)
        final_model = JointQualityModel(selected_spec).fit(
            indexed.loc[devices, final_columns],
            [score_map[name] for name in devices],
        )
        calibrator = PositiveAffineCalibrator(method="theil_sen").fit(
            selected_oof["oof_predicted_score"],
            selected_oof["adjusted_score"],
        )

        reference_names = sorted(indexed.index.astype(str).unique())
        reference_x = indexed.loc[reference_names, final_columns]
        reference_latent = final_model.predict_latent(reference_x)
        reference_score_raw = final_model.predict_score(reference_x)
        reference_score = calibrator.predict(reference_score_raw)
        labelled_mask = np.asarray([name in score_map for name in reference_names])
        labelled_scores = reference_score[labelled_mask]
        labelled_names = np.asarray(reference_names, dtype=object)[labelled_mask]
        labelled_percentiles = dict(
            zip(labelled_names, cohort_percentiles(labelled_scores), strict=True)
        )
        reference_percentiles = [
            float(labelled_percentiles[name])
            if name in labelled_percentiles
            else percentile_against_references(score, labelled_scores)
            for name, score in zip(reference_names, reference_score, strict=True)
        ]
        reference = pd.DataFrame(
            {
                "subdir": subdir,
                "name": reference_names,
                "predicted_latent_quality": reference_latent,
                "predicted_normalized_quality": 50.0 + 20.0 * reference_latent,
                "predicted_adjusted_score_raw": reference_score_raw,
                "predicted_adjusted_score": reference_score,
                "cohort_rank_percentile": reference_percentiles,
                "predicted_percentile": reference_percentiles,
                "is_labelled": labelled_mask,
            }
        )
        reference["reference_rank"] = reference["predicted_adjusted_score"].rank(
            method="min", ascending=False
        ).astype(int)
        reference_frames.append(reference)

        coefficients = final_model.coefficient_frame(final_columns)
        coefficients.insert(0, "subdir", subdir)
        coefficient_frames.append(coefficients)
        selected_rows.append(
            {
                "subdir": subdir,
                "status": "trained",
                "n_devices": len(devices),
                "k": _subdir_k(targets, subdir),
                "selected_spec": selected_spec.label,
                **selected_spec.to_dict(),
                "reported_validation": "nested_outer_LOODO",
                **nested_metrics,
                "calibration_slope": float(calibrator.slope_),
                "calibration_intercept": float(calibrator.intercept_),
            }
        )
        model_bundles[subdir] = {
            "subdir": subdir,
            "k": _subdir_k(targets, subdir),
            "normalizer": normalizer,
            "model": final_model,
            "calibrator": calibrator,
            "spec": selected_spec,
            "feature_columns": final_columns,
            "labelled_devices": devices,
            "score_map": score_map,
            "reference_predictions": reference,
            "selected_oof": selected_oof,
        }

    outputs = {
        "nested_oof_predictions": (
            pd.concat(nested_frames, ignore_index=True)
            if nested_frames
            else pd.DataFrame()
        ),
        "nested_selections": (
            pd.concat(nested_selection_frames, ignore_index=True)
            if nested_selection_frames
            else pd.DataFrame()
        ),
        "candidate_comparison": (
            pd.concat(comparison_frames, ignore_index=True)
            if comparison_frames
            else pd.DataFrame()
        ),
        "selected_models": pd.DataFrame(selected_rows),
        "coefficients": (
            pd.concat(coefficient_frames, ignore_index=True)
            if coefficient_frames
            else pd.DataFrame()
        ),
        "aggregated_features": (
            pd.concat(feature_frames, ignore_index=True)
            if feature_frames
            else pd.DataFrame()
        ),
        "reference_predictions": (
            pd.concat(reference_frames, ignore_index=True)
            if reference_frames
            else pd.DataFrame()
        ),
    }
    metadata = {
        "schema_version": 2,
        "package": "subjective_audio_quality",
        "bundle_type": "joint_score_rank_gap",
        "subjective_variant": config.subjective_variant,
        "subdirs": sorted(model_bundles),
        "feature_policy": "L2/cosine semantic centers; KL/JS excluded",
        "target_policy": (
            "fold-local median/robust-scale normalization followed by asinh"
        ),
        "loss_policy": "Huber score + soft pairwise rank + pair-gap Huber + L2",
        "validation": (
            "nested Leave-One-Device-Out with fold-local feature and target transforms"
        ),
        "percentile_semantics": (
            "mid-rank percentile against the fixed labelled reference cohort"
        ),
        "final_reference_scope": final_reference_scope,
        "n_models": len(model_bundles),
        "selected_models": [
            {
                "subdir": subdir,
                "k": payload["k"],
                "spec": payload["spec"].to_dict(),
                "n_labelled_devices": len(payload["labelled_devices"]),
            }
            for subdir, payload in sorted(model_bundles.items())
        ],
    }
    return {"metadata": metadata, "models": model_bundles}, outputs
