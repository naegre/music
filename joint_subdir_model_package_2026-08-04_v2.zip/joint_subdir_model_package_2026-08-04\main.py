#!/usr/bin/env python3
"""Unified command dispatcher for the standalone audio-quality project."""

from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "cli"))

COMMANDS = {
    "prepare": "prepare_data",
    "evaluate": "evaluate_models",
    "train": "train",
    "train-joint": "train_joint",
    "predict": "predict",
    "predict-joint": "predict_joint",
    "evaluate-predictions": "evaluate_predictions",
    "tune-k": "tune_k",
    "audit-filter": "audit_window_filter",
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=COMMANDS)
    args, remaining = parser.parse_known_args()
    module = importlib.import_module(COMMANDS[args.command])
    module.main(remaining)


if __name__ == "__main__":
    main()
