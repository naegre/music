#!/usr/bin/env python3
"""Train the leakage-safe joint score/rank/gap subdir models."""

from __future__ import annotations

import argparse
from pathlib import Path

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.config import load_experiment
from subjective_audio_quality.io import read_table, write_csv
from subjective_audio_quality.joint_training import train_joint_models
from subjective_audio_quality.persistence import save_bundle


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data", default=str(PROJECT_ROOT / "data/processed/x_metrics_merged.csv")
    )
    parser.add_argument(
        "--targets", default=str(PROJECT_ROOT / "data/processed/targets.csv")
    )
    parser.add_argument(
        "--config", default=str(PROJECT_ROOT / "configs/experiment.json")
    )
    parser.add_argument("--min-devices", type=int, default=6)
    parser.add_argument(
        "--reference-scope",
        choices=("all_reference", "labelled_only"),
        default="all_reference",
        help="Use labelled_only for strict inductive reference normalization.",
    )
    parser.add_argument(
        "--output-dir", default=str(PROJECT_ROOT / "results/train_joint")
    )
    parser.add_argument(
        "--model", default=str(PROJECT_ROOT / "models/joint_model_bundle.joblib")
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    config = load_experiment(args.config)
    bundle, outputs = train_joint_models(
        read_table(args.data),
        read_table(args.targets),
        config,
        min_devices=args.min_devices,
        final_reference_scope=args.reference_scope,
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for name, frame in outputs.items():
        write_csv(frame, output / f"{name}.csv")
    model_path = Path(args.model)
    save_bundle(bundle, model_path, model_path.with_suffix(".metadata.json"))
    print(outputs["selected_models"].to_string(index=False))
    print(f"Results: {output.resolve()}")
    print(f"Model: {model_path.resolve()}")


if __name__ == "__main__":
    main()
