# 联合子类别模型评估指标总结

## 1. 结果口径

本文中的主要结果来自每个 subdir 的嵌套 Leave-One-Device-Out（LOODO）外层预测。每台设备被预测时：

- 该设备没有参与模型拟合；
- 没有参与音频特征 robust 标准化、目标分数归一化和缺失值填充；
- 模型候选也只在外层剩余设备的内层 LOODO 中选择。

因此这里使用的是 `results/train_joint/selected_models.csv` 中 `reported_validation=nested_outer_LOODO` 的结果。冻结外测 `new.json` 没有用于训练、选参或本文指标。

## 2. 总体结果

| subdir | N | Score MAE | Score RMSE | Spearman | Kendall | Pair Acc. | Material Pair Acc. | Gap MAE | Spread Ratio |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| clarity | 10 | 4.956 | 6.704 | 0.624 | 0.422 | 0.711 | 0.775 | 0.925 | 1.218 |
| clarity_voice | 12 | 5.217 | 6.332 | 0.538 | 0.394 | 0.697 | 0.741 | 0.757 | 0.846 |
| edginess | 12 | 12.083 | 15.828 | 0.441 | 0.333 | 0.667 | 0.689 | 1.024 | 1.415 |
| fullness | 12 | 2.843 | 3.323 | 0.832 | 0.606 | 0.803 | 0.868 | 0.665 | 1.004 |
| lowfreq | 12 | 5.225 | 7.249 | 0.650 | 0.545 | 0.773 | 0.815 | 0.886 | 0.747 |
| treble | 12 | 5.389 | 6.794 | 0.727 | 0.576 | 0.788 | 0.759 | 0.737 | 1.255 |

六个 subdir 的等权平均仅用于概览：

| 指标 | 等权平均 |
|---|---:|
| Score MAE | 5.952 |
| Score RMSE | 7.705 |
| Normalized Score MAE | 0.574 |
| Spearman | 0.636 |
| Kendall tau | 0.479 |
| Pair Accuracy | 0.740 |
| Material Pair Accuracy | 0.774 |
| Pair Soft Log Loss | 0.663 |
| Pair Gap MAE | 0.832 |
| Spread Ratio | 1.081 |

不同 subdir 的原始分数量程不同，因此不能只根据原始 Score MAE 横向判断哪个维度更容易；应同时看 normalized error、排名和 spread ratio。

## 3. 各指标的计算和含义

### N

该 subdir 实际参加监督训练和嵌套验证的有标签设备数。样本只有 10–12 台，单台设备就可能明显改变相关系数，因此所有指标都应结合逐设备 OOF 文件查看。

### Score MAE

```text
MAE = mean(abs(predicted_adjusted_score - actual_adjusted_score))
```

单位与该 subdir 的调整后分数一致，越低越好。它表示一台设备平均偏离真实调整分数多少。MAE 不会特别放大单个极端误差。

### Score RMSE

```text
RMSE = sqrt(mean((predicted_adjusted_score - actual_adjusted_score)^2))
```

越低越好。RMSE 对大误差惩罚强于 MAE。若 RMSE 明显高于 MAE，说明存在少数误差特别大的设备；`edginess` 最明显。

### Score Bias

```text
Bias = mean(predicted_adjusted_score - actual_adjusted_score)
```

接近 0 最好。正数表示整体偏高，负数表示整体偏低。本轮分别为：

| subdir | Bias |
|---|---:|
| clarity | +0.720 |
| clarity_voice | +0.942 |
| edginess | -2.584 |
| fullness | -0.207 |
| lowfreq | -1.954 |
| treble | -0.777 |

### Normalized Score MAE / RMSE

先在评估设备的真实分数上计算 median 和 robust scale，再做：

```text
t = asinh((score - median) / robust_scale)
```

然后在该归一化空间计算 MAE/RMSE。越低越好。它消除了不同 subdir 分数量程不同的影响，更适合横向比较。当前 `fullness` 最好，`edginess` 最差。

### Spearman

衡量预测值和真实值的排名单调关系，范围为 `[-1,1]`：

- `1`：排名完全一致；
- `0`：没有稳定单调关系；
- `-1`：排名完全相反。

它只关心顺序，不关心分差大小。当前 `fullness=0.832` 最好，`edginess=0.441` 最弱。

### Kendall tau

同样衡量排序一致性，但更直接基于设备对的一致/逆序关系，范围为 `[-1,1]`。小样本下应与 Spearman 一起看。当前结果与 Spearman 的总体判断一致。

### Pairwise Accuracy

枚举同一 subdir 内所有真实分数不相同的设备对：

```text
Pair Accuracy = 排序方向正确的设备对数 / 全部有效设备对数
```

越高越好。它回答“任取两台设备，模型判断谁更好时有多大比例正确”。当前范围为 0.667–0.803。

### Material Pair Accuracy

只统计原始调整后分数差至少 2 分的设备对：

```text
abs(score_i - score_j) >= 2
```

越高越好。接近并列的设备即使排反也不进入该指标，因此它更符合“明显有差异的设备不能排反”的业务目标。当前 `fullness=0.868`、`lowfreq=0.815` 较好，`edginess=0.689` 较弱。

### Pairwise Soft Log Loss

真实归一化分差先转成软胜率：

```text
p_true(i>j) = sigmoid(t_i - t_j)
```

预测分差也转成 `p_pred`，再计算 soft binary cross entropy。越低越好。与硬 Pair Accuracy 不同，它同时惩罚方向错误和概率过度自信。

### Pair Gap MAE

```text
Gap MAE = mean(abs((pred_i-pred_j) - (true_i-true_j)))
```

这里的差值位于 robust/asinh 归一化空间。越低越好。它直接衡量模型是否保留设备间分差，是本次新模型相对旧百分位模型增加的核心指标。

### Actual / Predicted Score STD

分别是实际调整分数和 OOF 预测分数的样本标准差，用于观察预测范围是否被压缩或夸大。

### Spread Ratio

```text
Spread Ratio = std(predicted_score) / std(actual_score)
```

- 接近 `1`：预测分差尺度合适；
- 明显小于 `1`：预测范围被压缩；
- 明显大于 `1`：预测范围被夸大。

当前：

- `fullness=1.004`，分差尺度几乎一致；
- `clarity_voice=0.846`，轻度压缩；
- `lowfreq=0.747`，压缩较明显；
- `clarity=1.218`、`treble=1.255`，轻度扩张；
- `edginess=1.415`，扩张明显，需要谨慎解释分差。

### Selection Loss

仅用于内层候选模型选择，越低越好。它综合：

```text
0.25 * normalized_score_mae
+ 0.15 * pairwise_soft_log_loss
+ 0.20 * pair_gap_mae
+ 0.10 * spread_penalty
+ 0.15 * spearman_penalty
+ 0.15 * material_pair_penalty
```

它不是一个可直接解释为“准确率”的业务指标，也不应跨不同项目横向比较。

## 4. 分维度结论

- `fullness`：当前最稳定。分数 MAE 最低、排名最好、明显分差设备对准确率最高，spread ratio 几乎为 1。
- `treble`：排名和设备对判断较好，但 spread ratio 1.255，预测分差略偏大。
- `clarity`：中等水平，使用稳定性特征后排名改善，但分差也有一定扩张。
- `lowfreq`：明显设备对判断尚可，但预测范围被压缩，且纯排名低于旧 rank-only 模型。
- `clarity_voice`：分数范围较稳定，但排名能力一般。
- `edginess`：当前最弱。MAE/RMSE 最大，排名最低，spread ratio 最高。该维度不应作为高置信度输出。

## 5. 与旧排名模型的关系

联合模型不是所有维度都在纯排名指标上超过旧模型：

- `clarity`、`fullness`、`treble` 的嵌套 OOF Spearman 提高；
- `clarity_voice`、`edginess`、`lowfreq` 的嵌套 OOF Spearman 降低。

这是因为新模型同时优化分数、排名和分差，不再只追求排名。当前建议保留旧模型作为 rank-only 基线；若最终产品更重视纯排名，可以按 subdir 选择旧模型或联合模型，而不是强制六个维度全部切换。

## 6. 对应文件

- `selected_models.csv`：本文主要汇总结果。
- `nested_oof_predictions.csv`：逐设备外层 OOF 真实值和预测值。
- `nested_selections.csv`：每个外层留出设备对应的内层选型。
- `candidate_comparison.csv`：最终候选的固定-spec LOODO 比较，不能替代 nested OOF 主结果。
- `coefficients.csv`：最终部署模型系数；所有入模系数下界为 0.01。
- `reference_predictions.csv`：最终模型在固定参考设备上的预测。
