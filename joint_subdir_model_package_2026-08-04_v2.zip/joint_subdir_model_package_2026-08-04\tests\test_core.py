"""Focused tests for the statistical invariants that are easiest to break."""

from __future__ import annotations

import numpy as np
import pandas as pd

from subjective_audio_quality.features import aggregate_name_subdir
from subjective_audio_quality.joint_model import (
    JOINT_FEATURES,
    JointModelSpec,
    JointQualityModel,
    RobustTargetTransformer,
    add_joint_features,
)
from subjective_audio_quality.merge import merge_metric_rows
from subjective_audio_quality.normalization import PairedRobustNormalizer, robust_location_scale
from subjective_audio_quality.validation import FoldFeatureCache


def _row(name: str, l2: float, cos: float, n_windows: int = 6) -> dict[str, object]:
    return {
        "subdir": "clarity",
        "x": "0",
        "name": name,
        "n_windows": n_windows,
        "l2_mean": l2,
        "l2_var": 0.04,
        "cos_mean": cos,
        "cos_var": 0.0004,
    }


def test_robust_scale_has_zero_mad_fallback() -> None:
    center, scale, method = robust_location_scale(np.array([1.0, 1.0, 2.0, 2.0]))
    assert center == 1.5
    assert scale > 0
    assert method in {"mad", "iqr", "std"}


def test_alias_merge_preserves_raw_and_effective_counts() -> None:
    frame = pd.DataFrame([_row("recording_a", 3.0, 0.3), _row("recording_b", 3.2, 0.28)])
    merged, _ = merge_metric_rows(
        frame, {"recording_a": "product", "recording_b": "product"}
    )
    row = merged.iloc[0]
    assert row["n_windows_total"] == 12
    assert row["n_recordings"] == 2
    assert row["n_effective"] == 4.0
    assert row["n_effective"] != (12 + 4) / 5


def test_single_x_uncertainty_is_not_zero_between_x() -> None:
    source = pd.DataFrame([_row("a", 2.0, 0.5), _row("b", 4.0, 0.2)])
    merged, _ = merge_metric_rows(source, {})
    normalizer = PairedRobustNormalizer().fit(merged)
    aggregated = aggregate_name_subdir(normalizer.transform(merged), normalizer.expected_x_)
    assert aggregated["has_multiple_x"].eq(0).all()
    assert aggregated["l2_between_x_std"].isna().all()
    assert aggregated["cos_between_x_se"].isna().all()
    assert aggregated["l2_total_se"].gt(0).all()
    assert aggregated["uncertainty_mode"].eq("within_only").all()


def test_fold_statistics_ignore_heldout_extreme() -> None:
    base = pd.DataFrame(
        [_row("a", 2.0, 0.5), _row("b", 3.0, 0.4), _row("heldout", 4.0, 0.3)]
    )
    extreme = base.copy()
    extreme.loc[extreme["name"].eq("heldout"), ["l2_mean", "cos_mean"]] = [1000.0, -0.9]
    merged_base, _ = merge_metric_rows(base, {})
    merged_extreme, _ = merge_metric_rows(extreme, {})
    features_base = FoldFeatureCache(merged_base).get("clarity", ["a", "b"])
    features_extreme = FoldFeatureCache(merged_extreme).get("clarity", ["a", "b"])
    columns = ["l2_quality_mean", "cos_quality_mean"]
    np.testing.assert_allclose(
        features_base.loc[["a", "b"], columns],
        features_extreme.loc[["a", "b"], columns],
    )


def test_target_transform_normalizes_narrow_and_wide_score_ranges() -> None:
    narrow = np.array([70.0, 72.5, 75.0, 77.5, 80.0])
    wide = np.array([50.0, 62.5, 75.0, 87.5, 100.0])
    narrow_latent = RobustTargetTransformer().fit(narrow).transform(narrow)
    wide_latent = RobustTargetTransformer().fit(wide).transform(wide)
    np.testing.assert_allclose(narrow_latent, wide_latent)


def test_joint_model_keeps_semantic_coefficients_strictly_positive() -> None:
    feature_frame = pd.DataFrame(
        {
            "l2_quality_mean": np.linspace(-1.0, 1.0, 8),
            "l2_quality_median": np.linspace(-0.9, 1.1, 8),
            "cos_quality_mean": np.linspace(-1.2, 1.2, 8),
            "cos_quality_median": np.linspace(-1.1, 1.3, 8),
        }
    )
    prepared = add_joint_features(feature_frame)
    scores = np.linspace(70.0, 85.0, 8)
    spec = JointModelSpec(0.01, 0.5, 0.5, 1.0, min_coefficient=0.01)
    model = JointQualityModel(spec).fit(prepared[list(JOINT_FEATURES)], scores)
    assert np.all(model.regressor_.coef_ >= 0.01)
