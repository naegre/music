# 联合子类别模型交付包

本交付包包含联合“分数＋排名＋分差”子类别模型的可运行代码、训练配置、可复训数据、已训练模型、测试和结果。

解压后可直接打开根目录的 `模型评估指标总结.md` 查看全部指标公式、具体结果和逐子类别结论；`docs/JOINT_MODEL_METRICS_SUMMARY.md` 保留相同内容作为文档目录版本。

## 快速使用

```bash
python -m pip install -r requirements.txt
python -m pip install -e .

python main.py train-joint

python main.py predict-joint \
  --data data/raw/data.txt \
  --model models/joint_model_bundle.joblib

python -m pytest -q
```

Windows PowerShell 可将续行符替换为反引号，或者将命令写在同一行。

## 关键文件

- `models/joint_model_bundle.joblib`：已经训练完成的六个 subdir 模型。
- `configs/experiment.json`：联合 loss、正则化与候选配置。
- `data/processed/x_metrics_merged.csv`：训练用 `name+subdir+x` 聚合音频特征。
- `data/processed/targets.csv`：训练目标。
- `src/subjective_audio_quality/joint_model.py`：模型与 loss。
- `src/subjective_audio_quality/joint_training.py`：嵌套 LOODO 与训练打包。
- `results/train_joint/`：完整训练评估结果。
- `results/predict_joint/`：一次可复现的预测示例。
- `docs/JOINT_MODEL_TRAINING.md`：设计与使用说明。
- `docs/JOINT_MODEL_METRICS_SUMMARY.md`：指标定义和实际结果总结。
- `模型评估指标总结.md`：放在交付包根目录的同内容副本，便于直接查看。

## 数据与外测边界

包内保留训练所需数据和输入格式示例，但不包含冻结外测标签 `data/raw/new.json`。不得用冻结外测结果继续选择 alpha、loss 权重、特征模式或阈值。

`predicted_percentile` 与 `cohort_rank_percentile` 相同，表示相对固定有标签参考设备的组内 mid-rank percentile；`predicted_normalized_quality` 是模型质量指数，不是概率。
