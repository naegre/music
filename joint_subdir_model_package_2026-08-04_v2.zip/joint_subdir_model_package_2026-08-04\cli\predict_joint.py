#!/usr/bin/env python3
"""Predict subdir score, rank, gap, and fixed-reference percentile."""

from __future__ import annotations

import argparse
from pathlib import Path

from common import PROJECT_ROOT  # noqa: F401

from subjective_audio_quality.config import load_experiment, load_json
from subjective_audio_quality.io import canonicalize_columns, read_table, write_csv
from subjective_audio_quality.merge import apply_row_exclusions, merge_metric_rows
from subjective_audio_quality.persistence import load_bundle
from subjective_audio_quality.prediction import predict_joint_devices


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="New raw x-level CSV/TSV")
    parser.add_argument(
        "--model", default=str(PROJECT_ROOT / "models/joint_model_bundle.joblib")
    )
    parser.add_argument(
        "--aliases", default=str(PROJECT_ROOT / "configs/aliases.json")
    )
    parser.add_argument(
        "--config", default=str(PROJECT_ROOT / "configs/experiment.json")
    )
    parser.add_argument("--n-bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260716)
    parser.add_argument(
        "--output-dir", default=str(PROJECT_ROOT / "results/predict_joint")
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    config = load_experiment(args.config)
    canonical = canonicalize_columns(read_table(args.data), config.columns)
    merged, merge_audit = merge_metric_rows(canonical, load_json(args.aliases))
    revised, exclusion_audit = apply_row_exclusions(merged, config.drop_rows)
    predictions, pairwise = predict_joint_devices(
        revised,
        load_bundle(args.model),
        n_bootstrap=args.n_bootstrap,
        random_seed=args.seed,
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(predictions, output / "new_device_rankings.csv")
    write_csv(pairwise, output / "new_vs_reference_probabilities.csv")
    write_csv(merge_audit, output / "new_data_merge_audit.csv")
    write_csv(exclusion_audit, output / "new_data_exclusion_audit.csv")
    display_columns = [
        "subdir",
        "name",
        "status",
        "predicted_adjusted_score",
        "cohort_rank_percentile",
        "estimated_rank",
        "rank_ci_low",
        "rank_ci_high",
        "coverage_ratio",
        "warnings",
    ]
    print(predictions[display_columns].head(30).to_string(index=False))
    if len(predictions) > 30:
        print(f"... {len(predictions) - 30} additional rows written to CSV")
    print(f"Output: {output.resolve()}")


if __name__ == "__main__":
    main()
