"""Monotonic joint score/rank/gap model for small subdir datasets.

The model learns one latent quality value.  A robust, fold-local target
transform makes score gaps comparable across subdirs, while the objective
combines pointwise Huber loss, soft pairwise ranking loss, pair-gap Huber loss,
and L2 shrinkage.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import kendalltau, spearmanr
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

from .normalization import robust_location_scale
from .targets import percentile_rank


JOINT_FEATURES = (
    "l2_quality_center",
    "cos_quality_center",
)

JOINT_STABILITY_FEATURES = (
    "l2_stability_center",
    "cos_stability_center",
)


def add_joint_features(frame: pd.DataFrame) -> pd.DataFrame:
    """Collapse collinear mean/median pairs into two semantic features."""

    output = frame.copy()
    output["l2_quality_center"] = 0.5 * (
        output["l2_quality_mean"] + output["l2_quality_median"]
    )
    output["cos_quality_center"] = 0.5 * (
        output["cos_quality_mean"] + output["cos_quality_median"]
    )
    for metric in ("l2", "cos"):
        stability_columns = [
            f"{metric}_between_x_stability",
            f"{metric}_within_x_stability",
        ]
        output[f"{metric}_stability_center"] = (
            output[stability_columns].mean(axis=1, skipna=True)
            if set(stability_columns).issubset(output.columns)
            else np.nan
        )
    return output


def joint_feature_columns(mode: str) -> list[str]:
    """Return compact semantic feature columns for one candidate mode."""

    if mode == "center":
        return list(JOINT_FEATURES)
    if mode == "center_stability":
        return list(JOINT_FEATURES + JOINT_STABILITY_FEATURES)
    raise ValueError(f"Unknown joint feature mode: {mode}")


@dataclass(frozen=True)
class JointModelSpec:
    """Serializable hyperparameters for one joint-loss candidate."""

    alpha: float
    rank_weight: float
    gap_weight: float
    temperature: float
    score_weight: float = 1.0
    huber_delta: float = 1.0
    min_coefficient: float = 0.01
    pair_weight_floor: float = 0.25
    material_gap_normalized: float = 1.0
    feature_mode: str = "center"

    @property
    def label(self) -> str:
        return (
            f"joint_{self.feature_mode}_a{self.alpha:g}_rank{self.rank_weight:g}"
            f"_gap{self.gap_weight:g}_temp{self.temperature:g}"
        )

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class RobustTargetTransformer:
    """Fold-local median/robust-scale normalization plus soft tail compression."""

    def fit(self, scores) -> "RobustTargetTransformer":
        values = np.asarray(scores, dtype=float)
        if values.ndim != 1 or values.size < 2 or not np.isfinite(values).all():
            raise ValueError("scores must contain at least two finite values")
        center, scale, method = robust_location_scale(values)
        self.center_ = float(center)
        self.scale_ = float(scale)
        self.scale_method_ = str(method)
        transformed = self.transform(values)
        self.latent_min_ = float(np.min(transformed))
        self.latent_max_ = float(np.max(transformed))
        return self

    def transform(self, scores) -> np.ndarray:
        if not hasattr(self, "center_"):
            raise RuntimeError("RobustTargetTransformer.fit must be called first")
        values = np.asarray(scores, dtype=float)
        return np.arcsinh((values - self.center_) / self.scale_)

    def inverse_transform(self, latent, clip_margin: float | None = 1.0) -> np.ndarray:
        """Map latent values back to score units with conservative extrapolation."""

        values = np.asarray(latent, dtype=float)
        if clip_margin is not None:
            values = np.clip(
                values,
                self.latent_min_ - float(clip_margin),
                self.latent_max_ + float(clip_margin),
            )
        return self.center_ + self.scale_ * np.sinh(values)


def _huber(residual: np.ndarray, delta: float) -> tuple[np.ndarray, np.ndarray]:
    absolute = np.abs(residual)
    quadratic = absolute <= delta
    loss = np.where(
        quadratic,
        0.5 * np.square(residual),
        delta * (absolute - 0.5 * delta),
    )
    gradient = np.where(quadratic, residual, delta * np.sign(residual))
    return loss, gradient


class JointRankGapRegressor:
    """Positive linear regressor optimized with joint score/rank/gap losses."""

    def __init__(self, spec: JointModelSpec, max_iter: int = 5000):
        self.spec = spec
        self.max_iter = int(max_iter)

    def fit(self, x, target):
        features = np.asarray(x, dtype=float)
        values = np.asarray(target, dtype=float)
        if features.ndim != 2 or values.ndim != 1 or len(features) != len(values):
            raise ValueError("x and target have incompatible shapes")
        if len(values) < 3:
            raise ValueError("joint model requires at least three devices")
        n_samples, n_features = features.shape
        left, right = np.triu_indices(n_samples, k=1)
        pair_x = features[left] - features[right]
        target_gap = values[left] - values[right]
        temperature = max(float(self.spec.temperature), 1e-6)
        target_probability = expit(target_gap / temperature)
        material = max(float(self.spec.material_gap_normalized), 1e-6)
        pair_weight = float(self.spec.pair_weight_floor) + (
            1.0 - float(self.spec.pair_weight_floor)
        ) * np.minimum(np.abs(target_gap) / material, 1.0)
        pair_weight_sum = max(float(pair_weight.sum()), 1e-12)
        delta = max(float(self.spec.huber_delta), 1e-6)

        def objective(parameters):
            coefficients = parameters[:n_features]
            intercept = parameters[-1]
            prediction = features @ coefficients + intercept

            point_residual = prediction - values
            point_loss, point_psi = _huber(point_residual, delta)
            value = float(self.spec.score_weight) * float(np.mean(point_loss))
            prediction_gradient = (
                float(self.spec.score_weight) * point_psi / n_samples
            )

            predicted_gap = prediction[left] - prediction[right]
            logits = predicted_gap / temperature
            pair_bce = np.logaddexp(0.0, logits) - target_probability * logits
            value += float(self.spec.rank_weight) * float(
                np.dot(pair_weight, pair_bce) / pair_weight_sum
            )
            pair_gradient = (
                float(self.spec.rank_weight)
                * pair_weight
                * (expit(logits) - target_probability)
                / (pair_weight_sum * temperature)
            )

            gap_residual = predicted_gap - target_gap
            gap_loss, gap_psi = _huber(gap_residual, delta)
            value += float(self.spec.gap_weight) * float(
                np.dot(pair_weight, gap_loss) / pair_weight_sum
            )
            pair_gradient += (
                float(self.spec.gap_weight)
                * pair_weight
                * gap_psi
                / pair_weight_sum
            )

            np.add.at(prediction_gradient, left, pair_gradient)
            np.add.at(prediction_gradient, right, -pair_gradient)
            value += 0.5 * float(self.spec.alpha) * float(
                np.dot(coefficients, coefficients)
            )
            coefficient_gradient = (
                features.T @ prediction_gradient
                + float(self.spec.alpha) * coefficients
            )
            gradient = np.concatenate([coefficient_gradient, [prediction_gradient.sum()]])
            return value, gradient

        initial = np.concatenate(
            [
                np.full(n_features, float(self.spec.min_coefficient)),
                [float(np.median(values))],
            ]
        )
        bounds = [
            (float(self.spec.min_coefficient), None)
        ] * n_features + [(None, None)]
        result = minimize(
            objective,
            initial,
            method="L-BFGS-B",
            jac=True,
            bounds=bounds,
            options={"maxiter": self.max_iter},
        )
        if not np.isfinite(result.fun):
            raise RuntimeError(f"Joint optimization failed: {result.message}")
        self.coef_ = np.maximum(
            result.x[:n_features], float(self.spec.min_coefficient)
        )
        self.intercept_ = float(result.x[-1])
        self.n_features_in_ = n_features
        self.optimization_success_ = bool(result.success)
        self.objective_value_ = float(result.fun)
        return self

    def predict(self, x) -> np.ndarray:
        return np.asarray(x, dtype=float) @ self.coef_ + self.intercept_


class JointQualityModel:
    """Impute, scale, transform targets, and fit a joint-loss regressor."""

    def __init__(self, spec: JointModelSpec):
        self.spec = spec

    def fit(self, x, scores) -> "JointQualityModel":
        self.imputer_ = SimpleImputer(strategy="median", keep_empty_features=True)
        self.scaler_ = StandardScaler()
        imputed = self.imputer_.fit_transform(x)
        scaled = self.scaler_.fit_transform(imputed)
        self.target_transformer_ = RobustTargetTransformer().fit(scores)
        target = self.target_transformer_.transform(scores)
        self.regressor_ = JointRankGapRegressor(self.spec).fit(scaled, target)
        return self

    def _transform_x(self, x) -> np.ndarray:
        return self.scaler_.transform(self.imputer_.transform(x))

    def predict_latent(self, x) -> np.ndarray:
        return self.regressor_.predict(self._transform_x(x))

    def predict_score(self, x) -> np.ndarray:
        return self.target_transformer_.inverse_transform(self.predict_latent(x))

    def pair_probability(self, left, right) -> np.ndarray:
        difference = self.predict_latent(left) - self.predict_latent(right)
        return expit(difference / max(float(self.spec.temperature), 1e-6))

    def coefficient_frame(self, feature_names: list[str]) -> pd.DataFrame:
        standardized = np.asarray(self.regressor_.coef_, dtype=float)
        scales = np.asarray(self.scaler_.scale_, dtype=float)
        original = standardized / np.where(scales > 0.0, scales, 1.0)
        return pd.DataFrame(
            {
                "feature": feature_names,
                "coefficient_standardized": standardized,
                "coefficient_original_units": original,
                "lower_bound": float(self.spec.min_coefficient),
            }
        )


def candidate_grid(
    alphas,
    rank_weights,
    gap_weights,
    temperatures,
    score_weight: float,
    huber_delta: float,
    min_coefficient: float,
    pair_weight_floor: float,
    material_gap_normalized: float,
    feature_modes=("center", "center_stability"),
) -> list[JointModelSpec]:
    """Create a deliberately small joint-loss grid for nested LOODO."""

    return [
        JointModelSpec(
            alpha=float(alpha),
            rank_weight=float(rank_weight),
            gap_weight=float(gap_weight),
            temperature=float(temperature),
            score_weight=float(score_weight),
            huber_delta=float(huber_delta),
            min_coefficient=float(min_coefficient),
            pair_weight_floor=float(pair_weight_floor),
            material_gap_normalized=float(material_gap_normalized),
            feature_mode=str(feature_mode),
        )
        for alpha in alphas
        for rank_weight in rank_weights
        for gap_weight in gap_weights
        for temperature in temperatures
        for feature_mode in feature_modes
    ]


def joint_metrics(
    scores, predicted_scores, material_score_gap: float = 2.0
) -> dict[str, float | int]:
    """Measure score error, ordering, pair gaps, and range compression."""

    actual = np.asarray(scores, dtype=float)
    predicted = np.asarray(predicted_scores, dtype=float)
    transformer = RobustTargetTransformer().fit(actual)
    target_latent = transformer.transform(actual)
    predicted_latent = transformer.transform(predicted)
    score_error = predicted - actual
    normalized_error = predicted_latent - target_latent
    left, right = np.triu_indices(len(actual), k=1)
    target_gap = target_latent[left] - target_latent[right]
    predicted_gap = predicted_latent[left] - predicted_latent[right]
    non_ties = np.abs(target_gap) > 1e-12
    pair_accuracy = (
        float(np.mean(np.sign(target_gap[non_ties]) == np.sign(predicted_gap[non_ties])))
        if non_ties.any()
        else np.nan
    )
    raw_gap = np.abs(actual[left] - actual[right])
    material = non_ties & (raw_gap >= float(material_score_gap))
    material_pair_accuracy = (
        float(np.mean(np.sign(target_gap[material]) == np.sign(predicted_gap[material])))
        if material.any()
        else np.nan
    )
    target_probability = expit(target_gap)
    predicted_probability = np.clip(expit(predicted_gap), 1e-12, 1.0 - 1e-12)
    pair_log_loss = float(
        -np.mean(
            target_probability * np.log(predicted_probability)
            + (1.0 - target_probability) * np.log(1.0 - predicted_probability)
        )
    )
    actual_std = float(np.std(actual, ddof=1))
    predicted_std = float(np.std(predicted, ddof=1))
    spread_ratio = predicted_std / actual_std if actual_std > 1e-12 else np.nan
    rho = spearmanr(actual, predicted).statistic if len(actual) > 1 else np.nan
    tau = kendalltau(actual, predicted).statistic if len(actual) > 1 else np.nan
    gap_mae = float(np.mean(np.abs(predicted_gap - target_gap)))
    normalized_mae = float(np.mean(np.abs(normalized_error)))
    spread_penalty = (
        min(abs(float(np.log(max(spread_ratio, 1e-6)))), 2.0)
        if np.isfinite(spread_ratio)
        else 2.0
    )
    rho_value = float(rho) if np.isfinite(rho) else -1.0
    rank_penalty = 1.0 - (rho_value + 1.0) / 2.0
    material_penalty = (
        1.0 - material_pair_accuracy
        if np.isfinite(material_pair_accuracy)
        else 1.0
    )
    selection_loss = (
        0.25 * normalized_mae
        + 0.15 * pair_log_loss
        + 0.20 * gap_mae
        + 0.10 * spread_penalty
        + 0.15 * rank_penalty
        + 0.15 * material_penalty
    )
    return {
        "n": int(len(actual)),
        "score_mae": float(np.mean(np.abs(score_error))),
        "score_rmse": float(np.sqrt(np.mean(np.square(score_error)))),
        "score_bias": float(np.mean(score_error)),
        "normalized_score_mae": normalized_mae,
        "normalized_score_rmse": float(np.sqrt(np.mean(np.square(normalized_error)))),
        "spearman": float(rho),
        "kendall_tau": float(tau),
        "pairwise_accuracy": pair_accuracy,
        "material_pairwise_accuracy": material_pair_accuracy,
        "pairwise_soft_log_loss": pair_log_loss,
        "pair_gap_mae_normalized": gap_mae,
        "actual_score_std": actual_std,
        "predicted_score_std": predicted_std,
        "spread_ratio": float(spread_ratio),
        "selection_loss": float(selection_loss),
    }


def cohort_percentiles(values) -> np.ndarray:
    """Return true mid-rank percentiles for one comparison cohort."""

    return percentile_rank(np.asarray(values, dtype=float))


def percentile_against_references(value: float, references) -> float:
    """Rank one device against a fixed reference set, including a virtual self."""

    combined = np.append(np.asarray(references, dtype=float), float(value))
    return float(percentile_rank(combined)[-1])
